<?php
/**
 * Load and register widgets
 *
 * @package Baroque
 */

require_once BAROQUE_ADDONS_DIR . '/inc/widgets/popular-posts.php';
require_once BAROQUE_ADDONS_DIR . '/inc/widgets/socials.php';
require_once BAROQUE_ADDONS_DIR . '/inc/widgets/languages.php';

/**
 * Register widgets
 *
 * @since  1.0
 *
 * @return void
 */
if ( ! function_exists( 'baroque_register_widgets' ) ) :
	function baroque_register_widgets() {
		register_widget( 'Baroque_PopularPost_Widget' );
		register_widget( 'Baroque_Social_Links_Widget' );
		register_widget( 'Baroque_Language_Switcher_Widget' );
	}

	add_action( 'widgets_init', 'baroque_register_widgets' );
endif;

/**
 * Change markup of archive and category widget to include .count for post count
 *
 * @param string $output
 *
 * @return string
 */
if ( ! function_exists( 'baroque_widget_archive_count' ) ) :
	function baroque_widget_archive_count( $output ) {
		$output = preg_replace( '|\((\d+)\)|', '<span class="count">(\\1)</span>', $output );

		return $output;
	}

	add_filter( 'wp_list_categories', 'baroque_widget_archive_count' );
	add_filter( 'get_archives_link', 'baroque_widget_archive_count' );
endif;