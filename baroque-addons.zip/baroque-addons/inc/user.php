<?php
/**
 * Add more data for user
 *
 * @package Baroque
 */

/**
 * Add more contact method for user
 *
 * @param array $methods
 *
 * @return array
 */
function baroque_user_contact_methods( $methods ) {
	$methods['facebook']   = esc_html__( 'Facebook', 'baroque-addons' );
	$methods['twitter']    = esc_html__( 'Twitter', 'baroque-addons' );
	$methods['googleplus'] = esc_html__( 'Google Plus', 'baroque-addons' );
	$methods['pinterest']  = esc_html__( 'Pinterest', 'baroque-addons' );
	$methods['rss']        = esc_html__( 'Rss', 'baroque-addons' );

	return $methods;
}

add_filter( 'user_contactmethods', 'baroque_user_contact_methods' );