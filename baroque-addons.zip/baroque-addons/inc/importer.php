<?php
/**
 * Hooks for importer
 *
 * @package Baroque
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function baroque_vc_addons_importer() {
	return array(
		array(
			'name'       => 'Home Default',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-default/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-default/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-default/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Default',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Minimal',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-minimal/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-minimal/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-minimal/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Minimal',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Masonry',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-masonry/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-masonry/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-masonry/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Masonry',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Grid Background',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-grid-background/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-grid-background/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-grid-background/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Grid Background',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Vertical Slider',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-vertical-slider/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-vertical-slider/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-vertical-slider/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Vertical Slider',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Parallax',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-parallax/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-parallax/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-parallax/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Parallax',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home One Page',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-one-page/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-one-page/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-one-page/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home One Page',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Text Interactive',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-text-interactive/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-text-interactive/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-text-interactive/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Text Interactive',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Video',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-video/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-video/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-video/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Video',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Carousel',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-carousel/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-carousel/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/light/home-carousel/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Carousel',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		// Dark

		array(
			'name'       => 'Home Default Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-default/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-default/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-default/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Default',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Minimal Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-minimal/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-minimal/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-minimal/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Minimal',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Masonry Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-masonry/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-masonry/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-masonry/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Masonry',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Vertical Slider Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-vertical-slider/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-vertical-slider/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-vertical-slider/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Vertical Slider',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home One Page Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-one-page/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-one-page/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-one-page/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home One Page',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Zoom Dark',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-zoom/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-zoom/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/baroque/dark/home-zoom/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Zoom',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 455,
					'height' => 456,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 80,
					'height' => 80,
					'crop'   => 1,
				),
			),
		),
	);
}

add_filter( 'soo_demo_packages', 'baroque_vc_addons_importer', 20 );
