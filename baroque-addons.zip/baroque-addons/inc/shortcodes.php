<?php

/**
 * Define theme shortcodes
 *
 * @package Baroque
 */
class Baroque_Shortcodes {

	/**
	 * Store variables for js
	 *
	 * @var array
	 */
	public $l10n = array();

	/**
	 * Store variables for maps
	 *
	 * @var array
	 */
	public $maps = array();

	/**
	 * Check if WooCommerce plugin is actived or not
	 *
	 * @var bool
	 */
	private $wc_actived = false;

	/**
	 * Construction
	 *
	 * @return Baroque_Shortcodes
	 */
	function __construct() {
		$this->wc_actived = function_exists( 'is_woocommerce' );

		$shortcodes = array(
			'baroque_hero_slider',
			'baroque_latest_post',
			'baroque_portfolio',
			'baroque_empty_space',
			'baroque_single_image',
			'baroque_member',
			'baroque_button',
			'baroque_partner',
			'baroque_service',
			'baroque_image_box',
			'baroque_counter',
			'baroque_portfolio_quote',
			'baroque_portfolio_images',
			'baroque_portfolio_meta',
			'baroque_portfolios_grid_gap',
			'baroque_portfolios_grid',
			'baroque_vsslider',
			'baroque_vsslider2',
			'baroque_hsslider',
			'baroque_portfolios_list',
			'baroque_newsletter',
			'baroque_coming_soon',
			'baroque_revslider',
			'baroque_cta',
			'baroque_gmap',
		);

		foreach ( $shortcodes as $shortcode ) {
			add_shortcode( $shortcode, array( $this, $shortcode ) );
		}

		add_action( 'wp_footer', array( $this, 'footer' ) );

		add_action( 'wp_ajax_nopriv_baroque_load_portfolio', array( $this, 'ajax_load_portfolio' ) );
		add_action( 'wp_ajax_baroque_load_portfolio', array( $this, 'ajax_load_portfolio' ) );
	}

	public function footer() {
		wp_enqueue_script(
			'shortcodes', BAROQUE_ADDONS_URL . '/assets/js/frontend.js', array(
			'jquery',
			'imagesloaded',
			'wp-util',
		), '20171018', true
		);

		$this->l10n['days']    = esc_html__( 'days', 'baroque-addons' );
		$this->l10n['hours']   = esc_html__( 'hours', 'baroque-addons' );
		$this->l10n['minutes'] = esc_html__( 'minutes', 'baroque-addons' );
		$this->l10n['seconds'] = esc_html__( 'seconds', 'baroque-addons' );

		$this->l10n['isRTL'] = is_rtl();

		wp_localize_script( 'shortcodes', 'baroqueShortCode', $this->l10n );
	}

	/**
	 * Ajax load products
	 */
	function ajax_load_portfolio() {
		check_ajax_referer( 'baroque_get_portfolio', 'nonce' );

		$attr = $_POST['attr'];

		$attr['load_more'] = isset( $_POST['load_more'] ) ? $_POST['load_more'] : true;
		$attr['page']      = isset( $_POST['page'] ) ? $_POST['page'] : 1;
		$attr['style']     = isset( $_POST['style'] ) ? $_POST['style'] : 'thumbnail';
		$attr['source'] = 1;

		$products = $this->get_portfolio( $attr );

		wp_send_json_success( $products );
	}

	/**
	 * Get empty space
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_empty_space( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'height'        => '',
				'height_mobile' => '',
				'height_tablet' => '',
				'bg_color'      => '',
				'el_class'      => '',
			), $atts
		);

		$css_class = array(
			'ba-empty-space',
			$atts['el_class'],
		);

		$style = '';

		if ( $atts['bg_color'] ) {
			$style = 'background-color:' . $atts['bg_color'] . ';';
		}

		$height        = $atts['height'] ? (float) $atts['height'] : 0.0;
		$height_tablet = $atts['height_tablet'] ? (float) $atts['height_tablet'] : $height;
		$height_mobile = $atts['height_mobile'] ? (float) $atts['height_mobile'] : $height_tablet;

		$inline_css        = $height >= 0.0 ? ' style="height: ' . esc_attr( $height ) . 'px"' : '';
		$inline_css_mobile = $height_mobile >= 0.0 ? ' style="height: ' . esc_attr( $height_mobile ) . 'px"' : '';
		$inline_css_tablet = $height_tablet >= 0.0 ? ' style="height: ' . esc_attr( $height_tablet ) . 'px"' : '';

		return sprintf(
			'<div class="%s" style="%s">' .
			'<div class="ba_empty_space_lg" %s></div>' .
			'<div class="ba_empty_space_md" %s></div>' .
			'<div class="ba_empty_space_xs" %s></div>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$style,
			$inline_css,
			$inline_css_tablet,
			$inline_css_mobile
		);
	}


	/**
	 * Button
	 *
	 * @param array $atts
	 *
	 * @return string
	 */
	function baroque_button( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'align'                   => 'left',
				'style'                   => 'classic',
				'link'                    => '',
				'font_size'               => '',
				'button_background_color' => 'primary',
				'button_color'            => 'dark',
				'icon_ionicons'           => '',
				'el_class'                => '',
			), $atts
		);

		return $this->baroque_addons_btn( $atts );
	}

	/**
	 * Shortcode to display single image
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_single_image( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'      => '',
				'image_size' => 'full',
				'align'      => 'left',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'text-' . $atts['align'];

		$image_id = intval( $atts['image'] );
		if ( ! $atts['image'] ) {
			return;
		}

		$image_full = wp_get_attachment_image_src( $atts['image'], 'full' );

		if ( ! $image_full ) {
			return;
		}

		$image_size = $atts['image_size'];
		$image_src  = '';
		if ( function_exists( 'wpb_getImageBySize' ) ) {
			$image = wpb_getImageBySize(
				array(
					'attach_id'  => $image_id,
					'thumb_size' => $image_size,
				)
			);

			if ( $image['thumbnail'] ) {
				$image_src = $image['thumbnail'];
			} elseif ( $image['p_img_large'] ) {
				$image_src = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
			}

		}

		if ( empty( $image_src ) ) {
			$image_src = wp_get_attachment_image( $image_id, $image_size );
		}

		return sprintf(
			'<div class="ba-single-image ba-gallery-popup %s">' .
			'<a href="%s" class="photoswipe" data-large_image_width="%s" data-large_image_height="%s">' .
			'%s' .
			'</a>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_url( $image_full[0] ),
			esc_attr( $image_full[1] ),
			esc_attr( $image_full[2] ),
			$image_src
		);
	}

	/**
	 * Get tabs slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_hero_slider( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'full_width' => '',
				'color'      => 'light',
				'sliders'    => '',
				'el_class'   => '',
			), $atts
		);

		if ( ! $atts['sliders'] ) {
			return '';
		}

		$sliders = (array) json_decode( urldecode( $atts['sliders'] ), true );

		$output = array();
		$images = array();
		$i      = 0;
		foreach ( $sliders as $slider ) {
			$first_class = $style = '';
			if ( $i == 0 ) {
				$first_class = 'active';
			}
			$i ++;

			if ( isset( $slider['image'] ) && $slider['image'] ) {
				$props = wp_get_attachment_image_src( $slider['image'], 'full' );
				if ( $props ) {
					$images[] = sprintf( '<div class="item-image %s" style="background-image:url(%s)"></div>', esc_attr( $first_class ), esc_url( $props[0] ) );
				}
			}

			$item_content = '';
			if ( isset( $slider['subtitle'] ) && $slider['subtitle'] ) {
				$item_content .= sprintf( '<span class="desc">%s</span>', wp_kses( $slider['subtitle'], wp_kses_allowed_html( 'post' ) ) );
			}

			if ( isset( $slider['title'] ) && $slider['title'] ) {
				$item_content .= sprintf( '<h2 class="title">%s</h2>', wp_kses( $slider['title'], wp_kses_allowed_html( 'post' ) ) );
			}

			if ( isset( $slider['link'] ) && $slider['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $slider['link'] ) );
					if ( ! empty( $link ) ) {
						$item_content = sprintf(
							'<a href="%s" class="item-inner" %s%s %s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$style,
							$item_content
						);
					}
				}
			}

			$output[] = sprintf( '<div class="item-content %s">%s</div>', esc_attr( $first_class ), $item_content );
		}


		$css_class = $atts['el_class'];
		if ( $atts['full_width'] ) {
			$css_class .= ' full-width';
		}

		$items_class = 'slider-grid-content';

		$css_class .= ' hero-slider-' . $atts['color'];

		return sprintf(
			'<div class="ba-hero-slider %s">' .
			'<div class="hero-slider-content">' .
			'<div class="%s">' .
			'<div class="slider-items-content">' .
			'%s' .
			'</div>' .
			'</div>' .
			'<div class="slider-images-content">' .
			'%s' .
			'</div>' .
			'</div>' .
			'</div>',
			esc_attr( $css_class ),
			esc_attr( $items_class ),
			implode( ' ', $output ),
			implode( ' ', $images )
		);
	}

	/**
	 * Shortcode to display latest post
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_latest_post( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'number'    => '3',
				'read_more' => esc_html__( 'MORE', 'baroque-addons' ),
				'el_class'  => '',
			), $atts
		);

		$css_class = array(
			'ba-latest-post blog-grid',
			$atts['el_class'],
		);

		$output = array();

		$query_args = array(
			'posts_per_page'      => $atts['number'],
			'post_type'           => 'post',
			'ignore_sticky_posts' => true,
		);

		$query = new WP_Query( $query_args );

		while ( $query->have_posts() ) : $query->the_post();

			$category = get_the_terms( get_the_ID(), 'category' );

			$cat_html = '';

			if ( ! is_wp_error( $category ) && $category ) {
				$cat_html = sprintf( '<a href="%s" class="cat-links">%s</a>', esc_url( get_term_link( $category[0], 'category' ) ), esc_html( $category[0]->name ) );
			}

			if ( $cat_html ) {
				$cat_html = sprintf( '<span class="meta cat">%s</span>', $cat_html );
			}

			$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

			$time_string = sprintf(
				$time_string,
				esc_attr( get_the_date( 'c' ) ),
				esc_html( get_the_date() )
			);

			$time_string = sprintf( '<span class="meta date">%s</span>', $time_string );

			$output[] = sprintf(
				'<div class="post-wrapper col-md-4 col-xs-12 col-sm-6">
					<div class="blog-wrapper">
						<div class="entry-thumbnail">
							<a class="blog-thumb" href="%s">%s</a>
							<a href="%s" class="read-more">%s <i class="icon-plus"></i></a>
						</div>
						<div class="entry-summary">
							<div class="entry-header">
								<div class="entry-meta">
									%s%s
								</div>
								<h2 class="entry-title"><a href="%s">%s</a></h2>
							</div>
						</div>
					</div>
				</div>',
				get_the_permalink(),
				get_the_post_thumbnail( get_the_ID(), 'baroque-blog-grid' ),
				get_the_permalink(),
				$atts['read_more'],
				$time_string,
				$cat_html,
				get_the_permalink(),
				get_the_title()
			);

		endwhile;
		wp_reset_postdata();

		return sprintf(
			'<div class="%s">
                <div class="post-list row">%s</div>
            </div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display service
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_service( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'         => '1',
				'position'      => 'left',
				'service_image' => '',
				'image_size'    => '',
				'link'          => '',
				'sub_title'     => '',
				'title'         => '',
				'el_class'      => '',
			), $atts
		);

		$css_class = array(
			'ba-service',
			'style-' . $atts['style'],
			$atts['style'] == '1' ? 'content-' . $atts['position'] : '',
			$atts['el_class'],
		);

		$output = array();

		$attributes = array();

		$title = $sub_title = $icon = $link = $item = $btn = '';

		$arrow = '<i class="icon-plus"></i>';

		$link = vc_build_link( $atts['link'] );

		if ( ! empty( $link['url'] ) ) {
			$attributes['href'] = $link['url'];
		}

		if ( ! empty( $link['title'] ) ) {
			$attributes['title'] = $link['title'];
		}

		if ( ! empty( $link['target'] ) ) {
			$attributes['target'] = $link['target'];
		}

		if ( ! empty( $link['rel'] ) ) {
			$attributes['rel'] = $link['rel'];
		}

		$label = $link['title'];

		if ( ! $label ) {
			$attributes['title'] = $label;
		}

		$attr = array();

		foreach ( $attributes as $name => $value ) {
			$attr[] = $name . '="' . esc_attr( $value ) . '"';
		}

		if ( $atts['title'] ) {
			$title = sprintf(
				'<%1$s><%2$s %3$s>%4$s</%2$s></%1$s>',
				'h3',
				empty( $attributes['href'] ) ? 'span' : 'a',
				implode( ' ', $attr ),
				$atts['title']
			);
		}

		if ( $atts['sub_title'] ) {
			$sub_title = sprintf( '<span>%s</span>', $atts['sub_title'] );
		}

		$btn = sprintf(
			'<%1$s %2$s class="read-more">%3$s%4$s</%1$s>',
			empty( $attributes['href'] ) ? 'span' : 'a',
			implode( ' ', $attr ),
			$label,
			$arrow
		);

		if ( $atts['service_image'] ) {
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => $atts['service_image'],
						'thumb_size' => $atts['image_size'],
					)
				);

				$item .= $image['thumbnail'];
			} else {
				$image = wp_get_attachment_image_src( $atts['service_image'], $atts['image_size'] );
				if ( $image ) {
					$item .= sprintf(
						'<img alt="%s" src="%s">',
						esc_attr( $atts['image_size'] ),
						esc_url( $image[0] )
					);
				}
			}
		} else {
			$css_class[] = 'no-thumb';
		}

		$output[] = sprintf(
			'<div class="service-thumbnail"><a href="%s">%s</a>%s</div>',
			esc_url( $attributes['href'] ),
			$item,
			$atts['style'] == '2' ? $btn : ''
		);

		$output[] = '<div class="service-summary">';
		$output[] = $sub_title;
		$output[] = $title;
		$output[] = $atts['style'] == '1' ? $btn : '';
		$output[] = '</div>';

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display image box
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_image_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'      => '',
				'image_size' => '',
				'link'       => '',
				'sub_title'  => '',
				'title'      => '',
				'date'       => '',
				'el_class'   => '',
			), $atts
		);

		$css_class = array(
			'ba-image-box',
			$atts['el_class'],
		);

		$output = array();

		$attributes = array();

		$title = $sub_title = $date = $icon = $link = $item = '';

		$link = vc_build_link( $atts['link'] );

		if ( ! empty( $link['url'] ) ) {
			$attributes['href'] = $link['url'];
		}

		if ( ! empty( $link['title'] ) ) {
			$attributes['title'] = $link['title'];
		}

		if ( ! empty( $link['target'] ) ) {
			$attributes['target'] = $link['target'];
		}

		if ( ! empty( $link['rel'] ) ) {
			$attributes['rel'] = $link['rel'];
		}

		$label = $link['title'];

		if ( ! $label ) {
			$attributes['title'] = $label;
		}

		$attr = array();

		foreach ( $attributes as $name => $value ) {
			$attr[] = $name . '="' . esc_attr( $value ) . '"';
		}

		if ( $atts['title'] ) {
			$title = sprintf(
				'<%1$s><%2$s %3$s>%4$s</%2$s></%1$s>',
				'h3',
				empty( $attributes['href'] ) ? 'span' : 'a',
				implode( ' ', $attr ),
				$atts['title']
			);
		}

		if ( $atts['sub_title'] ) {
			$sub_title = sprintf( '<span class="subtitle">%s</span>', $atts['sub_title'] );
		}

		if ( $atts['date'] ) {
			$date = sprintf( '<span class="date">%s</span>', $atts['date'] );
		}

		if ( $atts['image'] ) {
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => $atts['image'],
						'thumb_size' => $atts['image_size'],
					)
				);

				$item .= $image['thumbnail'];
			} else {
				$image = wp_get_attachment_image_src( $atts['image'], $atts['image_size'] );
				if ( $image ) {
					$item .= sprintf(
						'<img alt="%s" src="%s">',
						esc_attr( $atts['image_size'] ),
						esc_url( $image[0] )
					);
				}
			}
		} else {
			$css_class[] = 'no-thumb';
		}

		if ( ! empty( $attributes['href'] ) ) {
			$item_html = sprintf( '<a href="%s">%s</a>', esc_url( $attributes['href'] ), $item );
		} else {
			$item_html = $item;
		}

		$output[] = sprintf(
			'<div class="service-thumbnail">%s</div>',
			$item_html
		);
		$output[] = '<div class="service-summary">';
		$output[] = $sub_title;
		$output[] = $date;
		$output[] = $title;
		$output[] = '</div>';

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display portfolio
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_portfolio( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'number'         => '-1',
				'read_more'      => esc_html__( 'SEE PROJECT', 'baroque-addons' ),
				'nav'            => false,
				'dot'            => false,
				'autoplay'       => false,
				'autoplay_speed' => '800',
				'el_class'       => '',
			), $atts
		);

		$css_class = array(
			'ba-portfolio portfolio-list',
			$atts['el_class'],
		);

		$autoplay_speed = intval( $atts['autoplay_speed'] );

		if ( $atts['autoplay'] ) {
			$autoplay = true;
		} else {
			$autoplay = false;
		}

		if ( $atts['nav'] ) {
			$nav = true;
		} else {
			$nav = false;
		}

		if ( $atts['dot'] ) {
			$dot = true;
		} else {
			$dot = false;
		}

		$id = uniqid( 'portfolio-slider-' );

		$this->l10n['portfolio'][$id] = array(
			'nav'            => $nav,
			'dot'            => $dot,
			'autoplay'       => $autoplay,
			'autoplay_speed' => $autoplay_speed,
		);

		$output = array();

		$query_args = array(
			'posts_per_page'      => $atts['number'],
			'post_type'           => 'portfolio',
			'ignore_sticky_posts' => true,
		);

		$query = new WP_Query( $query_args );

		while ( $query->have_posts() ) : $query->the_post();

			$category = get_the_terms( get_the_ID(), 'portfolio_category' );

			$cat_html = '';

			if ( ! is_wp_error( $category ) && $category ) {
				$cat_html = sprintf( '<a href="%s" class="portfolio-cat">%s</a>', esc_url( get_term_link( $category[0], 'category' ) ), esc_html( $category[0]->name ) );
			}

			$output[] = sprintf(
				'<div class="portfolio-wrapper">
					<div class="entry-thumbnail"><a href="%s">%s</a></div>
					<div class="container portfolio-inner">
						<div class="row">
							<div class="entry-summary col-md-8 col-sm-12 col-xs-12">
								<div class="summary-header">
									%s
									<h3 class="entry-title"><a href="%s">%s</a></h3>
									<div class="desc">%s</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-12 col-xs-12">
								<a href="%s" class="read-more">%s<i class="icon-plus"></i></a>
							</div>
						</div>
					</div>
				</div>',
				get_the_permalink(),
				get_the_post_thumbnail( get_the_ID(), 'baroque-portfolio-single' ),
				$cat_html,
				get_the_permalink(),
				get_the_title(),
				get_the_excerpt(),
				get_the_permalink(),
				$atts['read_more']
			);

		endwhile;
		wp_reset_postdata();

		$dir = '';

		if ( is_rtl() ) {
			$dir = 'dir="rtl"';
		}

		return sprintf(
			'<div class="%s">
                <div %s class="portfolio-list" id="%s">%s</div>
            </div>',
			esc_attr( implode( ' ', $css_class ) ),
			$dir,
			esc_attr( $id ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display counter
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_counter( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'color_scheme'   => 'dark',
				'columns'        => '1',
				'counter_option' => '',
				'el_class'       => '',
			), $atts
		);

		$css_class = array(
			'ba-counter',
			'columns-' . $atts['columns'],
			$atts['color_scheme'] . '-color',
			$atts['el_class'],
		);

		$option = vc_param_group_parse_atts( $atts['counter_option'] );
		$output = array();

		$columns = intval( $atts['columns'] );
		$col_css = 'col-xs-6 col-sm-12 col-md-' . 12 / $columns;

		foreach ( $option as $o ) {
			if ( isset( $o['value'] ) && $o['value'] ) {
				$content = sprintf( '<div class="counter"><span class="value">%s</span></div>', $o['value'] );
			}

			if ( isset( $o['title'] ) && $o['title'] ) {
				$content .= sprintf( '<h5 class="title">%s</h5>', $o['title'] );
			}

			$output[] = sprintf(
				'<div class="counter-content %s">%s</div>',
				esc_attr( $col_css ),
				$content
			);
		}

		return sprintf(
			'<div class="%s"><div class="list-counter">%s</div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display partner
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_partner( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'effect'              => 'none',
				'images'              => '',
				'image_size'          => 'thumbnail',
				'custom_links'        => '',
				'custom_links_target' => '_self',
				'el_class'            => '',
			), $atts
		);

		$css_class = array(
			'ba-partner',
			'effect-' . $atts['effect'],
			$atts['el_class'],
		);

		$output       = array();
		$custom_links = '';

		if ( function_exists( 'vc_value_from_safe' ) ) {
			$custom_links = vc_value_from_safe( $atts['custom_links'] );
			$custom_links = explode( ',', $custom_links );
		}

		$images = $atts['images'] ? explode( ',', $atts['images'] ) : '';

		if ( $images ) {
			$i = 0;
			foreach ( $images as $attachment_id ) {
				$image = wp_get_attachment_image( $attachment_id, $atts['image_size'] );
				if ( $image ) {
					$link = '';
					if ( $custom_links && isset( $custom_links[$i] ) ) {
						$link = preg_replace( '/<br \/>/iU', '', $custom_links[$i] );

						if ( $link ) {
							$link = 'href="' . esc_url( $link ) . '"';
						}
					}

					$output[] = sprintf(
						'<div class="partner-item">
							<a %s target="%s" >%s</a>
						</div>',
						$link,
						esc_attr( $atts['custom_links_target'] ),
						$image
					);
				}
				$i ++;
			}
		}

		return sprintf(
			'<div class="%s">
				<div class="list-item">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Get member
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_member( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'    => '',
				'name'     => '',
				'job'      => '',
				'socials'  => '',
				'el_class' => '',
			), $atts
		);

		$css_class = array(
			'ba-member',
			$atts['el_class']
		);

		$output = array();
		$intro  = '';

		if ( $atts['job'] ) {
			$output[] = sprintf( '<span class="job">%s</span>', $atts['job'] );
		}

		if ( $atts['name'] ) {
			$output[] = sprintf( '<h3 class="name">%s</h3>', $atts['name'] );
		}

		$socials = (array) json_decode( urldecode( $atts['socials'] ), true );

		$socials_html = '';
		if ( $socials ) {
			foreach ( $socials as $social ) {

				$text_html = '';
				if ( isset( $social['icon_ionicons'] ) && $social['icon_ionicons'] ) {
					$text_html = sprintf( '<i class="%s"></i>', esc_attr( $social['icon_ionicons'] ) );
				}

				$link_html = '';
				if ( isset( $social['link'] ) && $social['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $social['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="link" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								$text_html
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$socials_html .= $link_html;
			}

		}

		if ( $socials_html ) {
			$output[] = sprintf( '<div class="socials">%s</div>', $socials_html );
		}

		if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
			$content = wpb_js_remove_wpautop( $content, true );
		}

		if ( $content ) {
			$intro = sprintf( '<div class="member-intro">%s</div>', do_shortcode( $content ) );
		}

		$image_html = '';
		if ( $atts['image'] ) {
			$image_html = wp_get_attachment_image( $atts['image'], 'full' );
		}

		return sprintf(
			'<div class="%s">
				<div class="hover-border"><div></div></div>
				%s
				<div class="member-content">%s</div>
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$image_html,
			implode( ' ', $output ),
			$intro
		);

	}

	/**
	 * Shortcode to display portfolio quote
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_portfolio_quote( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'hide_border' => '',
				'title'       => '',
				'author'      => '',
				'cite'        => '',
				'el_class'    => '',
			), $atts
		);

		$css_class = array(
			'ba-portfolio-quote',
			$atts['hide_border'] == '1' ? 'hide-border' : '',
			$atts['el_class'],
		);

		$title = $author = $cite = '';

		if ( $atts['title'] ) {
			$title = sprintf( '<h3>%s</h3>', $atts['title'] );
		}

		if ( $atts['author'] ) {
			$author = sprintf( '%s', $atts['author'] );
		}

		if ( $atts['cite'] ) {
			$cite = sprintf( '<span>%s</span>', $atts['cite'] );
		}

		$cite_html = sprintf( '<cite>%s%s</cite>', $author, $cite );

		return sprintf(
			'<div class="%s">
				<div class="quote-header">
					%s
					<div class="quote-icon"><i class="icon_quotations"></i></div>
				</div>
				<div class="quote-content">
					<div class="quote">%s</div>
					%s
				</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$title,
			$content,
			$cite_html
		);
	}

	/**
	 * Shortcode to display portfolio images
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_portfolio_images( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'type'       => 'slides',
				'columns'    => '1',
				'images'     => '',
				'image_size' => '',
				'popup'      => '',
				'el_class'   => '',
			), $atts
		);

		$css_class = array(
			'ba-portfolio-images',
			$atts['el_class'],
		);

		if ( $atts['popup'] ) {
			$css_class[] = 'ba-gallery-popup';
		}

		$css = 'portfolio-' . $atts['type'];

		$col = '';

		if ( $atts['type'] == 'normal' ) {
			$css .= ' row columns-' . intval( $atts['columns'] );
			$col = 'col-sm-6 col-xs-12 col-md-' . 12 / intval( $atts['columns'] );
		} else {
			$css .= ' portfolio-slides';
		}

		$output = array();
		$images = $atts['images'] ? explode( ',', $atts['images'] ) : '';

		if ( $images ) {
			foreach ( $images as $attachment_id ) {
				$item = '';

				if ( function_exists( 'wpb_getImageBySize' ) ) {
					$image = wpb_getImageBySize(
						array(
							'attach_id'  => $attachment_id,
							'thumb_size' => $atts['image_size'],
						)
					);

					$item = $image['thumbnail'];
				} else {
					$image = wp_get_attachment_image_src( $attachment_id, $atts['image_size'] );
					if ( $image ) {
						$item = sprintf(
							'<img alt="%s" src="%s">',
							esc_attr( $atts['image_size'] ),
							esc_url( $image[0] )
						);
					}
				}

				$item_html  = $item;
				$image_full = wp_get_attachment_image_src( $attachment_id, 'full' );

				if ( $atts['popup'] ) {
					$item_html = sprintf(
						'<a href="%s" class="photoswipe" data-large_image_width="%s" data-large_image_height="%s">' .
						'%s' .
						'</a>',
						$image_full[0],
						$image_full[1],
						$image_full[2],
						$item
					);
				}

				$output[] = sprintf(
					'<div class="portfolio-item %s">
						%s
					</div>',
					esc_attr( $col ),
					$item_html
				);
			}
		}

		$dir = '';

		if ( is_rtl() ) {
			$dir = 'dir="rtl"';
		}

		return sprintf(
			'<div class="%s">
				<div %s class="portfolio-list-item %s">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$dir,
			esc_attr( $css ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display portfolio meta
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_portfolio_meta( $atts, $content ) {

		$atts = shortcode_atts(
			array(
				'cats'     => '',
				'tags'     => '',
				'socials'  => '',
				'meta'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class = array(
			'ba-portfolio-meta portfolio-meta',
			$atts['el_class'],
		);

		$meta   = vc_param_group_parse_atts( $atts['meta'] );
		$output = array();
		$index  = 1;
		if ( $meta ) {
			foreach ( $meta as $key => $value ) {
				$title = $val = '';

				if ( isset( $value['title'] ) && $value['title'] ) {
					$title = sprintf( '<h5 class="name">%s</h5>', $value['title'] );
				}

				if ( isset( $value['value'] ) && $value['value'] ) {
					$val = sprintf( '<div class="meta-content">%s</div>', $value['value'] );
				}

				$output[] = sprintf(
					'<div class="meta meta-%s">%s%s</div>',
					esc_attr( $index ),
					$title,
					$val
				);

				$index ++;
			}
		}

		$categories = get_the_terms( get_the_ID(), 'portfolio_category' );
		$tags       = get_the_terms( get_the_ID(), 'portfolio_tag' );

		if ( intval( $atts['cats'] ) ) {
			if ( ! is_wp_error( $categories ) && $categories ) {
				$cats = array();
				foreach ( $categories as $cat ) {
					$cats[] = sprintf( '<a href="%s">%s</a>', esc_url( get_term_link( $cat ) ), esc_html( $cat->name ) );
				}

				$output[] = sprintf(
					'<div class="meta cat"><h5>%s</h5><div class="portfolio-cat">%s</div></div>',
					apply_filters( 'ba_portfolio_meta_categories_label', esc_html__( 'CATEGORIES', 'baroque-addons' ) ),
					implode( ',', $cats )
				);
			}
		}

		if ( intval( $atts['tags'] ) ) {
			if ( ! is_wp_error( $tags ) && $tags ) {
				$t = array();
				foreach ( $tags as $tag ) {
					$t[] = sprintf( '<a href="%s">%s</a>', esc_url( get_term_link( $tag ) ), esc_html( $tag->name ) );
				}

				$output[] = sprintf(
					'<div class="meta tag"><h5>%s</h5><div class="portfolio-tag">%s</div></div>',
					apply_filters( 'ba_portfolio_meta_tags_label', esc_html__( 'TAGS', 'baroque-addons' ) ),
					implode( ',', $t )
				);
			}
		}

		if ( intval( $atts['socials'] ) ) {
			$output[] = sprintf(
				'<div class="meta socials"><h5>%s</h5>%s</div>',
				apply_filters( 'ba_portfolio_meta_socials_label', esc_html__( 'SHARE', 'baroque-addons' ) ),
				baroque_addons_share_link_socials( get_the_title(), get_the_permalink(), get_the_post_thumbnail() )
			);
		}

		$output = ( array ) apply_filters( 'baroque_vc_portfolio_meta', $output );

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function baroque_portfolios_grid_gap( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'source'   => '1',
				'cats'     => '',
				'per_page' => '9',
				'orderby'  => 'date',
				'order'    => 'desc',
				'ids'      => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$output      = array();

		$args = array(
			'post_type'           => 'portfolio',
			'posts_per_page'      => intval( $atts['per_page'] ),
			'ignore_sticky_posts' => true
		);

		if ( $atts['source'] == '1' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];

			if ( $atts['cats'] ) {
				$cats              = explode( ',', $atts['cats'] );
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio_category',
						'field'    => 'slug',
						'terms'    => $cats,
					),
				);
			}

		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids              = explode( ',', $atts['ids'] );
			$args['post__in'] = $ids;
			$args['orderby']  = 'post__in';
		}

		$query = new WP_Query( $args );
		$i     = 1;
		while ( $query->have_posts() ) : $query->the_post();

			$image_size = '490x320';
			$item_class = 'port-wide';

			$mod = $i % 9;
			if ( $mod == 2 ||
				$mod == 4 ||
				$mod == 6 ||
				$mod == 8
			) {
				$image_size = '320x490';
				$item_class = 'port-long';
			}
			$i ++;

			$image_src = '';
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => get_post_thumbnail_id( get_the_ID() ),
						'thumb_size' => $image_size,
					)
				);

				if ( $image['thumbnail'] ) {
					$image_src = $image['thumbnail'];
				} elseif ( $image['p_img_large'] ) {
					$image_src = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
				}

			}

			if ( empty( $image_src ) ) {
				$image_src = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), $image_size );
			}

			$term_list      = wp_get_post_terms( get_the_ID(), 'portfolio_category', array( 'fields' => 'names' ) );
			$term_list_html = '';
			if ( ! is_wp_error( $term_list ) && $term_list ) {
				$term_list_html = '<p><span>' . $term_list[0] . '</span></p>';
			}

			$output[] = sprintf(
				'<div class="col-md-4 col-sm-4 col-xs-6 port-item %s" > ' .
				'<div class="port-content" > ' .
				'%s' .
				'</div > ' .
				'<a href= "%s" class="port-title" > ' .
				'</a> ' .
				'<div class="port-heading" > ' .
				'<h2>%s</h2> ' .
				'%s' .
				'</div > ' .
				'</div > ',
				esc_attr( $item_class ),
				$image_src,
				esc_url( get_the_permalink() ),
				get_the_title(),
				$term_list_html
			);


		endwhile;
		wp_reset_postdata();

		return sprintf(
			'<div class="ba-portfolios-grid-gap %s">' .
			'<div class="ports-list">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function baroque_portfolios_grid( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'         => 'grid',
				'scrollbar'     => '',
				'arrows'        => '',
				'dots'          => '',
				'source'        => '1',
				'cats'          => '',
				'enable_filter' => '1',
				'load_more'     => false,
				'per_page'      => '9',
				'orderby'       => 'date',
				'order'         => 'desc',
				'ids'           => '',
				'el_class'      => '',
			), $atts
		);

		$atts['page'] = 1;

		$css_class = array(
			'ba-portfolios-grid portfolio-' . $atts['style'],
			$atts['el_class']
		);

		if ( $atts['load_more'] ) {
			$css_class[] = 'load-more-enabled';
		}

		$attr = array(
			'per_page' => intval( $atts['per_page'] ),
			'orderby'  => $atts['orderby'],
			'order'    => $atts['order'],
		);

		$filters      = array();
		$filters_html = '';

		if ( $atts['source'] == '1' ) {
			if ( $atts['enable_filter'] == '1' && $atts['style'] != 'carousel' ) {
				$css_class[] = 'filter-enable';

				if ( $atts['cats'] ) {
					$taxes    = explode( ',', $atts['cats'] );
					$taxonomy = 'portfolio_category';

					$filters[] = sprintf( '<li class="active" data-filter="*">%s</li>', esc_html__( 'All', 'baroque-addons' ) );

					foreach ( $taxes as $tax ) {
						$tax       = get_term_by( 'slug', $tax, $taxonomy );
						$filters[] = sprintf( '<li class="" data-filter=".%s-%s">%s</li>', esc_attr( $taxonomy ), esc_attr( $tax->slug ), esc_html( $tax->name ) );
					}
				}
				$filters_html = '<ul class="nav-filter filter">' . implode( "\n", $filters ) . '</ul>';
			}
		}

		$nav_carousel           = '';
		$carousel_container_css = array();

		if ( 'carousel' == $atts['style'] ) {
			$carousel_container_css[] = 'portfolio-carousel-wrapper';

			$nav_carousel =
				'<div class="navigation">
				<div class="container">
					<div class="btn-prev"><i class="icon-chevron-left"></i></div>
					<div class="btn-next"><i class="icon-chevron-right"></i></div>
				</div>
			</div>
			<div class="container">
				<div class="scrollbar">
					<div class="handle">
						<div class="mousearea"></div>
					</div>
				</div>
				<ul class="pages"></ul>
			</div>';
		}

		if ( ! intval( $atts['arrows'] ) ) {
			$carousel_container_css[] = 'hide-navigation';

		}

		if ( ! intval( $atts['scrollbar'] ) ) {
			$carousel_container_css[] = 'hide-scrollbar';
		}

		if ( ! intval( $atts['dots'] ) ) {
			$carousel_container_css[] = 'hide-dots';
		}

		return sprintf(
			'<div class="%s" data-attr="%s" data-load_more="%s" data-nonce="%s">' .
			'%s' .
			'<div id="ba-portfolio-vc" class="list-portfolio-wrapper %s">' .
			'%s' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( json_encode( $attr ) ),
			esc_attr( $atts['load_more'] ),
			esc_attr( wp_create_nonce( 'baroque_get_portfolio' ) ),
			$filters_html,
			implode( ' ', $carousel_container_css ),
			$this->get_portfolio( $atts ),
			$nav_carousel
		);
	}

	/**
	 * Get Vertical Slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_vsslider( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'    => '',
				'title_bg' => '',
				'link'     => '',
				'autoplay' => 0,
				'el_class' => '',
			), $atts
		);

		$autoplay    = intval( $atts['autoplay'] );
		$css_class[] = $atts['el_class'];
		$output      = array();

		if ( $atts['title_bg'] == '1' ) {
			$css_class[] = 'title-has-bg';
		}

		$items = (array) json_decode( urldecode( $atts['items'] ), true );
		foreach ( $items as $item ) {

			$bg_image = '';
			if ( isset( $item['image'] ) && $item['image'] ) {
				$image    = wp_get_attachment_image_src( $item['image'], 'full' );
				$bg_image = $image ? sprintf( '<div class="featured-img parallax-bg" ><img alt="" data-swiper-parallax="%s" src="%s"></div>', '-50%', esc_url( $image[0] ) ) : '';
			}

			$item_html = $url = '';

			if ( isset( $item['link'] ) && $item['link'] ) {

				$attributes = array();

				$attributes['data-swiper-parallax'] = '-300';

				$link = vc_build_link( $item['link'] );

				if ( ! empty( $link['url'] ) ) {
					$attributes['href'] = $link['url'];
				}

				$label = $link['title'];

				if ( ! $label ) {
					$attributes['title'] = $label;
				}

				if ( ! empty( $link['target'] ) ) {
					$attributes['target'] = $link['target'];
				}

				if ( ! empty( $link['rel'] ) ) {
					$attributes['rel'] = $link['rel'];
				}

				$attr = array();

				foreach ( $attributes as $name => $v ) {
					$attr[] = $name . '="' . esc_attr( $v ) . '"';
				}

				$url = sprintf(
					'<%1$s %2$s class="link">%3$s</%1$s>',
					empty( $attributes['href'] ) ? 'span' : 'a',
					implode( ' ', $attr ),
					$label
				);

				if ( isset( $item['title'] ) && $item['title'] ) {
					$item_html .= sprintf(
						'<%1$s class="title"><%2$s %3$s>%4$s</%2$s></%1$s>',
						'h2',
						empty( $attributes['href'] ) ? 'span' : 'a',
						implode( ' ', $attr ),
						$item['title']
					);
				}
			} else {
				if ( isset( $item['title'] ) && $item['title'] ) {
					$item_html .= sprintf(
						'<h2 class="title">%s</h2>',
						$item['title']
					);
				}
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$item_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			if ( isset( $item['desc'] ) && $item['desc'] ) {
				$item_html .= sprintf( '<div data-swiper-parallax="%s" class="desc">%s</div>', '-300', $item['desc'] );
			}

			$item_html .= $url;

			$output[] = sprintf(
				'<div class="slider-item swiper-slide" data-swiper-autoplay="%s">' .
				'<div class="container">' .
				'<div class="item-content">' .
				'%s' .
				'<div class="slider-content">' .
				'%s' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</div>',
				esc_attr( $autoplay ),
				$bg_image,
				$item_html
			);
		}

		$button_link = '';
		if ( isset( $atts['link'] ) && $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$button_link = sprintf(
						'<a href="%s" class="button-link" %s%s>%s</a>',
						isset( $link['url'] ) ? esc_url( $link['url'] ) : '',
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$id                            = uniqid( 'ba-vsslider-' );
		$this->l10n['baVsslider'][$id] = array(
			'autoplay' => $auto
		);

		$dir = '';

		if ( is_rtl() ) {
			$dir = 'dir="rtl"';
		}

		return sprintf(
			'<div %s class="ba-vs-slider3 swiper-container %s" id="%s">' .
			'<div class="hsslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="ba-buttons">' .
			'<div class="ba-button-prev ba-button-white"><i class="icon-arrow-up"></i></div>' .
			'<div class="ba-button-next ba-button-white"><i class="icon-arrow-down"></i></div>' .
			'</div>' .
			'%s' .
			'</div>',
			$dir,
			implode( ' ', $css_class ),
			esc_attr( $id ),
			implode( ' ', $output ),
			$button_link

		);

	}

	/**
	 * Get Vertical Slider Effect
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_vsslider2( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'       => '',
				'autoplay'    => '0',
				'button_link' => '',
				'el_class'    => '',
			), $atts
		);

		$autoplay = intval( $atts['autoplay'] );

		$css_class[] = $atts['el_class'];
		$output      = array();

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		foreach ( $items as $item ) {

			$item_output = array();
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image         = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$item_output[] = $image ? sprintf( '<div class="featured-img"  style="background-image: url(%s)"></div>', esc_url( $image[0] ) ) : '';
			}

			$title_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$title_html .= sprintf( '<h2>%s</h2>', $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$title_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			$item_html = '';
			if ( isset( $item['item_link'] ) && $item['item_link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['item_link'] ) );
					if ( ! empty( $link ) ) {
						$item_html = sprintf(
							'<a href="%s" class="title" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$title_html
						);
					}
				}
			}

			if ( empty( $item_html ) ) {
				$item_html = $title_html;
			}


			if ( $item_html ) {
				$item_output[] = sprintf( '<div class="slider-content"><div class="container">%s</div></div>', $item_html );
			}

			$output[] = sprintf(
				'<div class="slider-section swiper-slide" data-swiper-autoplay="%s">' .
				'<div class="slider-item">' .
				'%s' .
				'</div>' .

				'</div>',
				esc_attr( $autoplay ),
				implode( ' ', $item_output )
			);
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$id                             = uniqid( 'ba-vsslider-' );
		$this->l10n['bavsSlider2'][$id] = array(
			'autoplay' => $auto
		);

		$button_link = '';
		if ( isset( $atts['button_link'] ) && $atts['button_link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button_link'] ) );
				if ( ! empty( $link ) ) {
					$button_link = sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						isset( $link['url'] ) ? esc_url( $link['url'] ) : '',
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		return sprintf(
			'<div class="ba-vs-slider2 swiper-container %s" id="%s">' .
			'<div class="vsslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="custom-arrow">' .
			'<div class="container">' .
			'<div class="slick-prev slick-arrow"><span class="icon-chevron-left slick-prev-arrow"></span></div>' .
			'<div class="slick-next slick-arrow"><span class="icon-chevron-right slick-next-arrow"></span></div>' .
			'%s' .
			'</div>' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $id ),
			implode( ' ', $output ),
			$button_link
		);
	}

	/**
	 * Get Horizontal Swipe Slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function baroque_hsslider( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'    => '',
				'autoplay' => 0,
				'height'   => '726',
				'el_class' => '',
			), $atts
		);

		$autoplay    = intval( $atts['autoplay'] );
		$css_class[] = $atts['el_class'];
		$output      = array();
		$style       = '';

		if ( $atts['height'] ) {
			$style = 'min-height:' . intval( $atts['height'] ) . 'px;';
		}
		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		$count = count( $items );
		$total = sprintf( '%02d', $count );
		$i     = 1;

		foreach ( $items as $item ) {
			$i      = sprintf( '%02d', $i );
			$number = sprintf(
				'<div class="number">
					<span>%s</span> / <span class="total">%s</span>
				</div>',
				$i,
				$total
			);

			$bg_image = '';
			if ( isset( $item['image'] ) && $item['image'] ) {
				$image    = wp_get_attachment_image_src( $item['image'], 'full' );
				$bg_image = $image ? sprintf( '<div class="featured-img parallax-bg" >%s<img alt="" data-swiper-parallax="%s" src="%s"></div>', $number, '-50%', esc_url( $image[0] ) ) : '';
			}

			$parallax = '-300';

			$item_html = $url = '';

			if ( isset( $item['link'] ) && $item['link'] ) {

				$icon = '<i class="icon-plus"></i>';

				$attributes = array();

				$attributes['data-swiper-parallax'] = $parallax;

				$link = vc_build_link( $item['link'] );

				if ( ! empty( $link['url'] ) ) {
					$attributes['href'] = $link['url'];
				}

				$label = $link['title'];

				if ( ! $label ) {
					$attributes['title'] = $label;
				}

				if ( ! empty( $link['target'] ) ) {
					$attributes['target'] = $link['target'];
				}

				if ( ! empty( $link['rel'] ) ) {
					$attributes['rel'] = $link['rel'];
				}

				$attr = array();

				foreach ( $attributes as $name => $v ) {
					$attr[] = $name . '="' . esc_attr( $v ) . '"';
				}

				$url = sprintf(
					'<%1$s %2$s class="link">%3$s%4$s</%1$s>',
					empty( $attributes['href'] ) ? 'span' : 'a',
					implode( ' ', $attr ),
					$label,
					$icon
				);

				if ( isset( $item['title'] ) && $item['title'] ) {
					$item_html .= sprintf(
						'<%1$s data-swiper-parallax="%5$s" class="title"><%2$s %3$s>%4$s</%2$s></%1$s>',
						'h2',
						empty( $attributes['href'] ) ? 'span' : 'a',
						implode( ' ', $attr ),
						$item['title'],
						esc_attr( $parallax )
					);
				}
			} else {
				if ( isset( $item['title'] ) && $item['title'] ) {
					$item_html .= sprintf(
						'<h2 data-swiper-parallax="%s" class="title">%s</h2>',
						esc_attr( $parallax ),
						$item['title']
					);
				}
			}

			if ( isset( $item['area'] ) && $item['area'] ) {
				$item_html .= sprintf(
					'<div data-swiper-parallax="%s" class="area">%s</div>',
					esc_attr( $parallax ),
					$item['area']
				);
			}

			if ( isset( $item['location'] ) && $item['location'] ) {
				$item_html .= sprintf(
					'<div data-swiper-parallax="%s" class="location"><span>%s</span> %s</div>',
					esc_attr( $parallax ),
					esc_html__( 'Location:', 'baroque-addons' ),
					$item['location']
				);
			}

			if ( isset( $item['year'] ) && $item['year'] ) {
				$item_html .= sprintf(
					'<div data-swiper-parallax="%s" class="year"><span>%s</span> %s</div>',
					esc_attr( $parallax ),
					esc_html__( 'Year:', 'baroque-addons' ),
					$item['year']
				);
			}

			$item_html .= $url;

			$output[] = sprintf(
				'<div class="slider-item swiper-slide" data-swiper-autoplay="%s" style="%s">' .
				'%s' .
				'<div class="slider-content">' .
				'%s' .
				'</div>' .
				'</div>',
				esc_attr( $autoplay ),
				$style,
				$bg_image,
				$item_html
			);

			$i ++;
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$id                                 = uniqid( 'baroque-hsslider-' );
		$this->l10n['baroqueHsslider'][$id] = array(
			'autoplay' => $auto
		);


		return sprintf(
			'<div class="ba-hs-slider swiper-container %s" id="%s">' .
			'<div class="hsslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="ba-swiper-button">' .
			'<div class="swiper-button-prev swiper-button-white"><i class="icon-chevron-left"></i></div>' .
			'<div class="swiper-button-next swiper-button-white"><i class="icon-chevron-right"></i></div>' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $id ),
			implode( ' ', $output )
		);

	}

	/**
	 * Get portfolio list
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function baroque_portfolios_list( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'    => '1',
				'items'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		$i            = 0;
		$first_image  = '';
		$second_image = '';
		$output       = array();
		foreach ( $items as $item ) {

			$image_src = '';
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image     = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$image_src = $image ? $image[0] : '';
			}

			$title_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$title_html .= sprintf( '<h2>%s</h2>', $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$title_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			$item_html = '';
			if ( isset( $item['link'] ) && $item['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['link'] ) );
					if ( ! empty( $link ) ) {
						$item_html = sprintf(
							'<a href="%s" class="port-title" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$title_html
						);
					}
				}
			}

			if ( empty( $item_html ) ) {
				$item_html = $title_html;
			}

			if ( $atts['style'] == '1' ) {

				$item_class = '';
				if ( isset( $item['text_color'] ) && $item['text_color'] ) {
					$item_class = 'text-' . $item['text_color'];
				}

				$output[] = sprintf(
					'<div class="port-item %s"> ' .
					'<div class="port-content" > ' .
					'%s' .
					'</div > ' .
					'<div class="port-bg-white" ></div>' .
					'<div class="port-bg"  style="background-image: url(%s)"></div>' .
					'</div > ',
					esc_attr( $item_class ),
					$item_html,
					esc_url( $image_src )
				);
			} else {
				$class_active = '';
				if ( $i == 0 ) {
					$first_image  = $image_src;
					$class_active = 'active';
				}

				if ( $i == 1 ) {
					$second_image = $image_src;
				}

				$i ++;
				$output[] = sprintf(
					'<div class="port-item %s">' .
					'<div class="port-content" data-image="%s"> ' .
					'%s' .
					'</div > ' .
					'</div > ',
					esc_attr( $class_active ),
					esc_url( $image_src ),
					$item_html

				);
			}

		}

		if ( $output ) {
			if ( $atts['style'] == '1' ) {
				return sprintf(
					'<div class="ba-portfolios-list %s">' .
					'%s' .
					'</div>',
					implode( ' ', $css_class ),
					implode( ' ', $output )
				);
			} else {
				$second_image = $second_image ? $second_image : $first_image;

				return sprintf(
					'<div class="ba-portfolios-list %s">' .
					'<div class="port-list">' .
					'<div class="row">' .
					'<div class="col-md-6 col-sm-12 col-xs-12">' .
					'%s' .
					'</div>' .
					'<div class="col-md-6 hidden-sm hidden-xs">' .
					'<div class="port-first-image port-image" style="background-image: url(%s);"></div>' .
					'<div class="port-second-image port-image noactive" style="background-image: url(%s);"></div>' .
					'</div>' .
					'</div>' .
					'</div>' .
					'</div>',
					implode( ' ', $css_class ),
					implode( ' ', $output ),
					esc_url( $first_image ),
					esc_url( $second_image )
				);
			}
		}

	}

	/**
	 * Shortcode to display newsletter
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function baroque_newsletter( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'form'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class = array(
			'ba-newletter',
			$atts['el_class']
		);

		return sprintf(
			'<div class="%s"><div class="form-area">%s</div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			do_shortcode( '[mc4wp_form id="' . esc_attr( $atts['form'] ) . '"]' )
		);
	}

	/**
	 * Comming soon shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function baroque_coming_soon( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'date'       => '',
				'text_color' => 'dark',
				'el_class'   => '',
			), $atts
		);

		$css_class = array(
			'ba-coming-soon ba-time-format text-center',
			'text-' . $atts['text_color'],
			$atts['el_class'],
		);

		$second = 0;
		if ( $atts['date'] ) {
			$second_current = strtotime( date_i18n( 'Y/m/d H:i:s' ) );
			$date           = new DateTime( $atts['date'] );
			if ( $date ) {
				$second_discount = strtotime( date_i18n( 'Y/m/d H:i:s', $date->getTimestamp() ) );
				if ( $second_discount > $second_current ) {
					$second = $second_discount - $second_current;
				}
			}
		}

		$time_html = sprintf( '<div class="ba-time-countdown ba-countdown">%s</div>', $second );

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$time_html
		);
	}

	/*
	 * Revolution Slider
	 */
	function baroque_revslider( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'sliders'  => '',
				'socials'  => '',
				'el_class' => '',
			), $atts
		);

		$css_class = array(
			'ba-revslider',
			$atts['el_class'],
		);

		if ( ! isset( $atts['sliders'] ) || ! $atts['sliders'] ) {
			return;
		}

		$output = array();

		if ( isset( $atts['sliders'] ) ) {
			if ( $atts['sliders'] ) {
				$output[] = sprintf( '<div class="section-sliders">%s</div>', do_shortcode( '[rev_slider_vc alias="' . $atts['sliders'] . '"]' ) );
			}
		}

		$output[] = '<div class="section-sliders-info">';

		if ( $content ) {
			$output[] = sprintf( '<div class="slider-text"><div>%s</div></div>', do_shortcode( $content ) );
		}

		$socials = (array) json_decode( urldecode( $atts['socials'] ), true );

		$socials_html = '';
		if ( $socials ) {
			foreach ( $socials as $social ) {

				$text_html = '';
				if ( isset( $social['icon_ionicons'] ) && $social['icon_ionicons'] ) {
					$text_html = sprintf( '<i class="%s"></i>', esc_attr( $social['icon_ionicons'] ) );
				}

				$link_html = '';
				if ( isset( $social['link'] ) && $social['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $social['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="link" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								$text_html
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$socials_html .= $link_html;
			}

		}

		if ( $socials_html ) {
			$output[] = sprintf( '<div class="socials">%s</div>', $socials_html );
		}

		$output[] = '</div>';

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/*
	 * Call to Action
	 */
	function baroque_cta( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'color_scheme' => 'light',
				'image'        => '',
				'bg_color'     => '',
				'socials'      => '',
				'title'        => '',
				'subtitle'     => '',
				'el_class'     => '',
			), $atts
		);

		$css_class = array(
			'ba-cta',
			$atts['color_scheme'] . '-color',
			$atts['el_class'],
		);

		$style = $title = $subtitle = '';

		if ( $atts['image'] ) {
			$url         = wp_get_attachment_image_src( $atts['image'], 'full' );
			$style       = 'background-image:url( ' . esc_url( $url[0] ) . ' );';
			$css_class[] = 'has-background-image';
		}

		if ( $atts['bg_color'] ) {
			$style .= 'background-color:' . $atts['bg_color'] . ';';
		}

		$output = array();

		if ( $atts['title'] ) {
			$title = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['subtitle'] ) {
			$subtitle = sprintf( '<span class="subtitle">%s</span>', $atts['subtitle'] );
		}

		if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
			$content = wpb_js_remove_wpautop( $content, true );
		}

		$output[] = sprintf(
			'<div class="action-content" style="%s">
				<div class="action-content-wrapper">%s%s%s</div>
			</div>',
			esc_attr( $style ),
			$subtitle,
			$title,
			$content ? $content : ''
		);

		$socials = (array) json_decode( urldecode( $atts['socials'] ), true );

		$socials_html = '';
		if ( $socials ) {
			foreach ( $socials as $social ) {

				$text_html = '';
				if ( isset( $social['icon_ionicons'] ) && $social['icon_ionicons'] ) {
					$text_html = sprintf( '<i class="%s"></i>', esc_attr( $social['icon_ionicons'] ) );
				}

				$link_html = '';
				if ( isset( $social['link'] ) && $social['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $social['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="link" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								$text_html
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$socials_html .= $link_html;
			}

		}

		if ( $socials_html ) {
			$output[] = sprintf( '<div class="action-socials"><div class="socials">%s</div></div>', $socials_html );
		}

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/*
	 * GG Maps shortcode
	 */
	function baroque_gmap( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'api_key'             => '',
				'method'              => 'address',
				'location'            => '',
				'lat'                 => '',
				'lng'                 => '',
				'marker'              => '',
				'width'               => '',
				'height'              => '880',
				'zoom'                => '13',
				'address'             => '',
				'details'             => '',
				'email_label'         => esc_html__( 'Email:', 'baroque-addons' ),
				'email'               => '',
				'phone_label'         => esc_html__( 'Call directly:', 'baroque-addons' ),
				'phone'               => '',
				'brand_offices_label' => esc_html__( 'Brand Offices:', 'baroque-addons' ),
				'brand_offices'       => '',
				'map_btn'             => '',
				'el_class'            => '',
			), $atts
		);

		$class = array(
			'ba-map-shortcode',
			$atts['el_class'],
		);

		$info = $info_html = '';

		if ( $atts['address'] ) {
			$title = explode( '|', $atts['address'] );

			if ( sizeof( $title ) > 1 ) {
				$title = sprintf( '<div class="address"><span>%s</span> %s</div>', $title[0], $title[1] );
			} else {
				$title = sprintf( '<div class="address">%s</div>', $atts['address'] );
			}

			$info .= sprintf( '%s', $title );
		}

		if ( $atts['details'] ) {
			$info .= sprintf( '<p>%s</p>', $atts['details'] );
		}

		if ( $atts['email'] ) {
			$info .= sprintf( '<div class="email"><span>%s</span>%s</div>', $atts['email_label'], $atts['email'] );
		}

		if ( $atts['phone'] ) {
			$info .= sprintf( '<div class="phone"><span>%s</span>%s</div>', $atts['phone_label'], $atts['phone'] );
		}

		$offices = (array) json_decode( urldecode( $atts['brand_offices'] ), true );

		$offices_html = '';
		if ( $offices ) {
			foreach ( $offices as $office ) {

				$text_html = '';
				if ( isset( $office['brand_office'] ) && $office['brand_office'] ) {
					$text_html = sprintf( '%s', esc_attr( $office['brand_office'] ) );
				}

				$link_html = '';
				if ( isset( $office['link'] ) && $office['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $office['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								$text_html
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$offices_html .= $link_html;
			}
		}

		if ( $offices_html ) {
			$info .= sprintf( '<div class="offices"><h5>%s</h5><div class="list-offices">%s</div></div>', $atts['brand_offices_label'], $offices_html );
		}

		$link                = vc_build_link( $atts['map_btn'] );
		$attributes          = array();
		$attributes['class'] = 'map-btn btn-primary toggle-form';

		if ( ! empty( $link['url'] ) ) {
			$attributes['href'] = $link['url'];
		}

		$label = $link['title'];

		if ( ! $label ) {
			$attributes['title'] = $label;
		}

		if ( ! empty( $link['target'] ) ) {
			$attributes['target'] = $link['target'];
		}

		if ( ! empty( $link['rel'] ) ) {
			$attributes['rel'] = $link['rel'];
		}

		$attr = array();

		foreach ( $attributes as $name => $v ) {
			$attr[] = $name . '="' . esc_attr( $v ) . '"';
		}

		$button = sprintf(
			'<%1$s %2$s>%3$s</%1$s>',
			empty( $attributes['href'] ) ? 'span' : 'a',
			implode( ' ', $attr ),
			$label
		);

		$info .= sprintf( '<div class="map-btn-area">%s</div>', $button );

		$info .= sprintf(
			'<div class="map-form"><a class="toggle-form close-form" href="#"><i class="icon-cross"></i></a>%s</div>',
			do_shortcode( $content )
		);

		if ( ! empty( $info ) ) {
			$info_html = sprintf( '<div class="map-info">%s</div>', $info );
		}

		$style = '';
		if ( $atts['width'] ) {
			$unit = 'px;';
			if ( strpos( $atts['width'], '%' ) ) {
				$unit = '%;';
			}

			$atts['width'] = intval( $atts['width'] );
			$style .= 'width: ' . $atts['width'] . $unit;
		}
		if ( $atts['height'] ) {
			$unit = 'px;';
			if ( strpos( $atts['height'], '%' ) ) {
				$unit = '%;';
			}

			$atts['height'] = intval( $atts['height'] );
			$style .= 'height: ' . $atts['height'] . $unit;
		}
		if ( $atts['zoom'] ) {
			$atts['zoom'] = intval( $atts['zoom'] );
		}

		$id   = uniqid( 'mf_map_' );
		$html = sprintf(
			'<div class="%s"><div id="%s" class="ba-map" style="%s"></div>%s</div>',
			implode( ' ', $class ),
			$id,
			$style,
			$info_html
		);

		if ( 'address' == $atts['method'] ) {
			$coordinates = $this->get_coordinates( $atts['location'], $atts['api_key'] );
			$lats        = $coordinates['lat'];
			$lng         = $coordinates['lng'];

			if ( isset( $coordinates['error'] ) ) {
				return $coordinates['error'];
			}

		} else {
			$lats = $atts['lat'];
			$lng  = $atts['lng'];
		}

		$marker = '';
		if ( $atts['marker'] ) {

			if ( filter_var( $atts['marker'], FILTER_VALIDATE_URL ) ) {
				$marker = $atts['marker'];
			} else {
				$attachment_image = wp_get_attachment_image_src( intval( $atts['marker'] ), 'full' );
				$marker           = $attachment_image ? $attachment_image[0] : '';
			}
		}

		wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=' . $atts['api_key'] );

		$this->l10n['map'][$id] = array(
			'type'   => 'normal',
			'lat'    => $lats,
			'lng'    => $lng,
			'zoom'   => $atts['zoom'],
			'marker' => $marker,
			'height' => $atts['height'],
		);

		return $html;

	}

	/**
	 * Helper function to get coordinates for map
	 *
	 * @since 1.0.0
	 *
	 * @param string $address
	 * @param bool   $refresh
	 *
	 * @return array
	 */
	function get_coordinates( $address, $api_key, $refresh = false ) {
		$address_hash = md5( $address );
		$coordinates  = get_transient( $address_hash );
		$results      = array( 'lat' => '', 'lng' => '' );

		if ( $refresh || $coordinates === false ) {
			$args     = array( 'address' => urlencode( $address ), 'sensor' => 'false', 'key' => $api_key );
			$url      = add_query_arg( $args, 'https://maps.googleapis.com/maps/api/geocode/json' );
			$response = wp_remote_get( $url );

			if ( is_wp_error( $response ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'baroque-addons' );

				return $results;
			}

			$data = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $data ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'baroque-addons' );

				return $results;
			}

			if ( $response['response']['code'] == 200 ) {
				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {
					$coordinates = $data->results[0]->geometry->location;

					$results['lat']     = $coordinates->lat;
					$results['lng']     = $coordinates->lng;
					$results['address'] = (string) $data->results[0]->formatted_address;

					// cache coordinates for 3 months
					set_transient( $address_hash, $results, 3600 * 24 * 30 * 3 );
				} elseif ( $data->status === 'ZERO_RESULTS' ) {
					$results['error'] = esc_html__( 'No location found for the entered address.', 'baroque-addons' );
				} elseif ( $data->status === 'INVALID_REQUEST' ) {
					$results['error'] = esc_html__( 'Invalid request. Did you enter an address?', 'baroque-addons' );
				} else {
					$results['error'] = esc_html__( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'baroque-addons' );
				}
			} else {
				$results['error'] = esc_html__( 'Unable to contact Google API service.', 'baroque-addons' );
			}
		} else {
			$results = $coordinates; // return cached results
		}

		return $results;
	}

	/**
	 * Get images from Instagram profile page
	 *
	 * @since 2.0
	 *
	 * @param string $username
	 *
	 * @return array | WP_Error
	 */
	protected function scrape_instagram( $username ) {
		$username      = strtolower( $username );
		$username      = str_replace( '@', '', $username );
		$transient_key = 'baroque_instagram-' . sanitize_title_with_dashes( $username );

		if ( false === ( $instagram = get_transient( $transient_key ) ) ) {
			$remote = wp_remote_get( 'http://instagram.com/' . trim( $username ) . '/?__a=1' );

			if ( is_wp_error( $remote ) ) {
				return new WP_Error( 'site_down', esc_html__( 'Unable to communicate with Instagram.', 'baroque-addons' ) );
			}

			if ( 200 != wp_remote_retrieve_response_code( $remote ) ) {
				return new WP_Error( 'invalid_response', esc_html__( 'Instagram did not return a 200.', 'baroque-addons' ) );
			}

			$data = json_decode( $remote['body'], true );

			if ( ! $data ) {
				return new WP_Error( 'bad_json', esc_html__( 'Instagram has returned invalid data.', 'baroque-addons' ) );
			}

			if ( isset( $data['user']['media']['nodes'] ) ) {
				$images = $data['user']['media']['nodes'];
			} else {
				return new WP_Error( 'bad_json_2', esc_html__( 'Instagram has returned invalid data.', 'baroque-addons' ) );
			}

			if ( ! is_array( $images ) ) {
				return new WP_Error( 'bad_array', esc_html__( 'Instagram has returned invalid data.', 'baroque-addons' ) );
			}

			$instagram = array();

			foreach ( $images as $image ) {

				$image['thumbnail_src'] = preg_replace( '/^https?\:/i', '', $image['thumbnail_src'] );
				$image['display_src']   = preg_replace( '/^https?\:/i', '', $image['display_src'] );

				// handle both types of CDN url
				if ( ( strpos( $image['thumbnail_src'], 's640x640' ) !== false ) ) {
					$image['thumbnail'] = str_replace( 's640x640', 's160x160', $image['thumbnail_src'] );
					$image['small']     = str_replace( 's640x640', 's240x240', $image['thumbnail_src'] );
				} else {
					$urlparts  = wp_parse_url( $image['thumbnail_src'] );
					$pathparts = explode( '/', $urlparts['path'] );
					array_splice( $pathparts, 3, 0, array( 's160x160' ) );
					$image['thumbnail'] = '//' . $urlparts['host'] . implode( '/', $pathparts );
					$pathparts[3]       = 's240x240';
					$image['small']     = '//' . $urlparts['host'] . implode( '/', $pathparts );
				}

				$image['large'] = $image['thumbnail_src'];

				if ( $image['is_video'] == true ) {
					$type = 'video';
				} else {
					$type = 'image';
				}

				$instagram[] = array(
					'description' => $image['caption'],
					'link'        => trailingslashit( '//instagram.com/p/' . $image['code'] ),
					'time'        => $image['date'],
					'comments'    => $image['comments']['count'],
					'likes'       => $image['likes']['count'],
					'thumbnail'   => $image['thumbnail'],
					'small'       => $image['small'],
					'large'       => $image['large'],
					'original'    => $image['display_src'],
					'type'        => $type,
				);
			}

			// do not set an empty transient - should help catch private or empty accounts
			if ( ! empty( $instagram ) ) {
				$instagram = serialize( $instagram );
				set_transient( $transient_key, $instagram, 2 * 3600 );
			}
		}

		if ( ! empty( $instagram ) ) {
			return unserialize( $instagram );
		} else {
			return new WP_Error( 'no_images', esc_html__( 'Instagram did not return any images.', 'baroque-addons' ) );
		}
	}

	/**
	 * Filter images only
	 *
	 * @param array $item
	 *
	 * @return bool
	 */
	protected function image_only_filter( $item ) {
		return $item['type'] == 'image';
	}

	/**
	 * Get limited words from given string.
	 * Strips all tags and shortcodes from string.
	 *
	 * @since 1.0.0
	 *
	 * @param integer $num_words The maximum number of words
	 * @param string  $more      More link.
	 *
	 * @return string|void Limited content.
	 */
	protected function baroque_addons_content_limit( $content, $num_words, $more = "&hellip;" ) {
		// Strip tags and shortcodes so the content truncation count is done correctly
		$content = strip_tags( strip_shortcodes( $content ), apply_filters( 'baroque_content_limit_allowed_tags', '<script>,<style>' ) );

		// Remove inline styles / scripts
		$content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );

		// Truncate $content to $max_char
		$content = wp_trim_words( $content, $num_words );

		if ( $more ) {
			$output = sprintf(
				'<p>%s <a href="%s" class="more-link" title="%s">%s</a></p>',
				$content,
				get_permalink(),
				sprintf( esc_html__( 'Continue reading &quot;%s&quot;', 'baroque-addons' ), the_title_attribute( 'echo=0' ) ),
				esc_html( $more )
			);
		} else {
			$output = sprintf( '<p>%s</p>', $content );
		}

		return $output;
	}

	protected function baroque_addons_btn( $atts ) {
		$css_class = array(
			'ba-button',
			'text-' . $atts['align'],
			$atts['style'],
			$atts['style'] == 'classic' ? $atts['button_background_color'] . '-color' : '',
			$atts['style'] == 'outline' ? $atts['button_color'] . '-color' : '',
			$atts['el_class'],
		);

		$attributes = array();
		$icon       = '';

		if ( $atts['icon_ionicons'] ) {
			$icon = sprintf( '<i class="%s"></i>', esc_attr( $atts['icon_ionicons'] ) );
		}

		$attributes['class'] = 'button';

		if ( $atts['style'] == 'classic' ) {
			if ( $atts['button_background_color'] == 'primary' ) {
				$attributes['class'] .= ' btn-primary';
			} else {
				$attributes['class'] .= ' btn-secondary';
			}
		}

		if ( $atts['font_size'] ) {
			$attributes['style'] = 'font-size:' . $atts['font_size'] . 'px;';
		}

		$link = vc_build_link( $atts['link'] );

		if ( ! empty( $link['url'] ) ) {
			$attributes['href'] = $link['url'];
		}

		$label = $link['title'];

		if ( ! $label ) {
			$attributes['title'] = $label;
		}

		if ( ! empty( $link['target'] ) ) {
			$attributes['target'] = $link['target'];
		}

		if ( ! empty( $link['rel'] ) ) {
			$attributes['rel'] = $link['rel'];
		}

		$attr = array();

		foreach ( $attributes as $name => $v ) {
			$attr[] = $name . '="' . esc_attr( $v ) . '"';
		}

		$button = sprintf(
			'<%1$s %2$s>%3$s%4$s</%1$s>',
			empty( $attributes['href'] ) ? 'span' : 'a',
			implode( ' ', $attr ),
			$label,
			$icon
		);

		return sprintf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$button
		);
	}

	function baroque_addons_get_socials() {
		$socials = array(
			'facebook'   => esc_html__( 'Facebook', 'baroque-addons' ),
			'twitter'    => esc_html__( 'Twitter', 'baroque-addons' ),
			'google'     => esc_html__( 'Google', 'baroque-addons' ),
			'tumblr'     => esc_html__( 'Tumblr', 'baroque-addons' ),
			'flickr'     => esc_html__( 'Flickr', 'baroque-addons' ),
			'vimeo'      => esc_html__( 'Vimeo', 'baroque-addons' ),
			'youtube'    => esc_html__( 'Youtube', 'baroque-addons' ),
			'linkedin'   => esc_html__( 'LinkedIn', 'baroque-addons' ),
			'pinterest'  => esc_html__( 'Pinterest', 'baroque-addons' ),
			'dribbble'   => esc_html__( 'Dribbble', 'baroque-addons' ),
			'spotify'    => esc_html__( 'Spotify', 'baroque-addons' ),
			'instagram'  => esc_html__( 'Instagram', 'baroque-addons' ),
			'tumbleupon' => esc_html__( 'Tumbleupon', 'baroque-addons' ),
			'wordpress'  => esc_html__( 'WordPress', 'baroque-addons' ),
			'rss'        => esc_html__( 'Rss', 'baroque-addons' ),
			'deviantart' => esc_html__( 'Deviantart', 'baroque-addons' ),
			'share'      => esc_html__( 'Share', 'baroque-addons' ),
			'skype'      => esc_html__( 'Skype', 'baroque-addons' ),
			'behance'    => esc_html__( 'Behance', 'baroque-addons' ),
			'apple'      => esc_html__( 'Apple', 'baroque-addons' ),
			'yelp'       => esc_html__( 'Yelp', 'baroque-addons' ),
		);

		return apply_filters( 'baroque_addons_get_socials', $socials );
	}

	/**
	 * @param $atts
	 *
	 * @return string
	 */
	function get_portfolio( $atts ) {
		$html = array();

		$args = array(
			'post_type'           => 'portfolio',
			'posts_per_page'      => intval( $atts['per_page'] ),
			'paged'               => absint( $atts['page'] ),
			'ignore_sticky_posts' => true
		);

		$attr = array(
			'per_page' => intval( $atts['per_page'] ),
			'orderby'  => $atts['orderby'],
			'order'    => $atts['order'],
		);

		if ( $atts['cats'] ) {
			$cats = explode( ',', $atts['cats'] );

			$args['tax_query'] = array(
				array(
					'taxonomy' => 'portfolio_category',
					'field'    => 'slug',
					'terms'    => $cats,
				),
			);
		}

		if ( $atts['source'] == '1' ) {
			$args['orderby'] = $atts['orderby'];
			$args['order']   = $atts['order'];
		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids              = explode( ',', $atts['ids'] );
			$args['post__in'] = $ids;
			$args['orderby']  = 'post__in';
		}

		$index = 1;

		$query = new WP_Query( $args );
		$row   = $atts['style'] == 'carousel' ? '' : 'row';

		$html[] = '<div class="portfolio-frame">';
		$html[] = '<div class="list-portfolio ' . $row . '">';

		while ( $query->have_posts() ) : $query->the_post();
			global $ba_portfolio_attr;

			$ba_portfolio_attr['style'] = $atts['style'];
			$ba_portfolio_attr['index'] = $index;

			ob_start();

			get_template_part( 'parts/content', 'portfolio' );

			$html[] = ob_get_clean();

			$index ++;

		endwhile;

		$html[] = '</div>';

		$html[] = '</div>';

		if ( isset( $atts['load_more'] ) && $atts['load_more'] && $query->max_num_pages > 1 ) {
			$paged = max( 1, $query->get( 'paged' ) );

			if ( $paged < $query->max_num_pages ) {
				$button = sprintf(
					'<div class="load-more text-center">
						<a href="#" class="button ajax-load-portfolio" data-page="%s" data-style="%s" data-attr="%s" data-nonce="%s" rel="nofollow">
							<span class="nav-text">%s</span>
								<span class="loading-icon">
									<span class="bubble">
										<span class="dot"></span>
									</span>
									<span class="bubble">
										<span class="dot"></span>
									</span>
									<span class="bubble">
										<span class="dot"></span>
									</span>
								</span>
							</span>
						</a>
					</div>',
					esc_attr( $paged + 1 ),
					esc_attr( $atts['style'] ),
					esc_attr( json_encode( $attr ) ),
					esc_attr( wp_create_nonce( 'baroque_get_portfolio' ) ),
					esc_html__( 'More', 'baroque-addons' )
				);

				$html[] = $button;
			}
		}

		wp_reset_postdata();

		return implode( '', $html );
	}
}
