<?php
/**
 * Custom functions for Visual Composer
 *
 * @package    Baroque
 * @subpackage Visual Composer
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/**
 * Class Baroque
 *
 * @since 1.0.0
 */
class Baroque_VC {

	/**
	 * Construction
	 */
	function __construct() {
		// Stop if VC is not installed
		if ( ! is_plugin_active( 'js_composer/js_composer.php' ) ) {
			return false;
		}

		add_filter( 'vc_autocomplete_baroque_portfolios_grid_gap_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_baroque_portfolios_grid_gap_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_baroque_portfolios_grid_gap_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_baroque_portfolios_grid_gap_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_baroque_portfolios_grid_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_baroque_portfolios_grid_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_baroque_portfolios_grid_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_baroque_portfolios_grid_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_iconpicker-type-ionicons', array( $this, 'vc_iconpicker_type_ionicons' ) );

		add_action( 'vc_base_register_front_css', array( $this, 'vc_iconpicker_base_register_css' ) );
		add_action( 'vc_base_register_admin_css', array( $this, 'vc_iconpicker_base_register_css' ) );

		add_action( 'vc_enqueue_font_icon_element', array( $this, 'vc_icon_element_fonts_enqueue' ) );

		add_action( 'init', array( $this, 'map_shortcodes' ), 20 );
		add_action( 'init', array( $this, 'modify_element' ), 25 );
	}

	function modify_element() {
		// Add new option to Custom Header element
		vc_add_param(
			'vc_custom_heading', array(
				'heading'     => esc_html__( 'Letter Spacing', 'baroque' ),
				'description' => esc_html__( 'Enter letter spacing', 'baroque' ),
				'type'        => 'textfield',
				'param_name'  => 'letter_spacing',
				'value'       => '',
			)
		);
		vc_add_param(
			'vc_custom_heading', array(
				'heading'     => esc_html__( 'Font Weight', 'baroque' ),
				'description' => esc_html__( 'Enter font weight', 'baroque' ),
				'type'        => 'textfield',
				'param_name'  => 'font_weight',
				'value'       => '',
				'dependency'  => array(
					'element' => 'use_theme_fonts',
					'value'   => 'yes',
				),
			)
		);
	}


	/**
	 * Add new params or add new shortcode to VC
	 *
	 * @since 1.0
	 *
	 * @return void
	 */
	function map_shortcodes() {

		vc_remove_param( 'vc_row', 'parallax_image' );
		vc_remove_param( 'vc_row', 'parallax' );
		vc_remove_param( 'vc_row', 'parallax_speed_bg' );

		$attributes = array(
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Enable Parallax effect', 'baroque' ),
				'param_name'  => 'enable_parallax',
				'group'       => esc_html__( 'Design Options', 'baroque' ),
				'value'       => array( esc_html__( 'Enable', 'baroque' ) => 'yes' ),
				'description' => esc_html__( 'Enable this option if you want to have parallax effect on this row. When you enable this option, please set background repeat option as "Theme defaults" to make it works.', 'baroque' ),
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Overlay', 'baroque' ),
				'param_name'  => 'overlay',
				'group'       => esc_html__( 'Design Options', 'baroque' ),
				'value'       => '',
				'description' => esc_html__( 'Select an overlay color for this row', 'baroque' ),
			),
		);

		vc_add_params( 'vc_row', $attributes );

		// Button
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Button', 'baroque' ),
				'base'     => 'baroque_button',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'URL (Link)', 'baroque' ),
						'type'       => 'vc_link',
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Font Size (px)', 'baroque' ),
						'param_name'  => 'font_size',
						'admin_label' => true,
						'description' => esc_html__( 'Enter button font size.', 'baroque' )
					),
					array(
						'heading'     => esc_html__( 'Alignment', 'baroque' ),
						'description' => esc_html__( 'Select button alignment', 'baroque' ),
						'param_name'  => 'align',
						'type'        => 'dropdown',
						'value'       => array(
							esc_html__( 'Left', 'baroque' )   => 'left',
							esc_html__( 'Center', 'baroque' ) => 'center',
							esc_html__( 'Right', 'baroque' )  => 'right',
						),
					),
					array(
						'heading'     => esc_html__( 'Style', 'baroque' ),
						'description' => esc_html__( 'Select button style', 'baroque' ),
						'param_name'  => 'style',
						'type'        => 'dropdown',
						'value'       => array(
							esc_html__( 'Classic', 'baroque' ) => 'classic',
							esc_html__( 'Outline', 'baroque' ) => 'outline',
						),
					),
					array(
						'heading'     => esc_html__( 'Background Color', 'baroque' ),
						'description' => esc_html__( 'Select button background color', 'baroque' ),
						'param_name'  => 'button_background_color',
						'type'        => 'dropdown',
						'value'       => array(
							esc_html__( 'Primary Color', 'baroque' ) => 'primary',
							esc_html__( 'Transparent', 'baroque' )   => 'light',
						),
						'dependency'  => array(
							'element' => 'style',
							'value'   => 'classic',
						),
					),
					array(
						'heading'     => esc_html__( 'Color', 'baroque' ),
						'description' => esc_html__( 'Select button color', 'baroque' ),
						'param_name'  => 'button_color',
						'type'        => 'dropdown',
						'value'       => array(
							esc_html__( 'Dark', 'baroque' )  => 'dark',
							esc_html__( 'Light', 'baroque' ) => 'light',
						),
						'dependency'  => array(
							'element' => 'style',
							'value'   => 'outline',
						),
					),
					array(
						'heading'     => esc_html__( 'Button Icon', 'baroque' ),
						'description' => esc_html__( 'Select icon from library.', 'baroque' ),
						'type'        => 'iconpicker',
						'param_name'  => 'icon_ionicons',
						'value'       => '',
						'settings'    => array(
							'emptyIcon'    => true,
							'iconsPerPage' => 4000,
							'type'         => 'ionicons',
						),
					),
					array(
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
						'param_name'  => 'el_class',
						'type'        => 'textfield',
						'value'       => '',
					),
				),
			)
		);

		// Empty Space
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Empty Space', 'baroque' ),
				'base'     => 'baroque_empty_space',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height(px)', 'baroque' ),
						'param_name'  => 'height',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Desktop.', 'baroque' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height on Tablet(px)', 'baroque' ),
						'param_name'  => 'height_tablet',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Mobile. Leave empty to use the height of the desktop', 'baroque' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height on Mobile(px)', 'baroque' ),
						'param_name'  => 'height_mobile',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Mobile. Leave empty to use the height of the tablet', 'baroque' )
					),
					array(
						'type'       => 'colorpicker',
						'heading'    => esc_html__( 'Background Color', 'baroque' ),
						'param_name' => 'bg_color',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Add custom single image
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Single Image', 'baroque' ),
				'base'     => 'baroque_single_image',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'baroque' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'baroque' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'baroque' )
					),
					array(
						'heading'     => esc_html__( 'Alignment', 'baroque' ),
						'description' => esc_html__( 'Select image alignment', 'baroque' ),
						'param_name'  => 'align',
						'type'        => 'dropdown',
						'value'       => array(
							esc_html__( 'Left', 'baroque' )   => 'left',
							esc_html__( 'Center', 'baroque' ) => 'center',
							esc_html__( 'Right', 'baroque' )  => 'right',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Latest Post
		vc_map(
			array(
				'name'     => esc_html__( 'Latest Post', 'baroque' ),
				'base'     => 'baroque_latest_post',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Number of Posts', 'baroque' ),
						'param_name'  => 'number',
						'value'       => '3',
						'description' => esc_html__( 'Set numbers of Posts you want to display. Set -1 to display all posts', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Read More Button', 'baroque' ),
						'param_name' => 'read_more',
						'value'      => esc_html__( 'MORE', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Hero Slider
		vc_map(
			array(
				'name'            => esc_html__( 'Hero Slider', 'baroque' ),
				'base'            => 'baroque_hero_slider',
				'category'        => esc_html__( 'Baroque', 'baroque' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Full Width', 'baroque' ),
						'param_name' => 'full_width',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Color', 'baroque' ),
						'param_name' => 'color',
						'value'      => array(
							esc_html__( 'Light', 'baroque' ) => 'light',
							esc_html__( 'Dark', 'baroque' )  => 'dark',
						),
					),
					array(
						'heading'    => esc_html__( 'Sliders', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'sliders',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'baroque' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'baroque' ),
							),
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'Sub Title', 'baroque' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'vc_link',
								'heading'    => esc_html__( 'Link', 'baroque' ),
								'param_name' => 'link',
								'value'      => '',
							),

						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Service
		vc_map(
			array(
				'name'     => esc_html__( 'Service', 'baroque' ),
				'base'     => 'baroque_service',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Style', 'baroque' ),
						'param_name' => 'style',
						'type'       => 'dropdown',
						'value'      => array(
							esc_html__( 'Style 1', 'baroque' ) => '1',
							esc_html__( 'Style 2', 'baroque' ) => '2',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Content Position', 'baroque' ),
						'param_name' => 'position',
						'value'      => array(
							esc_html__( 'Left', 'baroque' )  => 'left',
							esc_html__( 'Right', 'baroque' ) => 'right',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => '1',
						),
					),
					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Title', 'baroque' ),
						'param_name'  => 'title',
						'value'       => '',
						'admin_label' => true,
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Sub Title', 'baroque' ),
						'param_name' => 'sub_title',
						'value'      => '',
					),
					array(
						'heading'     => esc_html__( 'Image', 'baroque' ),
						'description' => esc_html__( 'Upload service image', 'baroque' ),
						'type'        => 'attach_image',
						'param_name'  => 'service_image',
						'value'       => '',
					),
					array(
						'heading'     => esc_html__( 'Image size', 'baroque' ),
						'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'baroque' ),
						'type'        => 'textfield',
						'param_name'  => 'image_size',
						'value'       => '',
					),
					array(
						'heading'    => esc_html__( 'Service Link', 'baroque' ),
						'param_name' => 'link',
						'type'       => 'vc_link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Carousel
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolio', 'baroque' ),
				'base'     => 'baroque_portfolio',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Number of Portfolio', 'baroque' ),
						'param_name'  => 'number',
						'value'       => 'All',
						'description' => esc_html__( 'Set numbers of Portfolio you want to display. Set -1 to display all portfolio', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Read More Text', 'baroque' ),
						'param_name' => 'read_more',
						'value'      => esc_html__( 'SEE PROJECT', 'baroque' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Autoplay', 'baroque' ),
						'param_name'  => 'autoplay',
						'value'       => array( esc_html__( 'Yes', 'baroque' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" Enable autoplay', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Autoplay speed', 'baroque' ),
						'param_name'  => 'autoplay_speed',
						'value'       => '800',
						'description' => esc_html__( 'Set auto play speed (in ms).', 'baroque' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Navigation', 'baroque' ),
						'param_name'  => 'nav',
						'value'       => array( esc_html__( 'Yes', 'baroque' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" Enable navigation', 'baroque' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Dots', 'baroque' ),
						'param_name'  => 'dot',
						'value'       => array( esc_html__( 'Yes', 'baroque' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" Enable dots', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Image Box
		vc_map(
			array(
				'name'     => esc_html__( 'Image Box', 'baroque' ),
				'base'     => 'baroque_image_box',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Title', 'baroque' ),
						'param_name'  => 'title',
						'value'       => '',
						'admin_label' => true,
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Sub Title', 'baroque' ),
						'param_name' => 'sub_title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Date', 'baroque' ),
						'param_name' => 'date',
						'value'      => '',
					),
					array(
						'heading'     => esc_html__( 'Image', 'baroque' ),
						'description' => esc_html__( 'Upload service image', 'baroque' ),
						'type'        => 'attach_image',
						'param_name'  => 'image',
						'value'       => '',
					),
					array(
						'heading'     => esc_html__( 'Image size', 'baroque' ),
						'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'baroque' ),
						'type'        => 'textfield',
						'param_name'  => 'image_size',
						'value'       => '',
					),
					array(
						'heading'    => esc_html__( 'Link', 'baroque' ),
						'param_name' => 'link',
						'type'       => 'vc_link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Counter
		vc_map(
			array(
				'name'     => esc_html__( 'Counter', 'baroque' ),
				'base'     => 'baroque_counter',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Color Scheme', 'baroque' ),
						'param_name' => 'color_scheme',
						'type'       => 'dropdown',
						'value'      => array(
							esc_html__( 'Dark', 'baroque' )  => 'dark',
							esc_html__( 'Light', 'baroque' ) => 'light',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'baroque' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '1 Columns', 'baroque' ) => '1',
							esc_html__( '2 Columns', 'baroque' ) => '2',
							esc_html__( '3 Columns', 'baroque' ) => '3',
							esc_html__( '4 Columns', 'baroque' ) => '4',
						),
					),
					array(
						'type'       => 'param_group',
						'heading'    => esc_html__( 'Counter Option', 'baroque' ),
						'value'      => '',
						'param_name' => 'counter_option',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Counter Value', 'baroque' ),
								'param_name'  => 'value',
								'value'       => '',
								'description' => esc_html__( 'Input integer value for counting', 'baroque' ),
							),
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'value'       => '',
								'description' => esc_html__( 'Enter the title of this box', 'baroque' ),
								'admin_label' => true,
							),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Partner
		vc_map(
			array(
				'name'     => esc_html__( 'Partners', 'baroque' ),
				'base'     => 'baroque_partner',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Effect Hover', 'baroque' ),
						'param_name'  => 'effect',
						'value'       => array(
							esc_html__( 'None', 'baroque' )     => 'none',
							esc_html__( 'Effect 1', 'baroque' ) => '1',
							esc_html__( 'Effect 2', 'baroque' ) => '2',
						),
						'description' => esc_html__( 'Choose effect when hover on image', 'baroque' ),
					),
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Images', 'baroque' ),
						'param_name'  => 'images',
						'value'       => '',
						'description' => esc_html__( 'Choose images from media library', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'baroque' ),
						'param_name'  => 'image_size',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'baroque' ),
					),
					array(
						'type'        => 'exploded_textarea_safe',
						'heading'     => esc_html__( 'Custom links', 'baroque' ),
						'param_name'  => 'custom_links',
						'description' => esc_html__( 'Enter links for each slide here. Divide links with linebreaks (Enter).', 'baroque' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Custom link target', 'baroque' ),
						'param_name'  => 'custom_links_target',
						'value'       => array(
							esc_html__( 'Same window', 'baroque' ) => '_self',
							esc_html__( 'New window', 'baroque' )  => '_blank',
						),
						'description' => esc_html__( 'Select where to open custom links.', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Member
		vc_map(
			array(
				'name'     => esc_html__( 'Member', 'baroque' ),
				'base'     => 'baroque_member',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'baroque' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Name', 'baroque' ),
						'param_name' => 'name',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Job', 'baroque' ),
						'param_name' => 'job',
						'value'      => '',
					),
					array(
						'heading'    => esc_html__( 'Socials', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials',
						'params'     => array(
							array(
								'heading'     => esc_html__( 'Icon', 'baroque' ),
								'description' => esc_html__( 'Select icon from library.', 'baroque' ),
								'type'        => 'iconpicker',
								'param_name'  => 'icon_ionicons',
								'value'       => '',
								'settings'    => array(
									'emptyIcon'    => true,
									'iconsPerPage' => 4000,
									'type'         => 'ionicons',
								),
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'baroque' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Introduction', 'baroque' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Quote
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Quote', 'baroque' ),
				'base'     => 'baroque_portfolio_quote',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Hide Border', 'baroque' ),
						'param_name' => 'hide_border',
						'value'      => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'baroque' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Author', 'baroque' ),
						'param_name' => 'author',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Cite', 'baroque' ),
						'param_name' => 'cite',
						'value'      => '',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Content', 'baroque' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Images
		vc_map(
			array(
				'name'     => __( 'Gallery Images', 'baroque' ),
				'base'     => 'baroque_portfolio_images',
				'class'    => '',
				'category' => __( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Gallery Type', 'baroque' ),
						'param_name' => 'type',
						'value'      => array(
							esc_html__( 'Slider Slide', 'baroque' ) => 'slide',
							esc_html__( 'Slider fade', 'baroque' )  => 'fade',
							esc_html__( 'Image grid', 'baroque' )   => 'normal',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'baroque' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '1 Columns', 'baroque' ) => '1',
							esc_html__( '2 Columns', 'baroque' ) => '2',
							esc_html__( '3 Columns', 'baroque' ) => '3',
						),
						'dependency' => array(
							'element' => 'type',
							'value'   => 'normal',
						),
					),
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Images', 'baroque' ),
						'param_name'  => 'images',
						'value'       => '',
						'description' => esc_html__( 'Choose images from media library', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'baroque' ),
						'param_name'  => 'image_size',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'baroque' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Popup', 'baroque' ),
						'param_name'  => 'popup',
						'value'       => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'description' => esc_html__( 'Enable Popup feature when click on Image', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Meta
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolio Meta', 'baroque' ),
				'base'     => 'baroque_portfolio_meta',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Show Categories', 'baroque' ),
						'param_name'       => 'cats',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Show Tags', 'baroque' ),
						'param_name'       => 'tags',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Show Socials', 'baroque' ),
						'param_name'       => 'socials',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'       => 'param_group',
						'heading'    => esc_html__( 'Portfolio Meta', 'baroque' ),
						'value'      => '',
						'param_name' => 'meta',
						'params'     => array(
							array(
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'type'        => 'textfield',
								'value'       => '',
								'admin_label' => true,
							),
							array(
								'heading'    => esc_html__( 'Value', 'baroque' ),
								'param_name' => 'value',
								'type'       => 'textfield',
								'value'      => '',
							),
						),
					),
					array(
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'type'        => 'textfield',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Grid Gap
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios Grid Gap', 'baroque' ),
				'base'     => 'baroque_portfolios_grid_gap',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'baroque' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'baroque' ) => '1',
							esc_html__( 'Custom', 'baroque' )  => '2',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'baroque' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'baroque' ),
						'param_name'  => 'per_page',
						'value'       => '9',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'baroque' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'baroque' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                    => '',
							esc_html__( 'Date', 'baroque' )       => 'date',
							esc_html__( 'Title', 'baroque' )      => 'title',
							esc_html__( 'Menu Order', 'baroque' ) => 'menu_order',
							esc_html__( 'Random', 'baroque' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'baroque' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                     => '',
							esc_html__( 'Ascending ', 'baroque' )  => 'asc',
							esc_html__( 'Descending ', 'baroque' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'baroque' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios', 'baroque' ),
				'base'     => 'baroque_portfolios_grid',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Style', 'baroque' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Grid', 'baroque' )      => 'grid',
							esc_html__( 'Grid Wide', 'baroque' ) => 'grid-wide',
							esc_html__( 'Masonry', 'baroque' )   => 'masonry',
							esc_html__( 'Metro', 'baroque' )     => 'metro',
							esc_html__( 'Carousel', 'baroque' )  => 'carousel',
						),
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Scrollbar', 'baroque' ),
						'param_name'       => 'scrollbar',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'dependency'       => array(
							'element' => 'style',
							'value'   => array( 'carousel' ),
						),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Arrow', 'baroque' ),
						'param_name'       => 'arrows',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'dependency'       => array(
							'element' => 'style',
							'value'   => array( 'carousel' ),
						),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Dots', 'baroque' ),
						'param_name'       => 'dots',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'dependency'       => array(
							'element' => 'style',
							'value'   => array( 'carousel' ),
						),
						'edit_field_class' => 'vc_col-xs-4',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'baroque' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'baroque' ) => '1',
							esc_html__( 'Custom', 'baroque' )  => '2',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'baroque' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Enable Filter', 'baroque' ),
						'param_name'       => 'enable_filter',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'dependency'       => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
						'std'              => '1',
						'edit_field_class' => 'vc_col-xs-6',
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Load More', 'baroque' ),
						'param_name'       => 'load_more',
						'value'            => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
						'dependency'       => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
						'edit_field_class' => 'vc_col-xs-6',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'baroque' ),
						'param_name'  => 'per_page',
						'value'       => '9',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'baroque' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'baroque' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                    => '',
							esc_html__( 'Date', 'baroque' )       => 'date',
							esc_html__( 'Title', 'baroque' )      => 'title',
							esc_html__( 'Menu Order', 'baroque' ) => 'menu_order',
							esc_html__( 'Random', 'baroque' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'baroque' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                     => '',
							esc_html__( 'Ascending ', 'baroque' )  => 'asc',
							esc_html__( 'Descending ', 'baroque' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'baroque' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'baroque' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Vertical Slider
		vc_map(
			array(
				'name'     => esc_html__( 'Vertical Slider', 'baroque' ),
				'base'     => 'baroque_vsslider',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'baroque' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'baroque' ),
							),
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'baroque' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Description', 'baroque' ),
								'param_name' => 'desc',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link', 'baroque' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Title Background Effect', 'baroque' ),
						'param_name' => 'title_bg',
						'value'      => array( esc_html__( 'Yes', 'baroque' ) => '1' ),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button Link', 'baroque' ),
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'baroque' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		vc_map(
			array(
				'name'     => esc_html__( 'Vertical Slider 2', 'baroque' ),
				'base'     => 'baroque_vsslider2',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'baroque' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'baroque' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'baroque' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link(URL)', 'baroque' ),
								'param_name' => 'item_link',
							),
						)
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button Link', 'baroque' ),
						'param_name' => 'button_link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'baroque' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Horizontal Swipe Slider
		vc_map(
			array(
				'name'     => esc_html__( 'Horizontal Slider', 'baroque' ),
				'base'     => 'baroque_hsslider',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'baroque' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'baroque' ),
							),
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'Area', 'baroque' ),
								'param_name' => 'area',
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'Location', 'baroque' ),
								'param_name' => 'location',
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'Year', 'baroque' ),
								'param_name' => 'year',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link', 'baroque' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'baroque' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider Height(px)', 'baroque' ),
						'param_name'  => 'height',
						'value'       => '726',
						'description' => esc_html__( 'Enter height in pixel for slider', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Portfolio List
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios List', 'baroque' ),
				'base'     => 'baroque_portfolios_list',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'baroque' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'baroque' ) => '1',
							esc_html__( 'Style 2', 'baroque' ) => '2'
						),
					),
					array(
						'heading'    => esc_html__( 'Items', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'baroque' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'baroque' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'baroque' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'baroque' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link(URL)', 'baroque' ),
								'param_name' => 'link',
							),
							array(
								'type'        => 'dropdown',
								'heading'     => esc_html__( 'Text Color', 'baroque' ),
								'param_name'  => 'text_color',
								'value'       => array(
									esc_html__( 'Dark', 'baroque' )  => 'dark',
									esc_html__( 'Light', 'baroque' ) => 'light',
								),
								'description' => esc_html__( 'Choose text color when hover item. This option is only used for style 1', 'baroque' ),
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Add newsletter shortcode - get form id of mailchimp
		$mail_forms    = get_posts( 'post_type=mc4wp-form&posts_per_page=-1' );
		$mail_form_ids = array(
			esc_html__( 'Select Form', 'baroque' ) => '',
		);
		foreach ( $mail_forms as $form ) {
			$mail_form_ids[$form->post_title] = $form->ID;
		}
		vc_map(
			array(
				'name'     => esc_html__( 'Newsletter', 'baroque' ),
				'base'     => 'baroque_newsletter',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Mailchimp Form', 'baroque' ),
						'param_name' => 'form',
						'value'      => $mail_form_ids,
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'baroque' ),
					),
				),
			)
		);

		// Coming soon shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Coming Soon', 'baroque' ),
				'base'     => 'baroque_coming_soon',
				'class'    => '',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Date', 'baroque' ),
						'param_name'  => 'date',
						'value'       => '',
						'description' => esc_html__( 'Enter the date by format: YYYY-MM-DD', 'baroque' ),
					),
					array(
						'heading'    => esc_html__( 'Text Color', 'baroque' ),
						'param_name' => 'text_color',
						'type'       => 'dropdown',
						'value'      => array(
							esc_html__( 'Dark', 'baroque' )  => 'dark',
							esc_html__( 'Light', 'baroque' ) => 'light',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'baroque' ),
					),
				),
			)
		);


		/*
		 * Revolution Slider
		 */
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Revolution Slider', 'baroque' ),
				'base'     => 'baroque_revslider',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Revolution Slider', 'baroque' ),
						'param_name'  => 'sliders',
						'value'       => $this->rev_sliders(),
						'description' => esc_html__( 'Select your Revolution Slider.', 'baroque' ),
					),
					array(
						'heading'    => esc_html__( 'Socials', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials',
						'params'     => array(
							array(
								'heading'     => esc_html__( 'Icon', 'baroque' ),
								'description' => esc_html__( 'Select icon from library.', 'baroque' ),
								'type'        => 'iconpicker',
								'param_name'  => 'icon_ionicons',
								'value'       => '',
								'settings'    => array(
									'emptyIcon'    => true,
									'iconsPerPage' => 4000,
									'type'         => 'ionicons',
								),
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'baroque' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Text', 'baroque' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'baroque' ),
					),
				),
			)
		);

		/*
		 * Call to Action
		 */
		vc_map(
			array(
				'name'     => esc_html__( 'Baroque Call to Action', 'baroque' ),
				'base'     => 'baroque_cta',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Color Scheme', 'baroque' ),
						'param_name' => 'color_scheme',
						'type'       => 'dropdown',
						'value'      => array(
							esc_html__( 'Light', 'baroque' ) => 'light',
							esc_html__( 'Dark', 'baroque' )  => 'dark',
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Background Image', 'baroque' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'baroque' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Background Color', 'baroque' ),
						'param_name'  => 'bg_color',
						'value'       => '',
						'description' => esc_html__( 'Select background color for cta', 'baroque' ),
					),
					array(
						'heading'    => esc_html__( 'Socials', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials',
						'params'     => array(
							array(
								'heading'     => esc_html__( 'Icon', 'baroque' ),
								'description' => esc_html__( 'Select icon from library.', 'baroque' ),
								'type'        => 'iconpicker',
								'param_name'  => 'icon_ionicons',
								'value'       => '',
								'settings'    => array(
									'emptyIcon'    => true,
									'iconsPerPage' => 4000,
									'type'         => 'ionicons',
								),
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'baroque' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'       => 'textfield',
						'value'      => '',
						'heading'    => esc_html__( 'Title', 'baroque' ),
						'param_name' => 'title',
					),
					array(
						'type'       => 'textfield',
						'value'      => '',
						'heading'    => esc_html__( 'SubTitle', 'baroque' ),
						'param_name' => 'subtitle',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Text', 'baroque' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'baroque' ),
					),
				),
			)
		);

		// GG maps

		vc_map(
			array(
				'name'     => esc_html__( 'Google Maps', 'baroque' ),
				'base'     => 'baroque_gmap',
				'category' => esc_html__( 'Baroque', 'baroque' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Api Key', 'baroque' ),
						'param_name'  => 'api_key',
						'value'       => '',
						'description' => sprintf( __( 'Please go to <a href="%s">Google Maps APIs</a> to get a key', 'baroque' ), esc_url( 'https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key' ) ),
						'group'       => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'heading'    => esc_html__( 'Select method to find location', 'baroque' ),
						'param_name' => 'method',
						'type'       => 'dropdown',
						'value'      => array(
							esc_html__( 'Address Details', 'baroque' ) => 'address',
							esc_html__( 'Coordinates', 'baroque' )     => 'coordinates',
						),
						'group'      => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Address Details', 'baroque' ),
						'param_name' => 'location',
						'group'      => esc_html__( 'Map', 'baroque' ),
						'dependency' => array(
							'element' => 'method',
							'value'   => 'address',
						),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Lat', 'baroque' ),
						'param_name'       => 'lat',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Map', 'baroque' ),
						'dependency'       => array(
							'element' => 'method',
							'value'   => 'coordinates',
						),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Lng', 'baroque' ),
						'param_name'       => 'lng',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Map', 'baroque' ),
						'dependency'       => array(
							'element' => 'method',
							'value'   => 'coordinates',
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Marker', 'baroque' ),
						'param_name'  => 'marker',
						'value'       => '',
						'description' => esc_html__( 'Choose an image from media library', 'baroque' ),
						'group'       => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Width(px)', 'baroque' ),
						'param_name' => 'width',
						'value'      => '',
						'group'      => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Height(px)', 'baroque' ),
						'param_name' => 'height',
						'value'      => '880',
						'group'      => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Zoom', 'baroque' ),
						'param_name' => 'zoom',
						'value'      => '13',
						'group'      => esc_html__( 'Map', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'baroque' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'baroque' ),
						'group'       => esc_html__( 'Map', 'baroque' ),
					),

					// Address Information
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button', 'baroque' ),
						'param_name' => 'map_btn',
						'group'      => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Address', 'baroque' ),
						'param_name'  => 'address',
						'group'       => esc_html__( 'Address Information', 'baroque' ),
						'description' => esc_html__( 'Enter the address in this format "A|B" and the A element is BOLD.', 'cargohub' ),
						'admin_label' => true,
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Address Details', 'baroque' ),
						'param_name' => 'details',
						'group'      => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Email Label', 'baroque' ),
						'param_name'       => 'email_label',
						'value'            => esc_html__( 'Email:', 'baroque' ),
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Email', 'baroque' ),
						'param_name'       => 'email',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Phone Label', 'baroque' ),
						'param_name'       => 'phone_label',
						'value'            => esc_html__( 'Call directly:', 'baroque' ),
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Phone Number', 'baroque' ),
						'param_name'       => 'phone',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-6',
						'group'            => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Brand Offices Label', 'baroque' ),
						'param_name' => 'brand_offices_label',
						'value'      => esc_html__( 'Brand Offices:', 'baroque' ),
						'group'      => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'heading'    => esc_html__( 'Brand Offices', 'baroque' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'brand_offices',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Brand Office', 'baroque' ),
								'param_name'  => 'brand_office',
								'value'       => '',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'baroque' ),
								'param_name' => 'link',
							),
						),
						'group'      => esc_html__( 'Address Information', 'baroque' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Enter Form Shortcode', 'baroque' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => sprintf( __( 'Please go to <a href="%s">Contact</a> to get form shortcode', 'baroque' ), admin_url( 'admin.php?page=page=wpcf7' ) ),
						'group'       => esc_html__( 'Form', 'baroque' ),
					),
				),
			)
		);
	}

	/**
	 * Get Revolution Sliders
	 */
	function rev_sliders() {

		if ( ! class_exists( 'RevSlider' ) ) {
			return;
		}

		$slider     = new RevSlider();
		$arrSliders = $slider->getArrSliders();

		$revsliders = array();
		if ( $arrSliders ) {
			$revsliders[esc_html__( 'Choose a slider', 'baroque' )] = 0;
			foreach ( $arrSliders as $slider ) {
				$revsliders[$slider->getTitle()] = $slider->getAlias();
			}
		} else {
			$revsliders[esc_html__( 'No sliders found', 'baroque' )] = 0;
		}

		return $revsliders;
	}

	/**
	 * Suggester for autocomplete by slug
	 *
	 *
	 * @return array - id's from portfolio with title/slug.
	 */
	public function portfolioIdsAutocompleteSuggester( $query ) {
		$args = array(
			'post_type'              => 'portfolio',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			's'                      => $query
		);

		$query   = new WP_Query( $args );
		$results = array();
		while ( $query->have_posts() ) : $query->the_post();
			$data          = array();
			$data['value'] = get_the_ID();
			$data['label'] = esc_html__( 'Id', 'baroque' ) . ': ' . get_the_ID() . ' - ' . esc_html__( 'Title', 'baroque' ) . ': ' . get_the_title();
			$results[]     = $data;

		endwhile;
		wp_reset_postdata();

		return $results;
	}

	/**
	 * Suggester for autocomplete by slug
	 *
	 *
	 * @return array - id's from portfolio cat with title/slug.
	 */
	public function portfolioCatsAutocompleteSuggester( $query ) {
		global $wpdb;
		$cat_id          = (int) $query;
		$query           = trim( $query );
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'portfolio_category' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )", $cat_id > 0 ? $cat_id : - 1, stripslashes( $query ), stripslashes( $query )
			), ARRAY_A
		);

		$result = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = esc_html__( 'Id', 'baroque' ) . ': ' . $value['id'] . ' - ' . esc_html__( 'Name', 'baroque' ) . ': ' . $value['name'];
				$result[]      = $data;
			}
		}

		return $result;
	}

	/**
	 * Find portfolio cat by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function portfolioCatsAutocompleteRender( $query ) {
		$query = $query['value'];
		$query = trim( $query );
		$term  = get_term_by( 'slug', $query, 'portfolio_category' );

		if ( is_wp_error( $term ) || ! $term ) {
			return false;
		}

		$data          = array();
		$data['value'] = $term->slug;
		$data['label'] = esc_html__( 'Id', 'baroque' ) . ': ' . $term->term_id . ' - ' . esc_html__( 'Name', 'baroque' ) . ': ' . $term->name;


		return $data;
	}

	/**
	 * Find portfolio by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function portfolioIdsAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested

		if ( empty( $query ) ) {
			return false;
		}

		$args = array(
			'post_type'              => 'portfolio',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			'p'                      => intval( $query )
		);

		$query = new WP_Query( $args );
		$data  = array();
		while ( $query->have_posts() ) : $query->the_post();
			$data['value'] = get_the_ID();
			$data['label'] = esc_html__( 'Id', 'baroque' ) . ': ' . get_the_ID() . ' - ' . esc_html__( 'Title', 'baroque' ) . ': ' . get_the_title();
		endwhile;
		wp_reset_postdata();

		return $data;

	}

	/**
	 * Get icons
	 *
	 * @return array|string
	 */
	function vc_iconpicker_type_ionicons( $icons ) {
		$ionicons = array(
			array( 'ion-alert' => 'alert' ),
			array( 'ion-alert-circled' => 'alert circled' ),
			array( 'ion-android-add' => 'android add' ),
			array( 'ion-android-add-circle' => 'android add circle' ),
			array( 'ion-android-alarm-clock' => 'android alarm clock' ),
			array( 'ion-android-alert' => 'android alert' ),
			array( 'ion-android-apps' => 'android apps' ),
			array( 'ion-android-archive' => 'android archive' ),
			array( 'ion-android-arrow-back' => 'android arrow back' ),
			array( 'ion-android-arrow-down' => 'android arrow down' ),
			array( 'ion-android-arrow-dropdown' => 'android arrow dropdown' ),
			array( 'ion-android-arrow-dropdown-circle' => 'android arrow dropdown circle' ),
			array( 'ion-android-arrow-dropleft' => 'android arrow dropleft' ),
			array( 'ion-android-arrow-dropleft-circle' => 'android arrow dropleft circle' ),
			array( 'ion-android-arrow-dropright' => 'android arrow dropright' ),
			array( 'ion-android-arrow-dropright-circle' => 'android arrow dropright circle' ),
			array( 'ion-android-arrow-dropup' => 'android arrow dropup' ),
			array( 'ion-android-arrow-dropup-circle' => 'android arrow dropup circle' ),
			array( 'ion-android-arrow-forward' => 'android arrow forward' ),
			array( 'ion-android-arrow-up' => 'android arrow up' ),
			array( 'ion-android-attach' => 'android attach' ),
			array( 'ion-android-bar' => 'android bar' ),
			array( 'ion-android-bicycle' => 'android bicycle' ),
			array( 'ion-android-boat' => 'android boat' ),
			array( 'ion-android-bookmark' => 'android bookmark' ),
			array( 'ion-android-bulb' => 'android bulb' ),
			array( 'ion-android-bus' => 'android bus' ),
			array( 'ion-android-calendar' => 'android calendar' ),
			array( 'ion-android-call' => 'android call' ),
			array( 'ion-android-camera' => 'android camera' ),
			array( 'ion-android-cancel' => 'android cancel' ),
			array( 'ion-android-car' => 'android car' ),
			array( 'ion-android-cart' => 'android cart' ),
			array( 'ion-android-chat' => 'android chat' ),
			array( 'ion-android-checkbox' => 'android checkbox' ),
			array( 'ion-android-checkbox-blank' => 'android checkbox blank' ),
			array( 'ion-android-checkbox-outline' => 'android checkbox outline' ),
			array( 'ion-android-checkbox-outline-blank' => 'android checkbox outline blank' ),
			array( 'ion-android-checkmark-circle' => 'android checkmark circle' ),
			array( 'ion-android-clipboard' => 'android clipboard' ),
			array( 'ion-android-close' => 'android close' ),
			array( 'ion-android-cloud' => 'android cloud' ),
			array( 'ion-android-cloud-circle' => 'android cloud circle' ),
			array( 'ion-android-cloud-done' => 'android cloud done' ),
			array( 'ion-android-cloud-outline' => 'android cloud outline' ),
			array( 'ion-android-color-palette' => 'android color palette' ),
			array( 'ion-android-compass' => 'android compass' ),
			array( 'ion-android-contact' => 'android contact' ),
			array( 'ion-android-contacts' => 'android contacts' ),
			array( 'ion-android-contract' => 'android contract' ),
			array( 'ion-android-create' => 'android create' ),
			array( 'ion-android-delete' => 'android delete' ),
			array( 'ion-android-desktop' => 'android desktop' ),
			array( 'ion-android-document' => 'android document' ),
			array( 'ion-android-done' => 'android done' ),
			array( 'ion-android-done-all' => 'android done all' ),
			array( 'ion-android-download' => 'android download' ),
			array( 'ion-android-drafts' => 'android drafts' ),
			array( 'ion-android-exit' => 'android exit' ),
			array( 'ion-android-expand' => 'android expand' ),
			array( 'ion-android-favorite' => 'android favorite' ),
			array( 'ion-android-favorite-outline' => 'android favorite outline' ),
			array( 'ion-android-film' => 'android film' ),
			array( 'ion-android-folder' => 'android folder' ),
			array( 'ion-android-folder-open' => 'android folder open' ),
			array( 'ion-android-funnel' => 'android funnel' ),
			array( 'ion-android-globe' => 'android globe' ),
			array( 'ion-android-hand' => 'android hand' ),
			array( 'ion-android-hangout' => 'android hangout' ),
			array( 'ion-android-happy' => 'android happy' ),
			array( 'ion-android-home' => 'android home' ),
			array( 'ion-android-image' => 'android image' ),
			array( 'ion-android-laptop' => 'android laptop' ),
			array( 'ion-android-list' => 'android list' ),
			array( 'ion-android-locate' => 'android locate' ),
			array( 'ion-android-lock' => 'android lock' ),
			array( 'ion-android-mail' => 'android mail' ),
			array( 'ion-android-map' => 'android map' ),
			array( 'ion-android-menu' => 'android menu' ),
			array( 'ion-android-microphone' => 'android microphone' ),
			array( 'ion-android-microphone-off' => 'android microphone off' ),
			array( 'ion-android-more-horizontal' => 'android more horizontal' ),
			array( 'ion-android-more-vertical' => 'android more vertical' ),
			array( 'ion-android-navigate' => 'android navigate' ),
			array( 'ion-android-notifications' => 'android notifications' ),
			array( 'ion-android-notifications-none' => 'android notifications none' ),
			array( 'ion-android-notifications-off' => 'android notifications off' ),
			array( 'ion-android-open' => 'android open' ),
			array( 'ion-android-options' => 'android options' ),
			array( 'ion-android-people' => 'android people' ),
			array( 'ion-android-person' => 'android person' ),
			array( 'ion-android-person-add' => 'android person add' ),
			array( 'ion-android-phone-landscape' => 'android phone landscape' ),
			array( 'ion-android-phone-portrait' => 'android phone portrait' ),
			array( 'ion-android-pin' => 'android pin' ),
			array( 'ion-android-plane' => 'android plane' ),
			array( 'ion-android-playstore' => 'android playstore' ),
			array( 'ion-android-print' => 'android print' ),
			array( 'ion-android-radio-button-off' => 'android radio button off' ),
			array( 'ion-android-radio-button-on' => 'android radio button on' ),
			array( 'ion-android-refresh' => 'android refresh' ),
			array( 'ion-android-remove' => 'android remove' ),
			array( 'ion-android-remove-circle' => 'android remove circle' ),
			array( 'ion-android-restaurant' => 'android restaurant' ),
			array( 'ion-android-sad' => 'android sad' ),
			array( 'ion-android-search' => 'android search' ),
			array( 'ion-android-send' => 'android send' ),
			array( 'ion-android-settings' => 'android settings' ),
			array( 'ion-android-share' => 'android share' ),
			array( 'ion-android-share-alt' => 'android share alt' ),
			array( 'ion-android-star' => 'android star' ),
			array( 'ion-android-star-half' => 'android star half' ),
			array( 'ion-android-star-outline' => 'android star outline' ),
			array( 'ion-android-stopwatch' => 'android stopwatch' ),
			array( 'ion-android-subway' => 'android subway' ),
			array( 'ion-android-sunny' => 'android sunny' ),
			array( 'ion-android-sync' => 'android sync' ),
			array( 'ion-android-textsms' => 'android textsms' ),
			array( 'ion-android-time' => 'android time' ),
			array( 'ion-android-train' => 'android train' ),
			array( 'ion-android-unlock' => 'android unlock' ),
			array( 'ion-android-upload' => 'android upload' ),
			array( 'ion-android-volume-down' => 'android volume down' ),
			array( 'ion-android-volume-mute' => 'android volume mute' ),
			array( 'ion-android-volume-off' => 'android volume off' ),
			array( 'ion-android-volume-up' => 'android volume up' ),
			array( 'ion-android-walk' => 'android walk' ),
			array( 'ion-android-warning' => 'android warning' ),
			array( 'ion-android-watch' => 'android watch' ),
			array( 'ion-android-wifi' => 'android wifi' ),
			array( 'ion-aperture' => 'aperture' ),
			array( 'ion-archive' => 'archive' ),
			array( 'ion-arrow-down-a' => 'arrow down a' ),
			array( 'ion-arrow-down-b' => 'arrow down b' ),
			array( 'ion-arrow-down-c' => 'arrow down c' ),
			array( 'ion-arrow-expand' => 'arrow expand' ),
			array( 'ion-arrow-graph-down-left' => 'arrow graph down left' ),
			array( 'ion-arrow-graph-down-right' => 'arrow graph down right' ),
			array( 'ion-arrow-graph-up-left' => 'arrow graph up left' ),
			array( 'ion-arrow-graph-up-right' => 'arrow graph up right' ),
			array( 'ion-arrow-left-a' => 'arrow left a' ),
			array( 'ion-arrow-left-b' => 'arrow left b' ),
			array( 'ion-arrow-left-c' => 'arrow left c' ),
			array( 'ion-arrow-move' => 'arrow move' ),
			array( 'ion-arrow-resize' => 'arrow resize' ),
			array( 'ion-arrow-return-left' => 'arrow return left' ),
			array( 'ion-arrow-return-right' => 'arrow return right' ),
			array( 'ion-arrow-right-a' => 'arrow right a' ),
			array( 'ion-arrow-right-b' => 'arrow right b' ),
			array( 'ion-arrow-right-c' => 'arrow right c' ),
			array( 'ion-arrow-shrink' => 'arrow shrink' ),
			array( 'ion-arrow-swap' => 'arrow swap' ),
			array( 'ion-arrow-up-a' => 'arrow up a' ),
			array( 'ion-arrow-up-b' => 'arrow up b' ),
			array( 'ion-arrow-up-c' => 'arrow up c' ),
			array( 'ion-asterisk' => 'asterisk' ),
			array( 'ion-at' => 'at' ),
			array( 'ion-backspace' => 'backspace' ),
			array( 'ion-backspace-outline' => 'backspace outline' ),
			array( 'ion-bag' => 'bag' ),
			array( 'ion-battery-charging' => 'battery charging' ),
			array( 'ion-battery-empty' => 'battery empty' ),
			array( 'ion-battery-full' => 'battery full' ),
			array( 'ion-battery-half' => 'battery half' ),
			array( 'ion-battery-low' => 'battery low' ),
			array( 'ion-beaker' => 'beaker' ),
			array( 'ion-beer' => 'beer' ),
			array( 'ion-bluetooth' => 'bluetooth' ),
			array( 'ion-bonfire' => 'bonfire' ),
			array( 'ion-bookmark' => 'bookmark' ),
			array( 'ion-bowtie' => 'bowtie' ),
			array( 'ion-briefcase' => 'briefcase' ),
			array( 'ion-bug' => 'bug' ),
			array( 'ion-calculator' => 'calculator' ),
			array( 'ion-calendar' => 'calendar' ),
			array( 'ion-camera' => 'camera' ),
			array( 'ion-card' => 'card' ),
			array( 'ion-cash' => 'cash' ),
			array( 'ion-chatbox' => 'chatbox' ),
			array( 'ion-chatbox-working' => 'chatbox working' ),
			array( 'ion-chatboxes' => 'chatboxes' ),
			array( 'ion-chatbubble' => 'chatbubble' ),
			array( 'ion-chatbubble-working' => 'chatbubble working' ),
			array( 'ion-chatbubbles' => 'chatbubbles' ),
			array( 'ion-checkmark' => 'checkmark' ),
			array( 'ion-checkmark-circled' => 'checkmark circled' ),
			array( 'ion-checkmark-round' => 'checkmark round' ),
			array( 'ion-chevron-down' => 'chevron down' ),
			array( 'ion-chevron-left' => 'chevron left' ),
			array( 'ion-chevron-right' => 'chevron right' ),
			array( 'ion-chevron-up' => 'chevron up' ),
			array( 'ion-clipboard' => 'clipboard' ),
			array( 'ion-clock' => 'clock' ),
			array( 'ion-close' => 'close' ),
			array( 'ion-close-circled' => 'close circled' ),
			array( 'ion-close-round' => 'close round' ),
			array( 'ion-closed-captioning' => 'closed captioning' ),
			array( 'ion-cloud' => 'cloud' ),
			array( 'ion-code' => 'code' ),
			array( 'ion-code-download' => 'code download' ),
			array( 'ion-code-working' => 'code working' ),
			array( 'ion-coffee' => 'coffee' ),
			array( 'ion-compass' => 'compass' ),
			array( 'ion-compose' => 'compose' ),
			array( 'ion-connection-bars' => 'connectbars' ),
			array( 'ion-contrast' => 'contrast' ),
			array( 'ion-crop' => 'crop' ),
			array( 'ion-cube' => 'cube' ),
			array( 'ion-disc' => 'disc' ),
			array( 'ion-document' => 'document' ),
			array( 'ion-document-text' => 'document text' ),
			array( 'ion-drag' => 'drag' ),
			array( 'ion-earth' => 'earth' ),
			array( 'ion-easel' => 'easel' ),
			array( 'ion-edit' => 'edit' ),
			array( 'ion-egg' => 'egg' ),
			array( 'ion-eject' => 'eject' ),
			array( 'ion-email' => 'email' ),
			array( 'ion-email-unread' => 'email unread' ),
			array( 'ion-erlenmeyer-flask' => 'erlenmeyer flask' ),
			array( 'ion-erlenmeyer-flask-bubbles' => 'erlenmeyer flask bubbles' ),
			array( 'ion-eye' => 'eye' ),
			array( 'ion-eye-disabled' => 'eye disabled' ),
			array( 'ion-female' => 'female' ),
			array( 'ion-filing' => 'filing' ),
			array( 'ion-film-marker' => 'film marker' ),
			array( 'ion-fireball' => 'fireball' ),
			array( 'ion-flag' => 'flag' ),
			array( 'ion-flame' => 'flame' ),
			array( 'ion-flash' => 'flash' ),
			array( 'ion-flash-off' => 'flash off' ),
			array( 'ion-folder' => 'folder' ),
			array( 'ion-fork' => 'fork' ),
			array( 'ion-fork-repo' => 'fork repo' ),
			array( 'ion-forward' => 'forward' ),
			array( 'ion-funnel' => 'funnel' ),
			array( 'ion-gear-a' => 'gear a' ),
			array( 'ion-gear-b' => 'gear b' ),
			array( 'ion-grid' => 'grid' ),
			array( 'ion-hammer' => 'hammer' ),
			array( 'ion-happy' => 'happy' ),
			array( 'ion-happy-outline' => 'happy outline' ),
			array( 'ion-headphone' => 'headphone' ),
			array( 'ion-heart' => 'heart' ),
			array( 'ion-heart-broken' => 'heart broken' ),
			array( 'ion-help' => 'help' ),
			array( 'ion-help-buoy' => 'help buoy' ),
			array( 'ion-help-circled' => 'help circled' ),
			array( 'ion-home' => 'home' ),
			array( 'ion-icecream' => 'icecream' ),
			array( 'ion-image' => 'image' ),
			array( 'ion-images' => 'images' ),
			array( 'ion-information' => 'information' ),
			array( 'ion-information-circled' => 'informatcircled' ),
			array( 'ion-ionic' => 'ionic' ),
			array( 'ion-ios-alarm' => 'ios alarm' ),
			array( 'ion-ios-alarm-outline' => 'ios alarm outline' ),
			array( 'ion-ios-albums' => 'ios albums' ),
			array( 'ion-ios-albums-outline' => 'ios albums outline' ),
			array( 'ion-ios-americanfootball' => 'ios americanfootball' ),
			array( 'ion-ios-americanfootball-outline' => 'ios americanfootball outline' ),
			array( 'ion-ios-analytics' => 'ios analytics' ),
			array( 'ion-ios-analytics-outline' => 'ios analytics outline' ),
			array( 'ion-ios-arrow-back' => 'ios arrow back' ),
			array( 'ion-ios-arrow-down' => 'ios arrow down' ),
			array( 'ion-ios-arrow-forward' => 'ios arrow forward' ),
			array( 'ion-ios-arrow-left' => 'ios arrow left' ),
			array( 'ion-ios-arrow-right' => 'ios arrow right' ),
			array( 'ion-ios-arrow-thin-down' => 'ios arrow thin down' ),
			array( 'ion-ios-arrow-thin-left' => 'ios arrow thin left' ),
			array( 'ion-ios-arrow-thin-right' => 'ios arrow thin right' ),
			array( 'ion-ios-arrow-thin-up' => 'ios arrow thin up' ),
			array( 'ion-ios-arrow-up' => 'ios arrow up' ),
			array( 'ion-ios-at' => 'ios at' ),
			array( 'ion-ios-at-outline' => 'ios at outline' ),
			array( 'ion-ios-barcode' => 'ios barcode' ),
			array( 'ion-ios-barcode-outline' => 'ios barcode outline' ),
			array( 'ion-ios-baseball' => 'ios baseball' ),
			array( 'ion-ios-baseball-outline' => 'ios baseball outline' ),
			array( 'ion-ios-basketball' => 'ios basketball' ),
			array( 'ion-ios-basketball-outline' => 'ios basketball outline' ),
			array( 'ion-ios-bell' => 'ios bell' ),
			array( 'ion-ios-bell-outline' => 'ios bell outline' ),
			array( 'ion-ios-body' => 'ios body' ),
			array( 'ion-ios-body-outline' => 'ios body outline' ),
			array( 'ion-ios-bolt' => 'ios bolt' ),
			array( 'ion-ios-bolt-outline' => 'ios bolt outline' ),
			array( 'ion-ios-book' => 'ios book' ),
			array( 'ion-ios-book-outline' => 'ios book outline' ),
			array( 'ion-ios-bookmarks' => 'ios bookmarks' ),
			array( 'ion-ios-bookmarks-outline' => 'ios bookmarks outline' ),
			array( 'ion-ios-box' => 'ios box' ),
			array( 'ion-ios-box-outline' => 'ios box outline' ),
			array( 'ion-ios-briefcase' => 'ios briefcase' ),
			array( 'ion-ios-briefcase-outline' => 'ios briefcase outline' ),
			array( 'ion-ios-browsers' => 'ios browsers' ),
			array( 'ion-ios-browsers-outline' => 'ios browsers outline' ),
			array( 'ion-ios-calculator' => 'ios calculator' ),
			array( 'ion-ios-calculator-outline' => 'ios calculator outline' ),
			array( 'ion-ios-calendar' => 'ios calendar' ),
			array( 'ion-ios-calendar-outline' => 'ios calendar outline' ),
			array( 'ion-ios-camera' => 'ios camera' ),
			array( 'ion-ios-camera-outline' => 'ios camera outline' ),
			array( 'ion-ios-cart' => 'ios cart' ),
			array( 'ion-ios-cart-outline' => 'ios cart outline' ),
			array( 'ion-ios-chatboxes' => 'ios chatboxes' ),
			array( 'ion-ios-chatboxes-outline' => 'ios chatboxes outline' ),
			array( 'ion-ios-chatbubble' => 'ios chatbubble' ),
			array( 'ion-ios-chatbubble-outline' => 'ios chatbubble outline' ),
			array( 'ion-ios-checkmark' => 'ios checkmark' ),
			array( 'ion-ios-checkmark-empty' => 'ios checkmark empty' ),
			array( 'ion-ios-checkmark-outline' => 'ios checkmark outline' ),
			array( 'ion-ios-circle-filled' => 'ios circle filled' ),
			array( 'ion-ios-circle-outline' => 'ios circle outline' ),
			array( 'ion-ios-clock' => 'ios clock' ),
			array( 'ion-ios-clock-outline' => 'ios clock outline' ),
			array( 'ion-ios-close' => 'ios close' ),
			array( 'ion-ios-close-empty' => 'ios close empty' ),
			array( 'ion-ios-close-outline' => 'ios close outline' ),
			array( 'ion-ios-cloud' => 'ios cloud' ),
			array( 'ion-ios-cloud-download' => 'ios cloud download' ),
			array( 'ion-ios-cloud-download-outline' => 'ios cloud download outline' ),
			array( 'ion-ios-cloud-outline' => 'ios cloud outline' ),
			array( 'ion-ios-cloud-upload' => 'ios cloud upload' ),
			array( 'ion-ios-cloud-upload-outline' => 'ios cloud upload outline' ),
			array( 'ion-ios-cloudy' => 'ios cloudy' ),
			array( 'ion-ios-cloudy-night' => 'ios cloudy night' ),
			array( 'ion-ios-cloudy-night-outline' => 'ios cloudy night outline' ),
			array( 'ion-ios-cloudy-outline' => 'ios cloudy outline' ),
			array( 'ion-ios-cog' => 'ios cog' ),
			array( 'ion-ios-cog-outline' => 'ios cog outline' ),
			array( 'ion-ios-color-filter' => 'ios color filter' ),
			array( 'ion-ios-color-filter-outline' => 'ios color filter outline' ),
			array( 'ion-ios-color-wand' => 'ios color wand' ),
			array( 'ion-ios-color-wand-outline' => 'ios color wand outline' ),
			array( 'ion-ios-compose' => 'ios compose' ),
			array( 'ion-ios-compose-outline' => 'ios compose outline' ),
			array( 'ion-ios-contact' => 'ios contact' ),
			array( 'ion-ios-contact-outline' => 'ios contact outline' ),
			array( 'ion-ios-copy' => 'ios copy' ),
			array( 'ion-ios-copy-outline' => 'ios copy outline' ),
			array( 'ion-ios-crop' => 'ios crop' ),
			array( 'ion-ios-crop-strong' => 'ios crop strong' ),
			array( 'ion-ios-download' => 'ios download' ),
			array( 'ion-ios-download-outline' => 'ios download outline' ),
			array( 'ion-ios-drag' => 'ios drag' ),
			array( 'ion-ios-email' => 'ios email' ),
			array( 'ion-ios-email-outline' => 'ios email outline' ),
			array( 'ion-ios-eye' => 'ios eye' ),
			array( 'ion-ios-eye-outline' => 'ios eye outline' ),
			array( 'ion-ios-fastforward' => 'ios fastforward' ),
			array( 'ion-ios-fastforward-outline' => 'ios fastforward outline' ),
			array( 'ion-ios-filing' => 'ios filing' ),
			array( 'ion-ios-filing-outline' => 'ios filing outline' ),
			array( 'ion-ios-film' => 'ios film' ),
			array( 'ion-ios-film-outline' => 'ios film outline' ),
			array( 'ion-ios-flag' => 'ios flag' ),
			array( 'ion-ios-flag-outline' => 'ios flag outline' ),
			array( 'ion-ios-flame' => 'ios flame' ),
			array( 'ion-ios-flame-outline' => 'ios flame outline' ),
			array( 'ion-ios-flask' => 'ios flask' ),
			array( 'ion-ios-flask-outline' => 'ios flask outline' ),
			array( 'ion-ios-flower' => 'ios flower' ),
			array( 'ion-ios-flower-outline' => 'ios flower outline' ),
			array( 'ion-ios-folder' => 'ios folder' ),
			array( 'ion-ios-folder-outline' => 'ios folder outline' ),
			array( 'ion-ios-football' => 'ios football' ),
			array( 'ion-ios-football-outline' => 'ios football outline' ),
			array( 'ion-ios-game-controller-a' => 'ios game controller a' ),
			array( 'ion-ios-game-controller-a-outline' => 'ios game controller a outline' ),
			array( 'ion-ios-game-controller-b' => 'ios game controller b' ),
			array( 'ion-ios-game-controller-b-outline' => 'ios game controller b outline' ),
			array( 'ion-ios-gear' => 'ios gear' ),
			array( 'ion-ios-gear-outline' => 'ios gear outline' ),
			array( 'ion-ios-glasses' => 'ios glasses' ),
			array( 'ion-ios-glasses-outline' => 'ios glasses outline' ),
			array( 'ion-ios-grid-view' => 'ios grid view' ),
			array( 'ion-ios-grid-view-outline' => 'ios grid view outline' ),
			array( 'ion-ios-heart' => 'ios heart' ),
			array( 'ion-ios-heart-outline' => 'ios heart outline' ),
			array( 'ion-ios-help' => 'ios help' ),
			array( 'ion-ios-help-empty' => 'ios help empty' ),
			array( 'ion-ios-help-outline' => 'ios help outline' ),
			array( 'ion-ios-home' => 'ios home' ),
			array( 'ion-ios-home-outline' => 'ios home outline' ),
			array( 'ion-ios-infinite' => 'ios infinite' ),
			array( 'ion-ios-infinite-outline' => 'ios infinite outline' ),
			array( 'ion-ios-information' => 'ios information' ),
			array( 'ion-ios-information-empty' => 'ios informatempty' ),
			array( 'ion-ios-information-outline' => 'ios informatoutline' ),
			array( 'ion-ios-ionic-outline' => 'ios ionic outline' ),
			array( 'ion-ios-keypad' => 'ios keypad' ),
			array( 'ion-ios-keypad-outline' => 'ios keypad outline' ),
			array( 'ion-ios-lightbulb' => 'ios lightbulb' ),
			array( 'ion-ios-lightbulb-outline' => 'ios lightbulb outline' ),
			array( 'ion-ios-list' => 'ios list' ),
			array( 'ion-ios-list-outline' => 'ios list outline' ),
			array( 'ion-ios-location' => 'ios location' ),
			array( 'ion-ios-location-outline' => 'ios locatoutline' ),
			array( 'ion-ios-locked' => 'ios locked' ),
			array( 'ion-ios-locked-outline' => 'ios locked outline' ),
			array( 'ion-ios-loop' => 'ios loop' ),
			array( 'ion-ios-loop-strong' => 'ios loop strong' ),
			array( 'ion-ios-medical' => 'ios medical' ),
			array( 'ion-ios-medical-outline' => 'ios medical outline' ),
			array( 'ion-ios-medkit' => 'ios medkit' ),
			array( 'ion-ios-medkit-outline' => 'ios medkit outline' ),
			array( 'ion-ios-mic' => 'ios mic' ),
			array( 'ion-ios-mic-off' => 'ios mic off' ),
			array( 'ion-ios-mic-outline' => 'ios mic outline' ),
			array( 'ion-ios-minus' => 'ios minus' ),
			array( 'ion-ios-minus-empty' => 'ios minus empty' ),
			array( 'ion-ios-minus-outline' => 'ios minus outline' ),
			array( 'ion-ios-monitor' => 'ios monitor' ),
			array( 'ion-ios-monitor-outline' => 'ios monitor outline' ),
			array( 'ion-ios-moon' => 'ios moon' ),
			array( 'ion-ios-moon-outline' => 'ios moon outline' ),
			array( 'ion-ios-more' => 'ios more' ),
			array( 'ion-ios-more-outline' => 'ios more outline' ),
			array( 'ion-ios-musical-note' => 'ios musical note' ),
			array( 'ion-ios-musical-notes' => 'ios musical notes' ),
			array( 'ion-ios-navigate' => 'ios navigate' ),
			array( 'ion-ios-navigate-outline' => 'ios navigate outline' ),
			array( 'ion-ios-nutrition' => 'ios nutrition' ),
			array( 'ion-ios-nutrition-outline' => 'ios nutritoutline' ),
			array( 'ion-ios-paper' => 'ios paper' ),
			array( 'ion-ios-paper-outline' => 'ios paper outline' ),
			array( 'ion-ios-paperplane' => 'ios paperplane' ),
			array( 'ion-ios-paperplane-outline' => 'ios paperplane outline' ),
			array( 'ion-ios-partlysunny' => 'ios partlysunny' ),
			array( 'ion-ios-partlysunny-outline' => 'ios partlysunny outline' ),
			array( 'ion-ios-pause' => 'ios pause' ),
			array( 'ion-ios-pause-outline' => 'ios pause outline' ),
			array( 'ion-ios-paw' => 'ios paw' ),
			array( 'ion-ios-paw-outline' => 'ios paw outline' ),
			array( 'ion-ios-people' => 'ios people' ),
			array( 'ion-ios-people-outline' => 'ios people outline' ),
			array( 'ion-ios-person' => 'ios person' ),
			array( 'ion-ios-person-outline' => 'ios person outline' ),
			array( 'ion-ios-personadd' => 'ios personadd' ),
			array( 'ion-ios-personadd-outline' => 'ios personadd outline' ),
			array( 'ion-ios-photos' => 'ios photos' ),
			array( 'ion-ios-photos-outline' => 'ios photos outline' ),
			array( 'ion-ios-pie' => 'ios pie' ),
			array( 'ion-ios-pie-outline' => 'ios pie outline' ),
			array( 'ion-ios-pint' => 'ios pint' ),
			array( 'ion-ios-pint-outline' => 'ios pint outline' ),
			array( 'ion-ios-play' => 'ios play' ),
			array( 'ion-ios-play-outline' => 'ios play outline' ),
			array( 'ion-ios-plus' => 'ios plus' ),
			array( 'ion-ios-plus-empty' => 'ios plus empty' ),
			array( 'ion-ios-plus-outline' => 'ios plus outline' ),
			array( 'ion-ios-pricetag' => 'ios pricetag' ),
			array( 'ion-ios-pricetag-outline' => 'ios pricetag outline' ),
			array( 'ion-ios-pricetags' => 'ios pricetags' ),
			array( 'ion-ios-pricetags-outline' => 'ios pricetags outline' ),
			array( 'ion-ios-printer' => 'ios printer' ),
			array( 'ion-ios-printer-outline' => 'ios printer outline' ),
			array( 'ion-ios-pulse' => 'ios pulse' ),
			array( 'ion-ios-pulse-strong' => 'ios pulse strong' ),
			array( 'ion-ios-rainy' => 'ios rainy' ),
			array( 'ion-ios-rainy-outline' => 'ios rainy outline' ),
			array( 'ion-ios-recording' => 'ios recording' ),
			array( 'ion-ios-recording-outline' => 'ios recording outline' ),
			array( 'ion-ios-redo' => 'ios redo' ),
			array( 'ion-ios-redo-outline' => 'ios redo outline' ),
			array( 'ion-ios-refresh' => 'ios refresh' ),
			array( 'ion-ios-refresh-empty' => 'ios refresh empty' ),
			array( 'ion-ios-refresh-outline' => 'ios refresh outline' ),
			array( 'ion-ios-reload' => 'ios reload' ),
			array( 'ion-ios-reverse-camera' => 'ios reverse camera' ),
			array( 'ion-ios-reverse-camera-outline' => 'ios reverse camera outline' ),
			array( 'ion-ios-rewind' => 'ios rewind' ),
			array( 'ion-ios-rewind-outline' => 'ios rewind outline' ),
			array( 'ion-ios-rose' => 'ios rose' ),
			array( 'ion-ios-rose-outline' => 'ios rose outline' ),
			array( 'ion-ios-search' => 'ios search' ),
			array( 'ion-ios-search-strong' => 'ios search strong' ),
			array( 'ion-ios-settings' => 'ios settings' ),
			array( 'ion-ios-settings-strong' => 'ios settings strong' ),
			array( 'ion-ios-shuffle' => 'ios shuffle' ),
			array( 'ion-ios-shuffle-strong' => 'ios shuffle strong' ),
			array( 'ion-ios-skipbackward' => 'ios skipbackward' ),
			array( 'ion-ios-skipbackward-outline' => 'ios skipbackward outline' ),
			array( 'ion-ios-skipforward' => 'ios skipforward' ),
			array( 'ion-ios-skipforward-outline' => 'ios skipforward outline' ),
			array( 'ion-ios-snowy' => 'ios snowy' ),
			array( 'ion-ios-speedometer' => 'ios speedometer' ),
			array( 'ion-ios-speedometer-outline' => 'ios speedometer outline' ),
			array( 'ion-ios-star' => 'ios star' ),
			array( 'ion-ios-star-half' => 'ios star half' ),
			array( 'ion-ios-star-outline' => 'ios star outline' ),
			array( 'ion-ios-stopwatch' => 'ios stopwatch' ),
			array( 'ion-ios-stopwatch-outline' => 'ios stopwatch outline' ),
			array( 'ion-ios-sunny' => 'ios sunny' ),
			array( 'ion-ios-sunny-outline' => 'ios sunny outline' ),
			array( 'ion-ios-telephone' => 'ios telephone' ),
			array( 'ion-ios-telephone-outline' => 'ios telephone outline' ),
			array( 'ion-ios-tennisball' => 'ios tennisball' ),
			array( 'ion-ios-tennisball-outline' => 'ios tennisball outline' ),
			array( 'ion-ios-thunderstorm' => 'ios thunderstorm' ),
			array( 'ion-ios-thunderstorm-outline' => 'ios thunderstorm outline' ),
			array( 'ion-ios-time' => 'ios time' ),
			array( 'ion-ios-time-outline' => 'ios time outline' ),
			array( 'ion-ios-timer' => 'ios timer' ),
			array( 'ion-ios-timer-outline' => 'ios timer outline' ),
			array( 'ion-ios-toggle' => 'ios toggle' ),
			array( 'ion-ios-toggle-outline' => 'ios toggle outline' ),
			array( 'ion-ios-trash' => 'ios trash' ),
			array( 'ion-ios-trash-outline' => 'ios trash outline' ),
			array( 'ion-ios-undo' => 'ios undo' ),
			array( 'ion-ios-undo-outline' => 'ios undo outline' ),
			array( 'ion-ios-unlocked' => 'ios unlocked' ),
			array( 'ion-ios-unlocked-outline' => 'ios unlocked outline' ),
			array( 'ion-ios-upload' => 'ios upload' ),
			array( 'ion-ios-upload-outline' => 'ios upload outline' ),
			array( 'ion-ios-videocam' => 'ios videocam' ),
			array( 'ion-ios-videocam-outline' => 'ios videocam outline' ),
			array( 'ion-ios-volume-high' => 'ios volume high' ),
			array( 'ion-ios-volume-low' => 'ios volume low' ),
			array( 'ion-ios-wineglass' => 'ios wineglass' ),
			array( 'ion-ios-wineglass-outline' => 'ios wineglass outline' ),
			array( 'ion-ios-world' => 'ios world' ),
			array( 'ion-ios-world-outline' => 'ios world outline' ),
			array( 'ion-ipad' => 'ipad' ),
			array( 'ion-iphone' => 'iphone' ),
			array( 'ion-ipod' => 'ipod' ),
			array( 'ion-jet' => 'jet' ),
			array( 'ion-key' => 'key' ),
			array( 'ion-knife' => 'knife' ),
			array( 'ion-laptop' => 'laptop' ),
			array( 'ion-leaf' => 'leaf' ),
			array( 'ion-levels' => 'levels' ),
			array( 'ion-lightbulb' => 'lightbulb' ),
			array( 'ion-link' => 'link' ),
			array( 'ion-load-a' => 'load a' ),
			array( 'ion-load-b' => 'load b' ),
			array( 'ion-load-c' => 'load c' ),
			array( 'ion-load-d' => 'load d' ),
			array( 'ion-location' => 'location' ),
			array( 'ion-lock-combination' => 'lock combination' ),
			array( 'ion-locked' => 'locked' ),
			array( 'ion-log-in' => 'log in' ),
			array( 'ion-log-out' => 'log out' ),
			array( 'ion-loop' => 'loop' ),
			array( 'ion-magnet' => 'magnet' ),
			array( 'ion-male' => 'male' ),
			array( 'ion-man' => 'man' ),
			array( 'ion-map' => 'map' ),
			array( 'ion-medkit' => 'medkit' ),
			array( 'ion-merge' => 'merge' ),
			array( 'ion-mic-a' => 'mic a' ),
			array( 'ion-mic-b' => 'mic b' ),
			array( 'ion-mic-c' => 'mic c' ),
			array( 'ion-minus' => 'minus' ),
			array( 'ion-minus-circled' => 'minus circled' ),
			array( 'ion-minus-round' => 'minus round' ),
			array( 'ion-model-s' => 'model s' ),
			array( 'ion-monitor' => 'monitor' ),
			array( 'ion-more' => 'more' ),
			array( 'ion-mouse' => 'mouse' ),
			array( 'ion-music-note' => 'music note' ),
			array( 'ion-navicon' => 'navicon' ),
			array( 'ion-navicon-round' => 'navicon round' ),
			array( 'ion-navigate' => 'navigate' ),
			array( 'ion-network' => 'network' ),
			array( 'ion-no-smoking' => 'no smoking' ),
			array( 'ion-nuclear' => 'nuclear' ),
			array( 'ion-outlet' => 'outlet' ),
			array( 'ion-paintbrush' => 'paintbrush' ),
			array( 'ion-paintbucket' => 'paintbucket' ),
			array( 'ion-paper-airplane' => 'paper airplane' ),
			array( 'ion-paperclip' => 'paperclip' ),
			array( 'ion-pause' => 'pause' ),
			array( 'ion-person' => 'person' ),
			array( 'ion-person-add' => 'person add' ),
			array( 'ion-person-stalker' => 'person stalker' ),
			array( 'ion-pie-graph' => 'pie graph' ),
			array( 'ion-pin' => 'pin' ),
			array( 'ion-pinpoint' => 'pinpoint' ),
			array( 'ion-pizza' => 'pizza' ),
			array( 'ion-plane' => 'plane' ),
			array( 'ion-planet' => 'planet' ),
			array( 'ion-play' => 'play' ),
			array( 'ion-playstation' => 'playstation' ),
			array( 'ion-plus' => 'plus' ),
			array( 'ion-plus-circled' => 'plus circled' ),
			array( 'ion-plus-round' => 'plus round' ),
			array( 'ion-podium' => 'podium' ),
			array( 'ion-pound' => 'pound' ),
			array( 'ion-power' => 'power' ),
			array( 'ion-pricetag' => 'pricetag' ),
			array( 'ion-pricetags' => 'pricetags' ),
			array( 'ion-printer' => 'printer' ),
			array( 'ion-pull-request' => 'pull request' ),
			array( 'ion-qr-scanner' => 'qr scanner' ),
			array( 'ion-quote' => 'quote' ),
			array( 'ion-radio-waves' => 'radio waves' ),
			array( 'ion-record' => 'record' ),
			array( 'ion-refresh' => 'refresh' ),
			array( 'ion-reply' => 'reply' ),
			array( 'ion-reply-all' => 'reply all' ),
			array( 'ion-ribbon-a' => 'ribbon a' ),
			array( 'ion-ribbon-b' => 'ribbon b' ),
			array( 'ion-sad' => 'sad' ),
			array( 'ion-sad-outline' => 'sad outline' ),
			array( 'ion-scissors' => 'scissors' ),
			array( 'ion-search' => 'search' ),
			array( 'ion-settings' => 'settings' ),
			array( 'ion-share' => 'share' ),
			array( 'ion-shuffle' => 'shuffle' ),
			array( 'ion-skip-backward' => 'skip backward' ),
			array( 'ion-skip-forward' => 'skip forward' ),
			array( 'ion-social-android' => 'social android' ),
			array( 'ion-social-android-outline' => 'social android outline' ),
			array( 'ion-social-angular' => 'social angular' ),
			array( 'ion-social-angular-outline' => 'social angular outline' ),
			array( 'ion-social-apple' => 'social apple' ),
			array( 'ion-social-apple-outline' => 'social apple outline' ),
			array( 'ion-social-bitcoin' => 'social bitcoin' ),
			array( 'ion-social-bitcoin-outline' => 'social bitcoin outline' ),
			array( 'ion-social-buffer' => 'social buffer' ),
			array( 'ion-social-buffer-outline' => 'social buffer outline' ),
			array( 'ion-social-chrome' => 'social chrome' ),
			array( 'ion-social-chrome-outline' => 'social chrome outline' ),
			array( 'ion-social-codepen' => 'social codepen' ),
			array( 'ion-social-codepen-outline' => 'social codepen outline' ),
			array( 'ion-social-css3' => 'social css3' ),
			array( 'ion-social-css3-outline' => 'social css3 outline' ),
			array( 'ion-social-designernews' => 'social designernews' ),
			array( 'ion-social-designernews-outline' => 'social designernews outline' ),
			array( 'ion-social-dribbble' => 'social dribbble' ),
			array( 'ion-social-dribbble-outline' => 'social dribbble outline' ),
			array( 'ion-social-dropbox' => 'social dropbox' ),
			array( 'ion-social-dropbox-outline' => 'social dropbox outline' ),
			array( 'ion-social-euro' => 'social euro' ),
			array( 'ion-social-euro-outline' => 'social euro outline' ),
			array( 'ion-social-facebook' => 'social facebook' ),
			array( 'ion-social-facebook-outline' => 'social facebook outline' ),
			array( 'ion-social-foursquare' => 'social foursquare' ),
			array( 'ion-social-foursquare-outline' => 'social foursquare outline' ),
			array( 'ion-social-freebsd-devil' => 'social freebsd devil' ),
			array( 'ion-social-github' => 'social github' ),
			array( 'ion-social-github-outline' => 'social github outline' ),
			array( 'ion-social-google' => 'social google' ),
			array( 'ion-social-google-outline' => 'social google outline' ),
			array( 'ion-social-googleplus' => 'social googleplus' ),
			array( 'ion-social-googleplus-outline' => 'social googleplus outline' ),
			array( 'ion-social-hackernews' => 'social hackernews' ),
			array( 'ion-social-hackernews-outline' => 'social hackernews outline' ),
			array( 'ion-social-html5' => 'social html5' ),
			array( 'ion-social-html5-outline' => 'social html5 outline' ),
			array( 'ion-social-instagram' => 'social instagram' ),
			array( 'ion-social-instagram-outline' => 'social instagram outline' ),
			array( 'ion-social-javascript' => 'social javascript' ),
			array( 'ion-social-javascript-outline' => 'social javascript outline' ),
			array( 'ion-social-linkedin' => 'social linkedin' ),
			array( 'ion-social-linkedin-outline' => 'social linkedin outline' ),
			array( 'ion-social-markdown' => 'social markdown' ),
			array( 'ion-social-nodejs' => 'social nodejs' ),
			array( 'ion-social-octocat' => 'social octocat' ),
			array( 'ion-social-pinterest' => 'social pinterest' ),
			array( 'ion-social-pinterest-outline' => 'social pinterest outline' ),
			array( 'ion-social-python' => 'social python' ),
			array( 'ion-social-reddit' => 'social reddit' ),
			array( 'ion-social-reddit-outline' => 'social reddit outline' ),
			array( 'ion-social-rss' => 'social rss' ),
			array( 'ion-social-rss-outline' => 'social rss outline' ),
			array( 'ion-social-sass' => 'social sass' ),
			array( 'ion-social-skype' => 'social skype' ),
			array( 'ion-social-skype-outline' => 'social skype outline' ),
			array( 'ion-social-snapchat' => 'social snapchat' ),
			array( 'ion-social-snapchat-outline' => 'social snapchat outline' ),
			array( 'ion-social-tumblr' => 'social tumblr' ),
			array( 'ion-social-tumblr-outline' => 'social tumblr outline' ),
			array( 'ion-social-tux' => 'social tux' ),
			array( 'ion-social-twitch' => 'social twitch' ),
			array( 'ion-social-twitch-outline' => 'social twitch outline' ),
			array( 'ion-social-twitter' => 'social twitter' ),
			array( 'ion-social-twitter-outline' => 'social twitter outline' ),
			array( 'ion-social-usd' => 'social usd' ),
			array( 'ion-social-usd-outline' => 'social usd outline' ),
			array( 'ion-social-vimeo' => 'social vimeo' ),
			array( 'ion-social-vimeo-outline' => 'social vimeo outline' ),
			array( 'ion-social-whatsapp' => 'social whatsapp' ),
			array( 'ion-social-whatsapp-outline' => 'social whatsapp outline' ),
			array( 'ion-social-windows' => 'social windows' ),
			array( 'ion-social-windows-outline' => 'social windows outline' ),
			array( 'ion-social-wordpress' => 'social wordpress' ),
			array( 'ion-social-wordpress-outline' => 'social wordpress outline' ),
			array( 'ion-social-yahoo' => 'social yahoo' ),
			array( 'ion-social-yahoo-outline' => 'social yahoo outline' ),
			array( 'ion-social-yen' => 'social yen' ),
			array( 'ion-social-yen-outline' => 'social yen outline' ),
			array( 'ion-social-youtube' => 'social youtube' ),
			array( 'ion-social-youtube-outline' => 'social youtube outline' ),
			array( 'ion-soup-can' => 'soup can' ),
			array( 'ion-soup-can-outline' => 'soup can outline' ),
			array( 'ion-speakerphone' => 'speakerphone' ),
			array( 'ion-speedometer' => 'speedometer' ),
			array( 'ion-spoon' => 'spoon' ),
			array( 'ion-star' => 'star' ),
			array( 'ion-stats-bars' => 'stats bars' ),
			array( 'ion-steam' => 'steam' ),
			array( 'ion-stop' => 'stop' ),
			array( 'ion-thermometer' => 'thermometer' ),
			array( 'ion-thumbsdown' => 'thumbsdown' ),
			array( 'ion-thumbsup' => 'thumbsup' ),
			array( 'ion-toggle' => 'toggle' ),
			array( 'ion-toggle-filled' => 'toggle filled' ),
			array( 'ion-transgender' => 'transgender' ),
			array( 'ion-trash-a' => 'trash a' ),
			array( 'ion-trash-b' => 'trash b' ),
			array( 'ion-trophy' => 'trophy' ),
			array( 'ion-tshirt' => 'tshirt' ),
			array( 'ion-tshirt-outline' => 'tshirt outline' ),
			array( 'ion-umbrella' => 'umbrella' ),
			array( 'ion-university' => 'university' ),
			array( 'ion-unlocked' => 'unlocked' ),
			array( 'ion-upload' => 'upload' ),
			array( 'ion-usb' => 'usb' ),
			array( 'ion-videocamera' => 'videocamera' ),
			array( 'ion-volume-high' => 'volume high' ),
			array( 'ion-volume-low' => 'volume low' ),
			array( 'ion-volume-medium' => 'volume medium' ),
			array( 'ion-volume-mute' => 'volume mute' ),
			array( 'ion-wand' => 'wand' ),
			array( 'ion-waterdrop' => 'waterdrop' ),
			array( 'ion-wifi' => 'wifi' ),
			array( 'ion-wineglass' => 'wineglass' ),
			array( 'ion-woman' => 'woman' ),
			array( 'ion-wrench' => 'wrench' ),
			array( 'ion-xbox' => 'xbox' ),
		);

		return array_merge( $icons, $ionicons );
	}

	/**
	 * Enqueue icon element font
	 *
	 * @param $font
	 */
	function vc_icon_element_fonts_enqueue( $font ) {
		switch ( $font ) {
			case 'ionicons':
				wp_enqueue_style( 'ionicons' );
		}
	}

	function vc_iconpicker_base_register_css() {
		wp_enqueue_style( 'ionicons', BAROQUE_ADDONS_URL . '/assets/css/ionicons.min.css', array(), '2.0.0' );
	}
}