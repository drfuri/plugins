(function ( $ ) {
	'use strict';

	var baroque = baroque || {};

	baroque.init = function () {
		baroque.$body = $( document.body ),
			baroque.$window = $( window ),
			baroque.$header = $( '#masthead' );

		this.customCSS();
		this.rowParallax();
		this.portfolioCarousel();
		this.portfolioGridGap();
		this.videoLightBox();
		this.heroSlider();
		this.vsSlider2();
		this.vSwiperSlider();
		this.hSwiperSlider();
		this.portfolioList1();
		this.portfolioList2();
		this.portfolioListText();
		this.eventCountDown();
		this.gmaps();
		this.portfolioFilter();
		this.loadPortfolio();
		this.portfolioCarouselSwiper();

		/*Couterup*/
		$( '.ba-counter .value' ).counterUp();
	};

	// custom css
	baroque.customCSS = function () {

		baroque.$window.on( 'resize', function () {
			var $hSlider = $( '.ba-hs-slider' ),
				windowW = baroque.$window.outerWidth(),
				containerW = $( '.container' ).outerWidth();

			if ( baroqueShortCode.isRTL === '1' ) {
				$( '.ba-cta .action-content .action-content-wrapper' ).css( 'padding-right', ( windowW - containerW ) / 2 );
				$hSlider.find( '.slider-item' ).css( 'padding-right', ( windowW - containerW ) / 2 );
				$hSlider.find( '.ba-swiper-button' ).css( 'right', ( windowW - containerW ) / 2 );
			} else {
				$( '.ba-cta .action-content .action-content-wrapper' ).css( 'padding-left', ( windowW - containerW ) / 2 );
				$hSlider.find( '.slider-item' ).css( 'padding-left', ( windowW - containerW ) / 2 );
				$hSlider.find( '.ba-swiper-button' ).css( 'left', ( windowW - containerW ) / 2 );
			}

			if ( windowW < 1025 ) {
				if ( baroqueShortCode.isRTL === '1' ) {
					$( '.ba-cta .action-content .action-content-wrapper' ).css( 'padding-right', ( ( windowW - containerW ) / 2 ) + 15 );
					$hSlider.find( '.slider-item' ).css( 'padding-right', ( ( windowW - containerW ) / 2 ) + 15 );
				} else {
					$( '.ba-cta .action-content .action-content-wrapper' ).css( 'padding-left', ( ( windowW - containerW ) / 2 ) + 15 );
					$hSlider.find( '.slider-item' ).css( 'padding-left', ( ( windowW - containerW ) / 2 ) + 15 );
				}
			}

		} ).trigger( 'resize' );
	};

	/*
	 * Vc row parallax
	 */
	baroque.rowParallax = function () {
		if ( baroque.$window.width() < 1200 ) {
			return;
		}

		var $parallaxsRow = $( '.vc_row.parallax' );
		for ( var i = 0; i < $parallaxsRow.length; i++ ) {
			$( $parallaxsRow[i] ).parallax( '50%', 0.6 );
		}

		$( '.ba-cta.has-background-image .action-content' ).parallax( '50%', 0.6 );
	};

	/**
	 * Init portfolio carousel
	 */
	baroque.portfolioCarousel = function () {
		if ( baroqueShortCode.length === 0 || typeof baroqueShortCode.portfolio === 'undefined' ) {
			return;
		}

		$.each( baroqueShortCode.portfolio, function ( id, portfolioData ) {
			var $portfolio = $( document.getElementById( id ) );

			$portfolio.not( '.slick-initialized' ).slick( {
				rtl          : baroqueShortCode.isRTL === '1',
				slidesToShow : 1,
				infinite     : portfolioData.autoplay,
				arrows       : portfolioData.nav,
				autoplay     : portfolioData.autoplay,
				autoplaySpeed: portfolioData.autoplay_speed,
				dots         : portfolioData.dot,
				prevArrow    : '<div class="baroque-left-arrow"><i class="icon-chevron-left"></i></div>',
				nextArrow    : '<div class="baroque-right-arrow"><i class="icon-chevron-right"></i></div>',
				responsive   : [
					{
						breakpoint: 1200,
						settings  : {
							arrows: false,
							dots  : true
						}
					},
					{
						breakpoint: 768,
						settings  : {
							arrows: false,
							dots  : true
						}
					},
					{
						breakpoint: 480,
						settings  : {
							arrows: false,
							dots  : true
						}
					}
				]
			} );
		} );
	};

	// Portfolio grid gap
	baroque.portfolioGridGap = function () {
		var $portfolio = $( '.ba-portfolios-grid-gap' );

		$portfolio.find( '.port-title' ).on( 'mouseover', function () {
			$( this ).closest( '.port-item' ).addClass( 'active' );
			$( this ).closest( '.ports-list' ).addClass( 'hover' );
		} );

		$portfolio.find( '.port-title' ).on( 'mouseout', function () {
			$( this ).closest( '.port-item' ).removeClass( 'active' );
			$( this ).closest( '.ports-list' ).removeClass( 'hover' );
		} );
	};

	/*
	 * Toggle video banner play button
	 */
	baroque.videoLightBox = function () {
		var $images = $( '.mf-video-banner' );

		if ( !$images.length ) {
			return;
		}

		var $links = $images.find( 'a.photoswipe' ),
			items = [];

		$links.each( function () {
			var $a = $( this );

			items.push( {
				html: $a.data( 'href' )
			} );

		} );

		$images.on( 'click', 'a.photoswipe', function ( e ) {
			e.preventDefault();

			var index = $links.index( $( this ) ),
				options = {
					index              : index,
					bgOpacity          : 0.85,
					showHideOpacity    : true,
					mainClass          : 'pswp--minimal-dark',
					barsSize           : { top: 0, bottom: 0 },
					captionEl          : false,
					fullscreenEl       : false,
					shareEl            : false,
					tapToClose         : true,
					tapToToggleControls: false
				};

			var lightBox = new PhotoSwipe( document.getElementById( 'pswp' ), window.PhotoSwipeUI_Default, items, options );
			lightBox.init();

			lightBox.listen( 'close', function () {
				$( '.mf-video-wrapper' ).find( 'iframe' ).each( function () {
					$( this ).attr( 'src', $( this ).attr( 'src' ) );
				} );
			} );
		} );
	};

	/**
	 * Hero Slider
	 */

	baroque.heroSlider = function () {

		$( '.ba-hero-slider' ).on( 'mouseover touchstart', '.item-content', function () {
			var $tab = $( this ),
				index = $tab.index(),
				$images = $tab.closest( '.ba-hero-slider' ).find( '.item-image' );

			$images.removeClass( 'active' );
			$tab.siblings().removeClass( 'active' );

			$tab.addClass( 'active' );
			$images.filter( ':eq(' + index + ')' ).addClass( 'active' );

		} );
	};

	// Vertical Swiper Slider
	baroque.vSwiperSlider = function () {
		if ( baroqueShortCode.length === 0 || typeof baroqueShortCode.baVsslider === 'undefined' ) {
			return;
		}
		$.each( baroqueShortCode.baVsslider, function ( id, carouselData ) {

				var $carouselID = $( document.getElementById( id ) );
				new Swiper( $carouselID, {
					paginationClickable         : true,
					nextButton                  : $carouselID.find( '.ba-button-next' ),
					prevButton                  : $carouselID.find( '.ba-button-prev' ),
					parallax                    : true,
					loop                        : true,
					direction                   : 'vertical',
					autoplay                    : carouselData.autoplay,
					autoplayDisableOnInteraction: false,
					speed                       : 1200,
					keyboardControl             : true,
					mousewheelControl           : true
				} );
			}
		);
	};

	// Vertical Swiper Slider 2
	baroque.vsSlider2 = function () {
		if ( baroqueShortCode.length === 0 || typeof baroqueShortCode.bavsSlider2 === 'undefined' ) {
			return;
		}
		$.each( baroqueShortCode.bavsSlider2, function ( id, carouselData ) {

				var $carouselID = $( document.getElementById( id ) );
				new Swiper( $carouselID, {
					paginationClickable         : true,
					nextButton                  : $carouselID.find( '.slick-next' ),
					prevButton                  : $carouselID.find( '.slick-prev' ),
					parallax                    : true,
					loop                        : true,
					direction                   : 'vertical',
					autoplay                    : carouselData.autoplay,
					autoplayDisableOnInteraction: false,
					speed                       : 1200,
					keyboardControl             : true,
					mousewheelControl           : true,
					onSlideChangeStart          : function () {
						$carouselID.find( '.vsslider-list' ).removeClass( 'active' );
					},
					onSlideChangeEnd            : function () {
						$carouselID.find( '.vsslider-list' ).addClass( 'active' );
					}
				} );

				setTimeout( function () {
					$carouselID.addClass( 'loaded' );
				}, 200 );
			}
		);
	};

	// Horizontal Swiper Slider
	baroque.hSwiperSlider = function () {
		if ( baroqueShortCode.length === 0 || typeof baroqueShortCode.baroqueHsslider === 'undefined' ) {
			return;
		}
		$.each( baroqueShortCode.baroqueHsslider, function ( id, carouselData ) {

				var $carouselID = $( document.getElementById( id ) );

				new Swiper( $carouselID, {
					paginationClickable         : true,
					nextButton                  : $carouselID.find( '.swiper-button-next' ),
					prevButton                  : $carouselID.find( '.swiper-button-prev' ),
					parallax                    : true,
					loop                        : true,
					autoplay                    : carouselData.autoplay,
					autoplayDisableOnInteraction: false,
					speed                       : 1500,
					keyboardControl             : false,
					mousewheelControl           : false
				} );
			}
		);
	};

	baroque.portfolioList1 = function () {
		var $portList1 = $( '.ba-portfolios-list.style-1' );

		if ( $portList1.length <= 0 ) {
			return;
		}

		$portList1.find( '.port-content' ).on( 'mouseenter', function () {
			$( this ).parent().addClass( 'active' );
		} );
		$portList1.find( '.port-content' ).on( 'mouseleave', function () {
			$( this ).parent().removeClass( 'active' );
		} );
	};

	baroque.portfolioList2 = function () {
		var $portList2 = $( '.ba-portfolios-list.style-2' );

		if ( $portList2.length <= 0 ) {
			return;
		}

		$portList2.find( '.port-content' ).on( 'mouseenter', function () {
			$portList2.find( '.port-item' ).removeClass( 'active' );
			$( this ).parent().addClass( 'active' );
		} );
	};

	baroque.portfolioListText = function () {
		var $portList2 = $( '.ba-portfolios-list.style-2' );

		if ( $portList2.length <= 0 ) {
			return;
		}

		$portList2.find( '.port-content' ).on( 'mouseenter', function () {
			var selectedImage = 'url("' + $( this ).data( 'image' ) + '")',
				$firstImage = $( this ).closest( '.port-list' ).find( '.port-first-image' ),
				$secondImage = $( this ).closest( '.port-list' ).find( '.port-second-image' );

			if ( $firstImage.hasClass( 'noactive' ) ) {
				var currentImage = $secondImage.css( 'background-image' );
				if ( currentImage !== selectedImage ) {
					$firstImage.css( {
						'background-image': 'url(' + $( this ).data( 'image' ) + ')'
					} );

					$firstImage.removeClass( 'noactive' );
					$secondImage.addClass( 'noactive' );
				}
			} else if ( $secondImage.hasClass( 'noactive' ) ) {
				var currImage = $firstImage.css( 'background-image' );
				if ( currImage !== selectedImage ) {
					$secondImage.css( {
						'background-image': 'url(' + $( this ).data( 'image' ) + ')'
					} );

					$secondImage.removeClass( 'noactive' );
					$firstImage.addClass( 'noactive' );
				}
			}
		} );
	};

	/**
	 * Event CountDown
	 */
	baroque.eventCountDown = function () {

		if ( $( '.ba-time-format' ).length <= 0 ) {
			return;
		}

		$( '.ba-time-format' ).each( function () {
			var $eventDate = $( this );

			var diff = $( this ).find( '.ba-time-countdown' ).html();

			$eventDate.find( '.ba-time-countdown' ).FlipClock( diff, {
				clockFace: 'DailyCounter',
				countdown: true,
				labels   : [baroqueShortCode.days, baroqueShortCode.hours, baroqueShortCode.minutes, baroqueShortCode.seconds]
			} );
		} );
	};

	/**
	 * Init Google maps
	 */
	baroque.gmaps = function () {

		if ( baroqueShortCode.length === 0 || typeof baroqueShortCode.map === 'undefined' ) {
			return;
		}

		var mapOptions = {
				scrollwheel       : false,
				draggable         : true,
				zoom              : 10,
				mapTypeId         : google.maps.MapTypeId.ROADMAP,
				panControl        : false,
				zoomControl       : true,
				zoomControlOptions: {
					style: google.maps.ZoomControlStyle.SMALL
				},
				scaleControl      : false,
				streetViewControl : false

			},
			customMap;

		$.each( baroqueShortCode.map, function ( id, mapData ) {

			var styles =
				[
					{
						'featureType': 'landscape.man_made',
						'elementType': 'geometry.fill',
						'stylers'    : [{ 'color': '#e9e5dc' }]
					},
					{
						'featureType': 'landscape.natural',
						'elementType': 'geometry.fill',
						'stylers'    : [{ 'visibility': 'on' }, { 'color': '#b8cb93' }]
					},
					{
						'featureType': 'poi',
						'elementType': 'all',
						'stylers'    : [{ 'visibility': 'off' }]
					},
					{
						'featureType': 'poi.business',
						'elementType': 'all',
						'stylers'    : [{ 'visibility': 'simplified' }]
					},
					{
						'featureType': 'poi.medical',
						'elementType': 'all',
						'stylers'    : [{ 'visibility': 'on' }]
					},
					{
						'featureType': 'poi.park',
						'elementType': 'all',
						'stylers'    : [{ 'visibility': 'on' }]
					},
					{
						'featureType': 'poi.park',
						'elementType': 'geometry.fill',
						'stylers'    : [{ 'color': '#ccdca1' }]
					},
					{
						'featureType': 'poi.sports_complex',
						'elementType': 'all',
						'stylers'    : [{ 'visibility': 'on' }]
					},
					{
						'featureType': 'road',
						'elementType': 'geometry.fill',
						'stylers'    : [{ 'hue': '#ff0000' }, { 'saturation': -100 }, { 'lightness': 99 }]
					},
					{
						'featureType': 'road',
						'elementType': 'geometry.stroke',
						'stylers'    : [{ 'color': '#808080' }, { 'lightness': 54 }, { 'visibility': 'off' }]
					},
					{
						'featureType': 'road',
						'elementType': 'labels.text.fill',
						'stylers'    : [{ 'color': '#767676' }]
					},
					{
						'featureType': 'road',
						'elementType': 'labels.text.stroke',
						'stylers'    : [{ 'color': '#ffffff' }]
					},
					{
						'featureType': 'water',
						'elementType': 'all',
						'stylers'    : [{ 'saturation': 43 }, { 'lightness': -11 }, { 'color': '#89cada' }]
					}
				];

			customMap = new google.maps.StyledMapType( styles,
				{ name: 'Styled Map' } );

			var map,
				marker,
				location = new google.maps.LatLng( mapData.lat, mapData.lng );

			// Update map options
			mapOptions.zoom = parseInt( mapData.zoom, 10 );
			mapOptions.center = location;
			mapOptions.mapTypeControlOptions = {
				mapTypeIds: [google.maps.MapTypeId.ROADMAP]
			};

			// Init map
			map = new google.maps.Map( document.getElementById( id ), mapOptions );

			// Create marker options
			var markerOptions = {
				map     : map,
				position: location
			};
			if ( mapData.marker ) {
				markerOptions.icon = {
					url: mapData.marker
				};
			}

			map.mapTypes.set( 'map_style', customMap );
			map.setMapTypeId( 'map_style' );

			// Init marker
			marker = new google.maps.Marker( markerOptions );

			//if (mapData.info) {
			//	var infoWindow = new google.maps.InfoWindow({
			//		content : '<div class="info-box mf-map">' + mapData.info + '</div>',
			//		maxWidth: 600
			//	});
			//
			//	google.maps.event.addListener(marker, 'click', function () {
			//		infoWindow.open(map, marker);
			//	});
			//}

		} );

		var $form = $( '.map-form' );

		$( '.toggle-form' ).on( 'click', function ( e ) {
			e.preventDefault();

			$form.toggleClass( 'show-form' );
		} );
	};

	baroque.portfolioFilter = function () {
		var $parent = $( '.ba-portfolios-grid' );

		if ( $parent.hasClass( 'portfolio-carousel' ) ) {
			return;
		}

		var mode = 'fitRows';

		if ( $parent.hasClass( 'portfolio-masonry' ) || $parent.hasClass( 'portfolio-metro' ) ) {
			mode = 'masonry';
		}

		baroque.$body.imagesLoaded( function () {
			$parent.find( '.list-portfolio' ).isotope( {
				itemSelector: '.portfolio-wrapper',
				layoutMode  : mode
			} );

		} );

		if ( !$parent.hasClass( 'filter-enable' ) ) {
			return;
		}

		$parent.find( '.filter li:first' ).addClass( 'active' );

		$parent.on( 'click', '.filter li', function ( e ) {
			e.preventDefault();

			var $this = $( this ),
				$grid = $this.closest( '.ba-portfolios-grid' );

			if ( $this.hasClass( 'active' ) ) {
				return;
			}

			$this.addClass( 'active' ).siblings( '.active' ).removeClass( 'active' );

			var filter = $this.attr( 'data-filter' );

			$grid.find( '.list-portfolio' ).isotope( { filter: filter } );
		} );
	};

	/**
	 * Products
	 */
	baroque.loadPortfolio = function () {
		baroque.$body.on( 'click', '.ajax-load-portfolio', function ( e ) {
			e.preventDefault();

			var $el = $( this ),
				page = $el.data( 'page' );

			if ( $el.hasClass( 'loading' ) ) {
				return;
			}

			$el.addClass( 'loading' );

			wp.ajax.send( 'baroque_load_portfolio', {
				data: {
					page : page,
					nonce: $el.data( 'nonce' ),
					style: $el.data( 'style' ),
					attr : $el.data( 'attr' )
				},

				success: function ( data ) {
					$el.removeClass( 'loading' );
					var $data = $( data ),
						$products = $data.find( '.portfolio-wrapper' ),
						$button = $data.find( '.ajax-load-portfolio' ),
						$container = $el.closest( '.ba-portfolios-grid' ),
						$grid = $container.find( '.list-portfolio' );

					// If has products
					if ( $products.length ) {
						// Add classes before append products to grid
						$products.addClass( 'portfolio-wrapper' );

						if ( $container.hasClass( 'filter-enable' ) ) {
							var index = 0;
							$products.each( function() {
								var $product = $( this );

								setTimeout( function() {
									$grid.isotope( 'insert', $product );
								}, index * 100 );

								index++;
							} );

							setTimeout(function() {
								$grid.isotope( 'layout' );
							}, index * 100 );

						} else {
							if ( !$container.hasClass( 'portfolio-carousel' ) ) {
								for ( var index = 0; index < $products.length; index++ ) {
									$( $products[index] ).css( 'animation-delay', index * 100 + 100 + 'ms' );
								}
								$products.addClass( 'baroqueFadeInUp baroqueAnimation' );
							}

							$grid.append( $products );
						}

						if ( $button.length ) {
							$el.replaceWith( $button );
						} else {
							$el.slideUp();
						}
					}
				}
			} );
		} );
	};

	/**
	 * Portfolio Carousel
	 */
	baroque.portfolioCarouselSwiper = function () {
		var $parent = $( '.ba-portfolios-grid' );

		if ( !$parent.hasClass( 'portfolio-carousel' ) ) {
			return;
		}

		var $section = $( '#ba-portfolio-vc' ),
			$frame = $section.find( '.portfolio-frame' );
		var options = {
			horizontal    : 1,
			activateOn    : 'click',
			activateMiddle: false,
			itemNav       : 'basic',
			startAt       : 0,
			scrollBar     : $section.find( '.scrollbar' ),
			pagesBar      : $section.find( '.pages' ),
			activatePageOn: 'click',
			speed         : 800,
			easing        : 'easeInOutCubic',
			clickBar      : 1,
			dragHandle    : 1,
			dynamicHandle : 1,
			touchDragging : 1,
			smart         : 1,
			cycleBy       : 'items',
			cycleInterval : 5000,
			pauseOnHover  : 1,
			startPaused   : true,

			// Buttons
			prev: $section.find( '.btn-prev' ),
			next: $section.find( '.btn-next' )
		};

		var $sliders = new Sly( $frame, options );

		$sliders.on( 'load move', function () {
			$section.addClass( 'loaded' );
		} );

		$sliders.init();

		$( window ).on( 'resize', function () {
			var wWidth = $( window ).width(),
				sWidth = wWidth - 40;

			if ( wWidth < 1024 ) {
				sWidth = wWidth - 20;
			}

			if ( wWidth < 1200 ) {
				$( '.list-portfolio' ).find( '.portfolio-wrapper' ).width( sWidth );
			} else {
				$( '.list-portfolio' ).find( '.portfolio-wrapper' ).removeAttr( 'style' );
			}

			$sliders.reload();
		} );
	};

	/**
	 * Document ready
	 */
	$( function () {
		baroque.init();
	} );

})( jQuery );