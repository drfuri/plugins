<?php
/**
 * Plugin Name: Baroque Addons
 * Plugin URI: http://demo2.drfuri.com/plugins/baroque-addons.zip
 * Description: Extra elements for Visual Composer. It was built for Baroque theme.
 * Version: 1.0.5
 * Author: Drfuri
 * Author URI: http://drfuri.com/
 * License: GPL2+
 * Text Domain: baroque
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'BAROQUE_ADDONS_DIR' ) ) {
	define( 'BAROQUE_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'BAROQUE_ADDONS_URL' ) ) {
	define( 'BAROQUE_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once BAROQUE_ADDONS_DIR . '/inc/visual-composer.php';
require_once BAROQUE_ADDONS_DIR . '/inc/shortcodes.php';
require_once BAROQUE_ADDONS_DIR . '/inc/portfolio.php';
require_once BAROQUE_ADDONS_DIR . '/inc/services.php';
require_once BAROQUE_ADDONS_DIR . '/inc/socials.php';
require_once BAROQUE_ADDONS_DIR . '/inc/user.php';
require_once BAROQUE_ADDONS_DIR . '/inc/widgets/widgets.php';

if ( is_admin() ) {
	require_once BAROQUE_ADDONS_DIR . '/inc/importer.php';
}

/**
 * Init
 */
function baroque_vc_addons_init() {
	load_plugin_textdomain( 'baroque', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

	new Baroque_VC;
	new Baroque_Shortcodes;
	new Baroque_Portfolio;
	new Baroque_Services;
}

add_action( 'after_setup_theme', 'baroque_vc_addons_init', 20 );
