<?php
/**
 * End of wrapper for modals.
 *
 * @since 9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
	</div>
</div>
