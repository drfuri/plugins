<?php
/**
 * Device select next to a responsive param label: shows the targeted device, lets the user switch it.
 *
 * Each option carries its icon; the edit element view turns the select into the picker.
 *
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$wpb_device_sizes = wpb_responsive()->devices()->get_preview_sizes();
?>
<select class="wpb_device-select" aria-label="<?php esc_attr_e( 'Device', 'js_composer' ); ?>">
	<?php foreach ( $wpb_device_sizes as $wpb_device_size ) : ?>
		<option value="<?php echo esc_attr( $wpb_device_size['device'] ); ?>" data-icon="<?php echo esc_attr( vc_get_template( 'icons/' . ( 'default' === $wpb_device_size['key'] ? 'desktop' : preg_replace( '/[^a-z0-9\-]/', '', $wpb_device_size['key'] ) ) . '-sm-ico.tpl.php' ) ); ?>"><?php echo esc_html( $wpb_device_size['title'] ); ?></option>
	<?php endforeach; ?>
</select>
