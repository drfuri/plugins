<?php
/**
 * Control Screen Size template.
 *
 * @var array $screen_sizes
 * @var string $title
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<li class="vc_pull-right">
	<div class="vc_dropdown" id="vc_screen-size-control">
		<a href="#" class="vc_dropdown-toggle vc_icon-btn" tabindex="7"
			title="<?php echo esc_attr( $title ); ?>"
			aria-label="<?php echo esc_attr( $title ); ?>"
			role="button" aria-haspopup="true">
			<span id="vc_screen-size-current" class="vc_screen-size-current">
				<?php vc_include_template( 'icons/desktop-ico.tpl.php' ); ?>
			</span>
		</a>
		<ul class="vc_dropdown-list" role="menu">
			<?php foreach ( $screen_sizes as $screen ) : ?>
				<li>
					<a href="#" class="vc_screen-width<?php echo empty( $screen['active'] ) ? '' : ' active'; ?>"
						title="<?php echo esc_attr( $screen['title'] ); ?>"
						aria-label="<?php echo esc_attr( $screen['title'] ); ?>"
						data-size="<?php echo esc_attr( $screen['size'] ); ?>"
						<?php echo isset( $screen['device'] ) ? 'data-device="' . esc_attr( $screen['device'] ) . '"' : ''; ?>>
						<span class="vc_screen-size-icon"><?php vc_include_template( 'icons/' . $screen['icon'] . '-ico.tpl.php' ); ?></span>
						<span class="vc_screen-size-label">
							<span class="vc_screen-size-title"><?php echo esc_html( $screen['title'] ); ?></span>
							<?php if ( ! empty( $screen['range_label'] ) ) : ?>
								<span class="vc_screen-size-range"><?php echo esc_html( $screen['range_label'] ); ?></span>
							<?php endif; ?>
						</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</li>
