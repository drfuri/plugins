<?php
/**
 * Responsive breakpoints resolution.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Where each device band starts, resolved from plugin settings.
 *
 * Values come from the Design Options settings, fall back to the customized
 * legacy breakpoints and finally to the defaults below, which are mirrored
 * in assets/less/config/variables.less.
 *
 * @since 9.1
 */
class Wpb_Responsive_Breakpoints {
	/**
	 * Settings option name prefix, without the plugin wide one.
	 *
	 * @since 9.1
	 * @var string
	 */
	const OPTION_PREFIX = 'responsive_breakpoint_';

	/**
	 * Band start in px, ascending.
	 *
	 * @since 9.1
	 * @var array
	 */
	const DEFAULTS = [
		'sm' => 640,
		'md' => 768,
		'lg' => 1024,
		'xl' => 1200,
	];

	/**
	 * Legacy options that seed a band, with the default they used to have.
	 *
	 * Bands are matched by role, e.g. the old stacking breakpoint becomes sm.
	 * A value equal to the old default means the user never changed it.
	 *
	 * @since 9.1
	 * @var array
	 */
	const LEGACY_OPTIONS = [
		'sm' => [ 'responsive_max', '768' ],
		'lg' => [ 'responsive_md', '992' ],
		'xl' => [ 'responsive_lg', '1200' ],
	];

	/**
	 * Resolved breakpoints, built once per request.
	 *
	 * @since 9.1
	 * @var array|null
	 */
	protected $breakpoints;

	/**
	 * Get all band starts.
	 *
	 * @since 9.1
	 * @return array Device key => min width px, ascending (sm, md, lg, xl).
	 */
	public function get_all() {
		if ( null === $this->breakpoints ) {
			$this->breakpoints = $this->resolve();
		}

		return $this->breakpoints;
	}

	/**
	 * Get a single band start.
	 *
	 * @since 9.1
	 * @param string $device_key Band key (sm, md, lg, xl).
	 * @return int
	 */
	public function get( $device_key ) {
		$breakpoints = $this->get_all();

		return isset( $breakpoints[ $device_key ] ) ? $breakpoints[ $device_key ] : 0;
	}

	/**
	 * Get settings key of a band, as the settings api expects it.
	 *
	 * @since 9.1
	 * @param string $device_key Band key (sm, md, lg, xl).
	 * @return string
	 */
	public function get_option_key( $device_key ) {
		return self::OPTION_PREFIX . $device_key;
	}

	/**
	 * Check that bands leave room for each other and for xs below sm.
	 *
	 * @since 9.1
	 * @param array $breakpoints Device key => min width px.
	 * @return bool
	 */
	protected function is_valid( array $breakpoints ) {
		$keys = array_keys( self::DEFAULTS );
		$previous = 1;
		foreach ( $keys as $key ) {
			if ( ! isset( $breakpoints[ $key ] ) || $breakpoints[ $key ] <= $previous ) {
				return false;
			}
			$previous = $breakpoints[ $key ];
		}

		return true;
	}

	/**
	 * Validate a new value for one band against the other saved ones.
	 *
	 * @since 9.1
	 * @param string $device_key Band key (sm, md, lg, xl).
	 * @param mixed $value Value entered by user.
	 * @param array $submitted Submitted values of the other bands.
	 * @return int|null Validated value, null when it is not a usable breakpoint.
	 */
	public function validate( $device_key, $value, array $submitted = [] ) {
		if ( ! is_numeric( $value ) ) {
			return null;
		}

		$candidate = array_merge( $this->get_all(), $submitted );
		$candidate[ $device_key ] = (int) $value;

		return $this->is_valid( $candidate ) ? (int) $value : null;
	}

	/**
	 * Forget resolved values, e.g. after options change.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function flush() {
		$this->breakpoints = null;
	}

	/**
	 * Delete saved breakpoints, including the legacy ones that seed them.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function reset() {
		foreach ( array_keys( self::DEFAULTS ) as $device_key ) {
			delete_option( Vc_Settings::$field_prefix . $this->get_option_key( $device_key ) );
		}
		foreach ( self::LEGACY_OPTIONS as $legacy ) {
			delete_option( Vc_Settings::$field_prefix . $legacy[0] );
		}
		wpb_responsive()->flush();
	}

	/**
	 * Resolve bands, dropping the legacy seeds when they do not fit the new bands.
	 *
	 * @since 9.1
	 * @return array
	 */
	protected function resolve() {
		$breakpoints = $this->build( true );
		if ( $this->is_valid( $breakpoints ) ) {
			return $breakpoints;
		}

		$breakpoints = $this->build( false );

		return $this->is_valid( $breakpoints ) ? $breakpoints : self::DEFAULTS;
	}

	/**
	 * Build the set from saved options.
	 *
	 * @since 9.1
	 * @param bool $use_legacy Whether customized legacy values seed unsaved bands.
	 * @return array
	 */
	protected function build( $use_legacy ) {
		$breakpoints = [];
		foreach ( self::DEFAULTS as $device_key => $default ) {
			$value = vc_settings()->get( self::OPTION_PREFIX . $device_key );
			if ( ! is_numeric( $value ) && $use_legacy ) {
				$value = $this->get_legacy_value( $device_key );
			}
			$breakpoints[ $device_key ] = is_numeric( $value ) ? (int) $value : $default;
		}

		return $breakpoints;
	}

	/**
	 * Get the legacy value of a band when user customized it.
	 *
	 * @since 9.1
	 * @param string $device_key Band key (sm, md, lg, xl).
	 * @return int|null
	 */
	protected function get_legacy_value( $device_key ) {
		if ( ! isset( self::LEGACY_OPTIONS[ $device_key ] ) ) {
			return null;
		}

		list( $option, $old_default ) = self::LEGACY_OPTIONS[ $device_key ];
		$value = vc_settings()->get( $option );

		if ( ! is_numeric( $value ) || (string) $value === $old_default ) {
			return null;
		}

		return (int) $value;
	}
}
