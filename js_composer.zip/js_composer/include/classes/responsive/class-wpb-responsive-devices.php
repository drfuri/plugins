<?php
/**
 * Responsive device bands.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Device bands built on top of the breakpoints.
 *
 * Single source for every consumer: editor preview sizes, generated media
 * queries and the device list localized to the editors.
 *
 * @since 9.1
 */
class Wpb_Responsive_Devices {
	/**
	 * Width the smallest band previews at when the band is wide enough for it.
	 *
	 * @since 9.1
	 * @var int
	 */
	const SMALLEST_PREVIEW_WIDTH = 480;

	/**
	 * Breakpoints the bands are built from.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Breakpoints
	 */
	protected $breakpoints;

	/**
	 * Device bands, built once per request.
	 *
	 * @since 9.1
	 * @var array|null
	 */
	protected $devices;

	/**
	 * Wpb_Responsive_Devices constructor.
	 *
	 * @since 9.1
	 * @param Wpb_Responsive_Breakpoints $breakpoints
	 */
	public function __construct( Wpb_Responsive_Breakpoints $breakpoints ) {
		$this->breakpoints = $breakpoints;
	}

	/**
	 * Get all bands, widest first.
	 *
	 * Every band has: key, title, the min/max width it covers, preview_key used
	 * by the editor preview control, preview_width and is_default.
	 *
	 * @since 9.1
	 * @return array[]
	 */
	protected function get_all() {
		if ( null === $this->devices ) {
			$this->devices = $this->build();
		}

		return $this->devices;
	}

	/**
	 * Get band keys, widest first.
	 *
	 * @since 9.1
	 * @return string[]
	 */
	public function get_keys() {
		return wp_list_pluck( $this->get_all(), 'key' );
	}

	/**
	 * Get the editor icon of each band, widest first.
	 *
	 * @since 9.1
	 * @return array Device key => icon name.
	 */
	public function get_icons() {
		return wp_list_pluck( $this->get_all(), 'icon', 'key' );
	}

	/**
	 * Get the media query a band applies in.
	 *
	 * Bands are closed ranges, so a value set on one never leaks into another.
	 *
	 * @since 9.1
	 * @param string $device_key Band key.
	 * @return string
	 */
	public function get_media_query( $device_key ) {
		foreach ( $this->get_all() as $device ) {
			if ( $device['key'] !== $device_key ) {
				continue;
			}

			$parts = [];
			if ( ! empty( $device['min'] ) ) {
				$parts[] = '(min-width: ' . $device['min'] . 'px)';
			}
			if ( ! empty( $device['max'] ) ) {
				$parts[] = '(max-width: ' . $device['max'] . 'px)';
			}

			return empty( $parts ) ? '' : '@media ' . implode( ' and ', $parts );
		}

		return '';
	}

	/**
	 * Get the media query a band value applies from, down to the narrowest band.
	 *
	 * Rules written widest first let narrower bands inherit the value until they set their own.
	 *
	 * @since 9.1
	 * @param string $device_key Band key.
	 * @return string
	 */
	public function get_cascade_media_query( $device_key ) {
		foreach ( $this->get_all() as $device ) {
			if ( $device['key'] === $device_key ) {
				return empty( $device['max'] ) ? '' : '@media (max-width: ' . $device['max'] . 'px)';
			}
		}

		return '';
	}

	/**
	 * Get bands for the editor preview control in the navbar.
	 *
	 * Every entry has: title, size (css width of the preview), key (preview
	 * control key), device (band key) and the min/max the band covers.
	 *
	 * @since 9.1
	 * @return array[]
	 */
	public function get_preview_sizes() {
		$sizes = [];
		foreach ( $this->get_all() as $device ) {
			$size = [
				'title' => $device['title'],
				'size' => is_int( $device['preview_width'] ) ? $device['preview_width'] . 'px' : $device['preview_width'],
				'key' => $device['preview_key'],
				'device' => $device['key'],
				'min' => $device['min'],
				'max' => $device['max'],
			];
			if ( $device['is_default'] ) {
				$size['active'] = true;
			}
			$sizes[] = $size;
		}

		return $sizes;
	}

	/**
	 * Forget built bands, e.g. after breakpoints change.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function flush() {
		$this->devices = null;
	}

	/**
	 * Build bands from the current breakpoints.
	 *
	 * @since 9.1
	 * @return array[]
	 */
	protected function build() {
		$breakpoints = $this->breakpoints->get_all();
		$devices = [
			[
				'key' => 'xl',
				'icon' => 'desktop',
				'title' => esc_html__( 'Desktop', 'js_composer' ),
				'min' => $breakpoints['xl'],
				'max' => null,
				'preview_key' => 'default',
				'preview_width' => '100%',
				'is_default' => true,
			],
			[
				'key' => 'lg',
				'icon' => 'tablet-landscape',
				'title' => esc_html__( 'Tablet horizontal', 'js_composer' ),
				'min' => $breakpoints['lg'],
				'max' => $breakpoints['xl'] - 1,
				'preview_key' => 'landscape-tablets',
				'preview_width' => $breakpoints['lg'],
				'is_default' => false,
			],
			[
				'key' => 'md',
				'icon' => 'tablet-portrait',
				'title' => esc_html__( 'Tablet vertical', 'js_composer' ),
				'min' => $breakpoints['md'],
				'max' => $breakpoints['lg'] - 1,
				'preview_key' => 'portrait-tablets',
				'preview_width' => $breakpoints['md'],
				'is_default' => false,
			],
			[
				'key' => 'sm',
				'icon' => 'mobile-landscape',
				'title' => esc_html__( 'Mobile horizontal', 'js_composer' ),
				'min' => $breakpoints['sm'],
				'max' => $breakpoints['md'] - 1,
				'preview_key' => 'landscape-smartphones',
				'preview_width' => $breakpoints['sm'],
				'is_default' => false,
			],
			[
				'key' => 'xs',
				'icon' => 'mobile-portrait',
				'title' => esc_html__( 'Mobile vertical', 'js_composer' ),
				'min' => null,
				'max' => $breakpoints['sm'] - 1,
				'preview_key' => 'portrait-smartphones',
				'preview_width' => min( self::SMALLEST_PREVIEW_WIDTH, $breakpoints['sm'] - 1 ),
				'is_default' => false,
			],
		];

		return $devices;
	}
}
