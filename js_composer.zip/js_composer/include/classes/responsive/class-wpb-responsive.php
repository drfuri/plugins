<?php
/**
 * Responsive feature facade.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Single entry point to the responsive services.
 *
 * Devices are derived from breakpoints and params from devices.
 *
 * @since 9.1
 */
class Wpb_Responsive {
	/**
	 * Breakpoint resolution.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Breakpoints|null
	 */
	protected $breakpoints;

	/**
	 * Device bands derived from the breakpoints.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Devices|null
	 */
	protected $devices;

	/**
	 * Per device shortcode params.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Params|null
	 */
	protected $params;

	/**
	 * Per device element hiding.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Hide|null
	 */
	protected $hide;

	/**
	 * Legacy hide migration.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Hide_Migration|null
	 */
	protected $hide_migration;

	/**
	 * Get breakpoint resolution.
	 *
	 * @since 9.1
	 * @return Wpb_Responsive_Breakpoints
	 */
	public function breakpoints() {
		if ( ! isset( $this->breakpoints ) ) {
			require_once vc_path_dir( 'RESPONSIVE_DIR', 'class-wpb-responsive-breakpoints.php' );
			$this->breakpoints = new Wpb_Responsive_Breakpoints();
		}

		return $this->breakpoints;
	}

	/**
	 * Get device bands.
	 *
	 * @since 9.1
	 * @return Wpb_Responsive_Devices
	 */
	public function devices() {
		if ( ! isset( $this->devices ) ) {
			require_once vc_path_dir( 'RESPONSIVE_DIR', 'class-wpb-responsive-devices.php' );
			$this->devices = new Wpb_Responsive_Devices( $this->breakpoints() );
		}

		return $this->devices;
	}

	/**
	 * Get per device params.
	 *
	 * @since 9.1
	 * @return Wpb_Responsive_Params
	 */
	public function params() {
		if ( ! isset( $this->params ) ) {
			require_once vc_path_dir( 'RESPONSIVE_DIR', 'class-wpb-responsive-params.php' );
			$this->params = new Wpb_Responsive_Params( $this->devices() );
		}

		return $this->params;
	}

	/**
	 * Get per device element hiding.
	 *
	 * @since 9.1
	 * @return Wpb_Responsive_Hide
	 */
	public function hide() {
		if ( ! isset( $this->hide ) ) {
			require_once vc_path_dir( 'RESPONSIVE_DIR', 'class-wpb-responsive-hide.php' );
			$this->hide = new Wpb_Responsive_Hide( $this->devices(), $this->params() );
		}

		return $this->hide;
	}

	/**
	 * Get the legacy hide migration.
	 *
	 * @since 9.1
	 * @return Wpb_Responsive_Hide_Migration
	 */
	public function hide_migration() {
		if ( ! isset( $this->hide_migration ) ) {
			require_once vc_path_dir( 'MIGRATIONS_DIR', 'class-wpb-responsive-hide-migration.php' );
			$this->hide_migration = new Wpb_Responsive_Hide_Migration( $this->devices(), $this->params() );
		}

		return $this->hide_migration;
	}

	/**
	 * Rebuild the params generated for an element after one of its params was added, changed or removed.
	 *
	 * Params changed with vc_add_param(), vc_update_shortcode_param() or vc_remove_param() land after
	 * 'vc_element_settings_filter' ran, so their per device params and the hide param are built here.
	 *
	 * @since 9.2
	 * @param array $settings Element settings.
	 * @param string $param_name Param added, changed or removed.
	 * @param bool $is_new Whether the param was added, not replaced or changed.
	 * @return array
	 */
	public function refresh_element_params( $settings, $param_name, $is_new = false ) {
		if ( empty( $settings['params'] ) || ! is_array( $settings['params'] ) ) {
			return $settings;
		}
		// Its bands are rebuilt from the new settings.
		$settings['params'] = array_filter( $settings['params'], function ( $param ) use ( $param_name ) {
			return ( $param['responsive_base'] ?? '' ) !== $param_name;
		} );
		// Only a new css editor brings the hide param, so a removed one stays removed.
		$index = array_search( $param_name, wp_list_pluck( $settings['params'], 'param_name' ), true );
		if ( $is_new && false !== $index && 'css_editor' === ( $settings['params'][ $index ]['type'] ?? '' ) ) {
			$settings = $this->hide()->inject_param( $settings );
		}

		return $this->params()->expand_element_settings( $settings );
	}

	/**
	 * Forget everything resolved from the breakpoints.
	 *
	 * Call it after breakpoint options change: devices are derived from them,
	 * so they must not keep serving values built from the previous set.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function flush() {
		$this->breakpoints()->flush();
		$this->devices()->flush();
	}
}
