<?php
/**
 * Per device element hiding.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Hides elements on the device bands they were switched off for.
 *
 * The value lives in the `hide_element` param, which is responsive like any other.
 *
 * @since 9.1
 */
class Wpb_Responsive_Hide {
	/**
	 * Param the value is stored in.
	 *
	 * @since 9.1
	 * @var string
	 */
	const PARAM = 'hide_element';

	/**
	 * Class prefix marking a band the element hides on.
	 *
	 * @since 9.1
	 * @var string
	 */
	const CLASS_PREFIX = 'vc_hidden-';

	/**
	 * Device bands the value is resolved against.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Devices
	 */
	protected $devices;

	/**
	 * Params the bands are read from.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Params
	 */
	protected $params;

	/**
	 * Wpb_Responsive_Hide constructor.
	 *
	 * @since 9.1
	 * @param Wpb_Responsive_Devices $devices
	 * @param Wpb_Responsive_Params $params
	 */
	public function __construct( Wpb_Responsive_Devices $devices, Wpb_Responsive_Params $params ) {
		$this->devices = $devices;
		$this->params = $params;
	}

	/**
	 * Register the hooks the feature runs on.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function init() {
		add_filter( 'vc_element_settings_filter', [ $this, 'inject_param' ], 9 );
		add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, [ $this, 'add_css_classes' ], 10, 3 );
		add_filter( 'vc_shortcode_output', [ $this, 'remove_when_hidden_everywhere' ], 10, 3 );
		add_filter( 'do_shortcode_tag', [ $this, 'remove_when_hidden_everywhere' ], 10, 3 );
		add_filter( 'vc_get_editor_wpb_data', [ $this, 'add_editor_data' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'add_band_css' ], 20 );
	}

	/**
	 * Give every element with Design Options the param the toggle writes to.
	 *
	 * @since 9.1
	 * @param array $settings Element settings.
	 * @return array
	 */
	public function inject_param( $settings ) {
		if ( empty( $settings['params'] ) || ! is_array( $settings['params'] ) ) {
			return $settings;
		}
		if ( in_array( self::PARAM, wp_list_pluck( $settings['params'], 'param_name' ), true ) ) {
			return $settings;
		}
		$css_editor = array_search( 'css_editor', wp_list_pluck( $settings['params'], 'type' ), true );
		if ( false === $css_editor || false === ( $settings['params'][ $css_editor ]['settings']['hide_toggle'] ?? true ) ) {
			return $settings;
		}

		$settings['params'][] = [
			'type' => 'hidden',
			'param_name' => self::PARAM,
			'copy-paste-value' => true,
			'settings' => [
				'responsive' => ! empty( $settings['params'][ $css_editor ]['settings']['responsive'] ),
				'default' => 'false',
			],
		];

		return $settings;
	}

	/**
	 * Resolve whether an element hides on each device band.
	 *
	 * A band without a value inherits the nearest wider band, the widest one inherits the base.
	 *
	 * @since 9.1
	 * @param mixed $atts Shortcode attributes.
	 * @param string $tag Shortcode tag, band values are ignored when its hide param is not responsive.
	 * @return array Device key => whether the element hides there.
	 */
	public function get_map( $atts, $tag = '' ) {
		if ( ! is_array( $atts ) ) {
			return [];
		}

		$keys = $this->devices->get_keys();
		$is_hidden = 'true' === ( $atts[ self::PARAM ] ?? '' );
		if ( $tag && ! $this->is_responsive( $tag ) ) {
			return array_fill_keys( $keys, $is_hidden );
		}

		$bands = $this->params->get_values( $atts, self::PARAM );

		$map = [];
		foreach ( $keys as $device_key ) {
			if ( isset( $bands[ $device_key ] ) ) {
				$is_hidden = 'true' === $bands[ $device_key ];
			}
			$map[ $device_key ] = $is_hidden;
		}

		return $map;
	}

	/**
	 * Whether an element maps its hide param per device.
	 *
	 * @since 9.1
	 * @param string $tag Shortcode tag.
	 * @return bool
	 */
	protected function is_responsive( $tag ) {
		$settings = WPBMap::getShortCode( $tag );
		foreach ( (array) ( $settings['params'] ?? [] ) as $param ) {
			if ( self::PARAM === ( $param['param_name'] ?? '' ) ) {
				return ! empty( $param['settings']['responsive'] );
			}
		}

		return false;
	}

	/**
	 * Whether an element has the param the toggle writes to.
	 *
	 * @since 9.2
	 * @param string $tag Shortcode tag.
	 * @return bool
	 */
	public function has_param( $tag ) {
		$settings = WPBMap::getShortCode( $tag );

		return in_array( self::PARAM, wp_list_pluck( (array) ( $settings['params'] ?? [] ), 'param_name' ), true );
	}

	/**
	 * Get the classes marking the bands an element hides on.
	 *
	 * @since 9.1
	 * @param mixed $atts Shortcode attributes.
	 * @param string $tag Shortcode tag.
	 * @return array
	 */
	public function get_classes( $atts, $tag = '' ) {
		$classes = [];
		foreach ( $this->get_map( $atts, $tag ) as $device_key => $is_hidden ) {
			if ( $is_hidden ) {
				$classes[] = self::CLASS_PREFIX . $device_key;
			}
		}

		return $classes;
	}

	/**
	 * Append the hidden band classes to the element wrapper classes.
	 *
	 * @since 9.1
	 * @param string $css_class Element classes.
	 * @param string $tag Shortcode tag.
	 * @param mixed $atts Shortcode attributes.
	 * @return string
	 */
	public function add_css_classes( $css_class, $tag = '', $atts = [] ) {
		$hide_classes = $this->get_classes( $atts, $tag );
		if ( ! $hide_classes ) {
			return $css_class;
		}
		$existing = preg_split( '/\s+/', (string) $css_class, -1, PREG_SPLIT_NO_EMPTY );

		return implode( ' ', array_unique( array_merge( $existing, $hide_classes ) ) );
	}

	/**
	 * Hidden on every band keeps the element out of the public output; editors keep it dimmed.
	 *
	 * @since 9.1
	 * @param string $output Shortcode output.
	 * @param WPBakeryShortCode|string $shortcode Shortcode object, or its tag for custom elements.
	 * @param mixed $atts Shortcode attributes.
	 * @return string
	 */
	public function remove_when_hidden_everywhere( $output, $shortcode, $atts ) {
		if ( vc_is_page_editable() || ! is_array( $atts ) || ( is_string( $shortcode ) && ! WPBMap::exists( $shortcode ) ) ) {
			return $output;
		}
		$tag = is_object( $shortcode ) ? $shortcode->getShortcode() : (string) $shortcode;
		$map = $this->get_map( wpb_responsive()->hide_migration()->migrate_atts( $atts ), $tag );

		return $map && ! in_array( false, $map, true ) ? '' : $output;
	}

	/**
	 * Get the band rules built from the breakpoint settings.
	 *
	 * @since 9.1
	 * @return string
	 */
	protected function get_band_css() {
		$css = '';
		foreach ( $this->devices->get_keys() as $device_key ) {
			$rule = '.' . self::CLASS_PREFIX . $device_key . '{display:none!important}';
			$query = $this->devices->get_media_query( $device_key );
			$css .= $query ? $query . '{' . $rule . '}' : $rule;
		}

		return $css;
	}

	/**
	 * Attach the band rules to the front stylesheet, which only loads with VC content.
	 *
	 * The editor gets none: hidden elements are dimmed there instead.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function add_band_css() {
		if ( vc_is_page_editable() ) {
			return;
		}
		wp_add_inline_style( 'js_composer_front', $this->get_band_css() );
	}

	/**
	 * Share the device keys and their media queries with the editors.
	 *
	 * @since 9.1
	 * @param array $data Editor data.
	 * @return array
	 */
	public function add_editor_data( $data ) {
		$data['responsiveDevices'] = array_map( fn( $key ) => [
			'key' => $key,
			'mediaQuery' => trim( str_replace( '@media', '', $this->devices->get_media_query( $key ) ) ),
		], $this->devices->get_keys() );

		return $data;
	}
}
