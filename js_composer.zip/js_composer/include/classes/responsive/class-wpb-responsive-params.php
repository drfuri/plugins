<?php
/**
 * Responsive shortcode params.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Per device values for mapped params.
 *
 * A param mapped with 'settings' => [ 'responsive' => true ] gets one param per band, e.g.
 * css_animation_wpb_md. A band left empty falls back to the base param.
 *
 * @since 9.1
 */
class Wpb_Responsive_Params {
	/**
	 * Separates the base param name from the band key.
	 *
	 * @since 9.1
	 * @var string
	 */
	const SEPARATOR = '_wpb_';

	/**
	 * Params that can be responsive: param name => param type.
	 *
	 * @since 9.1
	 * @var array
	 */
	const SUPPORTED_PARAMS = [
		'css' => 'css_editor',
		'css_animation' => 'animation_style',
		'hide_element' => 'hidden',
	];

	/**
	 * Device bands the params are generated for.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Devices
	 */
	protected $devices;

	/**
	 * Css of the elements rendered so far, keyed by their class.
	 *
	 * @since 9.1
	 * @var array
	 */
	protected $inline_css = [];

	/**
	 * Whether the class filter already offered the element its per device class.
	 *
	 * @since 9.1
	 * @var bool
	 */
	protected $element_class_used = false;

	/**
	 * Shortcodes being rendered, innermost last: tag and atts of custom elements, null for ours, and the class state of their parent.
	 *
	 * @since 9.1
	 * @var array
	 */
	protected $rendering = [];

	/**
	 * Wpb_Responsive_Params constructor.
	 *
	 * @since 9.1
	 * @param Wpb_Responsive_Devices $devices
	 */
	public function __construct( Wpb_Responsive_Devices $devices ) {
		$this->devices = $devices;
	}

	/**
	 * Register the hooks the per device params run on.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function init() {
		add_filter( 'vc_shortcode_prepare_atts', [ $this, 'start_element' ] );
		add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, [ $this, 'add_element_class' ], 10, 3 );
		add_filter( 'pre_do_shortcode_tag', [ $this, 'start_shortcode' ], PHP_INT_MAX, 3 );
		add_filter( 'do_shortcode_tag', [ $this, 'end_shortcode' ] );
	}

	/**
	 * Custom elements, rendered by their own shortcode callback, get the per device css our elements get.
	 *
	 * @since 9.1
	 * @param false|string $output Short-circuited output.
	 * @param string $tag Shortcode tag.
	 * @param mixed $atts Shortcode attributes.
	 * @return false|string
	 */
	public function start_shortcode( $output, $tag, $atts ) {
		if ( false !== $output ) {
			return $output;
		}
		global $shortcode_tags;
		$callback = $shortcode_tags[ $tag ] ?? null;
		$is_ours = 'vc_do_shortcode' === $callback || ( is_array( $callback ) && $callback[0] instanceof WPBakeryShortCodeFishBones );
		$is_custom = ! $is_ours && is_array( $atts ) && WPBMap::exists( $tag );
		$this->rendering[] = [ $is_custom ? [ $tag, $atts ] : null, $this->element_class_used ];
		if ( $is_custom ) {
			$this->start_element( $atts );
			$this->add_design_options_css( $atts );
		}

		return $output;
	}

	/**
	 * End of a shortcode render.
	 *
	 * @since 9.1
	 * @param string $output Shortcode output.
	 * @return string
	 */
	public function end_shortcode( $output ) {
		$shortcode = array_pop( $this->rendering );
		if ( $shortcode ) {
			$this->element_class_used = $shortcode[1];
		}

		return $output;
	}

	/**
	 * Get the custom element being rendered.
	 *
	 * @since 9.1
	 * @return array|null Tag and atts.
	 */
	public function get_custom_element() {
		return $this->rendering ? end( $this->rendering )[0] : null;
	}

	/**
	 * Start of an element render: it does not carry its per device class yet.
	 *
	 * @since 9.1
	 * @param array $atts Shortcode attributes.
	 * @return array
	 */
	public function start_element( $atts ) {
		$this->element_class_used = false;

		return $atts;
	}



	/**
	 * Give the element the class its per device css is written for.
	 *
	 * Elements that build their classes through getExtraClass() already carry it.
	 *
	 * @since 9.1
	 * @param string $css_class Element classes.
	 * @param string $tag Shortcode tag.
	 * @param mixed $atts Shortcode attributes.
	 * @return string
	 */
	public function add_element_class( $css_class, $tag = '', $atts = [] ) {
		if ( $this->element_class_used ) {
			return $css_class;
		}
		$element_class = $this->get_element_class( (array) $atts );
		if ( '' === $element_class ) {
			return $css_class;
		}

		// Elements that filter a second class list, like the button inside its wrapper, keep it off.
		$this->element_class_used = true;

		return vc_has_class( $element_class, (string) $css_class ) ? $css_class : $css_class . ' ' . $element_class;
	}

	/**
	 * Add the per device params to the mapped element settings.
	 *
	 * @since 9.1
	 * @param array $settings Element settings.
	 * @return array
	 */
	public function expand_element_settings( $settings ) {
		if ( empty( $settings['params'] ) || ! is_array( $settings['params'] ) ) {
			return $settings;
		}

		$expanded = [];
		foreach ( $settings['params'] as $param ) {
			if ( ! empty( $param['responsive_base'] ) ) {
				$expanded[] = $param['responsive_base'];
			}
		}
		$params = [];
		foreach ( $settings['params'] as $param ) {
			$param = $this->drop_unsupported_responsive( $param );
			$param = $this->drop_css_editor_heading_device_dropdown( $param );
			$params[] = $param;

			if ( ! $this->is_responsive_param( $param ) || in_array( $param['param_name'], $expanded, true ) ) {
				continue;
			}

			foreach ( $this->devices->get_keys() as $device_key ) {
				$params[] = $this->build_device_param( $param, $device_key );
			}
		}
		$settings['params'] = $params;

		return $settings;
	}

	/**
	 * Get the param name a band stores its value in.
	 *
	 * @since 9.1
	 * @param string $param_name Base param name.
	 * @param string $device_key Band key.
	 * @return string
	 */
	public function get_param_name( $param_name, $device_key ) {
		return $param_name . self::SEPARATOR . $device_key;
	}

	/**
	 * Get every value a param was given, keyed by band, widest first.
	 *
	 * Bands left empty are not in the list, so the caller only gets the values
	 * that were really set.
	 *
	 * @since 9.1
	 * @param array $atts Shortcode attributes.
	 * @param string $param_name Base param name.
	 * @return array
	 */
	public function get_values( $atts, $param_name ) {
		$values = [];
		foreach ( $this->devices->get_keys() as $device_key ) {
			$name = $this->get_param_name( $param_name, $device_key );
			if ( isset( $atts[ $name ] ) && '' !== $atts[ $name ] ) {
				$values[ $device_key ] = $atts[ $name ];
			}
		}

		return $values;
	}

	/**
	 * Get the class carrying the per device css of an element.
	 *
	 * Built on the fly from the values, like the vc_custom_ class of the design
	 * options, so nothing is stored in the shortcode.
	 *
	 * @since 9.1
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function get_element_class( $atts ) {
		$keys = array_map( fn( $key ) => preg_quote( $key, '/' ), $this->devices->get_keys() );
		$suffix = '/' . preg_quote( self::SEPARATOR, '/' ) . '(' . implode( '|', $keys ) . ')$/';
		$values = [];
		foreach ( $atts as $name => $value ) {
			if ( '' !== $value && preg_match( $suffix, $name ) ) {
				$values[ $name ] = $value;
			}
		}

		if ( empty( $values ) ) {
			return '';
		}

		return 'wpb_responsive_' . substr( md5( wp_json_encode( $values ) ), 0, 10 );
	}

	/**
	 * Add the css an element needs on the bands it styles.
	 *
	 * Every band value is turned into a declaration by the caller, this only
	 * wraps it in the selector and the media query of its band. Narrower bands
	 * inherit the value of the nearest wider band that sets one.
	 *
	 * @since 9.1
	 * @param string $selector Selector the rules are written for.
	 * @param array $values Band key => value.
	 * @param callable $to_declaration Turns one band value into a css declaration.
	 * @return void
	 */
	public function add_css( $selector, $values, callable $to_declaration ) {
		$css = '';
		foreach ( $values as $device_key => $value ) {
			$rule = $selector . '{' . $to_declaration( $value ) . '}';
			$query = $this->devices->get_cascade_media_query( $device_key );
			$css .= $query ? $query . '{' . $rule . '}' : $rule;
		}
		$this->inline_css[ md5( $selector . wp_json_encode( $values ) ) ] = $css;
	}

	/**
	 * Add the design options an element set on single bands.
	 *
	 * A band holds a full rule of its own, the declarations are taken out of it
	 * and written against the class of the element.
	 *
	 * @since 9.1
	 * @param array $atts Shortcode attributes.
	 * @return void
	 */
	public function add_design_options_css( $atts ) {
		$bands = $this->get_values( $atts, 'css' );
		if ( empty( $bands ) ) {
			return;
		}

		$this->add_css( '.' . $this->get_element_class( $atts ), $bands, function ( $rules ) {
			return preg_replace( '/\s*\.[^{]+\{\s*([^}]*)\s*\}\s*/', '$1', $rules );
		} );
	}

	/**
	 * Print the css collected while rendering the page.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function print_inline_css() {
		if ( empty( $this->inline_css ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<style data-type="wpb-responsive-css">' . wp_strip_all_tags( implode( '', $this->inline_css ) ) . '</style>';
	}

	/**
	 * Only our params render per device values, the flag is removed from any other param.
	 *
	 * @since 9.1
	 * @param array $param Param settings.
	 * @return array
	 */
	protected function drop_unsupported_responsive( $param ) {
		if ( ! empty( $param['params'] ) && is_array( $param['params'] ) ) {
			// No bands are built inside a param group.
			foreach ( array_keys( $param['params'] ) as $index ) {
				unset( $param['params'][ $index ]['settings']['responsive'] );
			}
		}
		if ( empty( $param['settings']['responsive'] ) || ! empty( $param['responsive_base'] ) ) {
			return $param;
		}
		$name = $param['param_name'] ?? '';
		if ( ( self::SUPPORTED_PARAMS[ $name ] ?? null ) !== ( $param['type'] ?? '' ) ) {
			unset( $param['settings']['responsive'] );
		}

		return $param;
	}

	/**
	 * The css editor has a device dropdown on each of its fields, its heading gets none.
	 *
	 * @since 9.2
	 * @param array $param Param settings.
	 * @return array
	 */
	protected function drop_css_editor_heading_device_dropdown( $param ) {
		if ( 'css_editor' === ( $param['type'] ?? '' ) ) {
			$param['settings']['heading_device_dropdown'] = false;
		}

		return $param;
	}

	/**
	 * Check whether a param asked for per device values.
	 *
	 * @since 9.1
	 * @param array $param Param settings.
	 * @return bool
	 */
	protected function is_responsive_param( $param ) {
		return ! empty( $param['settings']['responsive'] )
			&& empty( $param['responsive_base'] )
			&& ! empty( $param['param_name'] )
			&& 'content' !== $param['param_name'];
	}

	/**
	 * Build the param a single band stores its value in.
	 *
	 * @since 9.1
	 * @param array $param Base param settings.
	 * @param string $device_key Band key.
	 * @return array
	 */
	protected function build_device_param( $param, $device_key ) {
		$holder_class = isset( $param['param_holder_class'] ) ? $param['param_holder_class'] . ' ' : '';

		$param['responsive_base'] = $param['param_name'];
		$param['responsive_device'] = $device_key;
		$param['param_name'] = $this->get_param_name( $param['param_name'], $device_key );
		$param['param_holder_class'] = $holder_class . 'wpb-responsive-param wpb-responsive-param-' . $device_key;

		// Empty means "inherit", so a band must not fall back to the default of the base param.
		$param['settings']['default'] = '';
		$param['std'] = '';
		$param['admin_label'] = false;
		unset( $param['save_always'] );

		return $param;
	}
}
