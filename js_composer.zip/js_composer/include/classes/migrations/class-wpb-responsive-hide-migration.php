<?php
/**
 * Per device hide migration.
 *
 * @package WPBakeryPageBuilder
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Moves the legacy per device hides onto the hide_element param.
 *
 * Handles three shapes kept for bc: offset vc_hidden-* tokens, a comma
 * separated device list and the row wide hide toggle.
 *
 * @since 9.1
 */
class Wpb_Responsive_Hide_Migration {
	/**
	 * Token the legacy hides are written with.
	 *
	 * @since 9.1
	 * @var string
	 */
	const TOKEN = 'vc_hidden-';

	/**
	 * Attribute the legacy row toggle is stored in.
	 *
	 * @since 9.1
	 * @var string
	 */
	const ROW_TOGGLE = 'disable_element';

	/**
	 * Param the resolved value is stored in.
	 *
	 * @since 9.1
	 * @var string
	 */
	const PARAM = 'hide_element';

	/**
	 * Device bands the tokens are matched against.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Devices
	 */
	protected $devices;

	/**
	 * Params the bands are written to.
	 *
	 * @since 9.1
	 * @var Wpb_Responsive_Params
	 */
	protected $params;

	/**
	 * Wpb_Responsive_Hide_Migration constructor.
	 *
	 * @since 9.1
	 * @param Wpb_Responsive_Devices $devices
	 * @param Wpb_Responsive_Params $params
	 */
	public function __construct( Wpb_Responsive_Devices $devices, Wpb_Responsive_Params $params ) {
		$this->devices = $devices;
		$this->params = $params;
	}

	/**
	 * Register the hooks the migration runs on.
	 *
	 * @since 9.1
	 * @return void
	 */
	public function init() {
		add_filter( 'wp_insert_post_data', [ $this, 'migrate_post_content' ] );
		add_filter( 'vc_map_get_attributes', [ $this, 'migrate_atts' ], 9 );
		add_filter( 'vc_edit_form_fields_attributes', [ $this, 'migrate_atts' ] );
	}

	/**
	 * Decide the value each band ends up with.
	 *
	 * The base takes the widest band. Narrower bands inherit the band above them, so a
	 * band is stored wherever it differs from the one it inherits, keeping each legacy
	 * device toggle on its own band.
	 *
	 * @since 9.1
	 * @param array $device_keys Bands the element hides on.
	 * @return array Base value and the band values to write.
	 */
	protected function resolve( array $device_keys ) {
		$all_keys = $this->devices->get_keys();
		$base = in_array( reset( $all_keys ), $device_keys, true );

		$bands = [];
		$inherited = $base;
		foreach ( $all_keys as $device_key ) {
			$is_hidden = in_array( $device_key, $device_keys, true );
			if ( $is_hidden !== $inherited ) {
				$bands[ $device_key ] = $is_hidden ? 'true' : 'false';
			}
			$inherited = $is_hidden;
		}

		return [
			'base' => $base ? 'true' : 'false',
			'bands' => $bands,
		];
	}

	/**
	 * Read the bands out of a legacy column offset value.
	 *
	 * @since 9.1
	 * @param string $offset Column offset attribute value.
	 * @return array Bands read and the tokens they were read from.
	 */
	protected function read_offset( $offset ) {
		if ( ! function_exists( 'wpb_normalize_column_offset_hidden' ) ) {
			require_once vc_path_dir( 'PARAMS_DIR', '/column_offset/column_offset.php' );
		}
		$offset = wpb_normalize_column_offset_hidden( $offset );
		$pattern = '/\s*' . preg_quote( self::TOKEN, '/' ) . '(' . $this->device_keys_pattern() . ')(?=\s|$)/';
		preg_match_all( $pattern, $offset, $tokens );

		return [
			'offset' => $offset,
			'keys' => $tokens[1],
			'tokens' => $tokens[0],
		];
	}

	/**
	 * Read the bands out of a legacy comma separated list of device keys.
	 *
	 * @since 9.1
	 * @param mixed $value hide_element value.
	 * @return array
	 */
	protected function read_list( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^' . $this->device_list_pattern() . '$/', $value ) ) {
			return [];
		}

		return array_map( 'trim', explode( ',', $value ) );
	}

	/**
	 * Get the pattern matching a hide_element attribute holding a list of device keys.
	 *
	 * @since 9.1
	 * @return string
	 */
	protected function attribute_list_pattern() {
		return '/\shide_element="(' . $this->device_list_pattern() . ')"/';
	}

	/**
	 * Get the alternation matching any device band key.
	 *
	 * @since 9.1
	 * @return string
	 */
	protected function device_keys_pattern() {
		return implode( '|', array_map( fn( $key ) => preg_quote( $key, '/' ), $this->devices->get_keys() ) );
	}

	/**
	 * Get the pattern matching a list of device keys.
	 *
	 * @since 9.1
	 * @return string
	 */
	protected function device_list_pattern() {
		$keys = $this->device_keys_pattern();

		return '(?:' . $keys . ')(?:\s*,\s*(?:' . $keys . '))*';
	}

	/**
	 * Convert the legacy hide attributes of one element while it is read.
	 *
	 * @since 9.1
	 * @param mixed $atts Shortcode attributes.
	 * @return mixed
	 */
	public function migrate_atts( $atts ) {
		if ( ! is_array( $atts ) ) {
			return $atts;
		}

		$device_keys = $this->read_list( $atts[ self::PARAM ] ?? '' );
		$has_legacy = (bool) $device_keys;

		if ( ! empty( $atts['offset'] ) && false !== strpos( $atts['offset'], self::TOKEN ) ) {
			$offset = $this->read_offset( $atts['offset'] );
			$device_keys = array_merge( $device_keys, $offset['keys'] );
			$atts['offset'] = trim( preg_replace( '/\s+/', ' ', str_replace( $offset['tokens'], '', $offset['offset'] ) ) );
			$has_legacy = true;
		}

		if ( 'yes' === ( $atts[ self::ROW_TOGGLE ] ?? '' ) ) {
			$device_keys = $this->devices->get_keys();
			$atts[ self::ROW_TOGGLE ] = '';
			$has_legacy = true;
		}

		if ( ! $has_legacy ) {
			return $atts;
		}

		$resolved = $this->resolve( $device_keys );
		$atts[ self::PARAM ] = $resolved['base'];
		foreach ( $resolved['bands'] as $device_key => $value ) {
			$atts[ $this->params->get_param_name( self::PARAM, $device_key ) ] = $value;
		}

		return $atts;
	}

	/**
	 * Check whether a content string still carries legacy hides.
	 *
	 * @since 9.1
	 * @param mixed $content Post content.
	 * @return bool
	 */
	public function has_legacy_hide( $content ) {
		if ( ! is_string( $content ) ) {
			return false;
		}

		return false !== strpos( $content, self::TOKEN )
			|| false !== strpos( $content, self::ROW_TOGGLE . '="yes"' )
			|| (bool) preg_match( $this->attribute_list_pattern(), $content );
	}

	/**
	 * Move the per device hides of a post onto hide_element while it is saved.
	 *
	 * Hooked on the post data because the backend editor lets WordPress write the content.
	 *
	 * @since 9.1
	 * @param array $data Sanitized post data, slashed.
	 * @return array
	 */
	public function migrate_post_content( $data ) {
		if ( empty( $data['post_content'] ) ) {
			return $data;
		}

		$content = wp_unslash( $data['post_content'] );
		$migrated = $this->migrate_content( $content );
		if ( $migrated === $content ) {
			return $data;
		}

		$data['post_content'] = wp_slash( $migrated );

		return $data;
	}

	/**
	 * Rewrite every shortcode that still hides per device onto hide_element.
	 *
	 * @since 9.1
	 * @param mixed $content Post content.
	 * @return mixed Content with the tokens moved, untouched when there are none.
	 */
	public function migrate_content( $content ) {
		if ( ! $this->has_legacy_hide( $content ) ) {
			return $content;
		}

		// Matches one shortcode tag; quoted values may hold the ] the tag ends with.
		$migrated = preg_replace_callback(
			'/\[([a-z0-9_]+)((?:[^\]"]|"[^"]*")*)\]/i',
			[ $this, 'migrate_shortcode' ],
			$content
		);

		return null === $migrated ? $content : $migrated;
	}

	/**
	 * Move the tokens of a single shortcode tag.
	 *
	 * @since 9.1
	 * @param array $matches Shortcode tag, its name and its attribute string.
	 * @return string
	 */
	protected function migrate_shortcode( $matches ) {
		list( $tag, $name, $attributes ) = $matches;

		$atts = $this->parse_attributes( $attributes );
		$migrated = $this->migrate_atts( $atts );
		if ( $migrated === $atts ) {
			return $tag;
		}

		return '[' . $name . $this->write_attributes( $attributes, $atts, $migrated ) . ']';
	}

	/**
	 * Read the attributes of a shortcode tag into an array.
	 *
	 * @since 9.1
	 * @param string $attributes Shortcode attribute string.
	 * @return array
	 */
	protected function parse_attributes( $attributes ) {
		preg_match_all( '/\s([a-z0-9_]+)="([^"]*)"/i', $attributes, $found, PREG_SET_ORDER );

		$atts = [];
		foreach ( $found as $match ) {
			$atts[ $match[1] ] = $match[2];
		}

		return $atts;
	}

	/**
	 * Write the converted attributes back, leaving the untouched ones as they were.
	 *
	 * @since 9.1
	 * @param string $attributes Shortcode attribute string.
	 * @param array $before Attributes as they were read.
	 * @param array $after Attributes after the conversion.
	 * @return string
	 */
	protected function write_attributes( $attributes, array $before, array $after ) {
		foreach ( $after as $name => $value ) {
			if ( ( $before[ $name ] ?? null ) === $value ) {
				continue;
			}
			$attributes = $this->is_stored( $name, $value )
				? $this->set_attribute( $attributes, $name, $value )
				: $this->remove_attribute( $attributes, $name );
		}

		foreach ( $before as $name => $value ) {
			if ( ! $this->is_stored( $name, $value ) ) {
				$attributes = $this->remove_attribute( $attributes, $name );
			}
		}

		return $attributes;
	}

	/**
	 * Check whether an attribute carries anything worth keeping in the content.
	 *
	 * A band keeps any value, even one equal to the base, as it stops the band
	 * inheriting from the band above it.
	 *
	 * @since 9.1
	 * @param string $name Attribute name.
	 * @param string $value Attribute value.
	 * @return bool
	 */
	protected function is_stored( $name, $value ) {
		if ( self::ROW_TOGGLE === $name ) {
			return '' !== $value;
		}
		if ( self::PARAM === $name ) {
			return 'false' !== $value;
		}
		if ( 0 === strpos( $name, self::PARAM . Wpb_Responsive_Params::SEPARATOR ) ) {
			return '' !== $value;
		}

		return true;
	}

	/**
	 * Drop one attribute from the attribute string.
	 *
	 * @since 9.1
	 * @param string $attributes Shortcode attribute string.
	 * @param string $name Attribute name.
	 * @return string
	 */
	protected function remove_attribute( $attributes, $name ) {
		return preg_replace( '/\s' . preg_quote( $name, '/' ) . '="[^"]*"/', '', $attributes );
	}

	/**
	 * Write one attribute into the attribute string, replacing it when it is already there.
	 *
	 * @since 9.1
	 * @param string $attributes Shortcode attribute string.
	 * @param string $name Attribute name.
	 * @param string $value Attribute value.
	 * @return string
	 */
	protected function set_attribute( $attributes, $name, $value ) {
		$written = ' ' . $name . '="' . $value . '"';
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '="[^"]*"/', $attributes, $existing ) ) {
			return str_replace( $existing[0], $written, $attributes );
		}

		return $attributes . $written;
	}
}
