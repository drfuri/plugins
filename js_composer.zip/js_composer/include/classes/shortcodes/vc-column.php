<?php
/**
 * Class that handles specific [vc_column] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_column.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * WPBakery Page Builder shortcodes
 *
 * @package WPBakeryPageBuilder
 */
class WPBakeryShortCode_VC_Column extends WPBakeryShortCode {
	/**
	 * Class for non draggable column.
	 *
	 * @var string
	 */
	public $nonDraggableClass = 'vc-non-draggable-column';

	/**
	 * WPBakeryShortCode_VC_Column constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );
		$this->shortcodeScripts();
	}

	/**
	 * Register shortcode scripts.
	 */
	protected function shortcodeScripts() {
		wp_register_script( 'vc_jquery_skrollr_js', vc_asset_url( 'lib/vendor/dist/skrollr/dist/skrollr.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		wp_register_script( 'vc_youtube_iframe_api_js', 'https://www.youtube.com/iframe_api', [], WPB_VC_VERSION, true );
		wp_register_script( 'wpb_video_bg_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_video_bg_container.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		// wpb_parallax_container relies on window.vc_initVideoBackgrounds running first; depend on it so it's always enqueued alongside.
		wp_register_script( 'wpb_parallax_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_parallax_container.min.js' ), [ 'jquery-core', 'wpb_video_bg_container' ], WPB_VC_VERSION, true );
	}

	/**
	 * Get column control settings.
	 *
	 * @since 9.0
	 *
	 * @param string $extended_css
	 * @return array
	 */
	public function get_column_control_settings( $extended_css = '' ) {
		$settings = [];
		$move_access = vc_user_access()->part( 'dragndrop' )->checkStateAny( true, null )->get();

		if ( $move_access ) {
			$settings['move'] = [
				'classes' => 'column_move vc_column-move',
				'title'   => __( 'Drag to move this column', 'js_composer' ),
				'icon'    => 'vc-c-param-group-dragndrop',
			];
		}

		$settings += [
			'edit'  => [
				'classes' => 'column_edit vc_column-edit',
				'title'   => __( 'Edit this column', 'js_composer' ),
				'icon'    => 'vc-c-edit',
			],
			'paste' => [
				'classes' => 'column_paste vc_column-paste',
				'title'   => __( 'Paste', 'js_composer' ),
				'icon'    => 'vc-c-icon-paste',
			],
			'delete' => [
				'classes' => 'column_delete vc_column-delete',
				'title'   => __( 'Delete this column', 'js_composer' ),
				'icon'    => 'vc-c-trash',
			],
		];

		if ( false !== strpos( $extended_css, 'bottom-controls' ) ) {
			$control_title = __( 'Append to this column', 'js_composer' );
		} else {
			$control_title = __( 'Prepend to this column', 'js_composer' );
		}
		$add_icon = 'vc-c-add-circle';

		if ( vc_user_access()->part( 'shortcodes' )->checkStateAny( true, 'custom', null )->get() ) {
			$settings['add'] = [
				'classes' => 'column_add vc_column-add',
				'title' => $control_title,
				'icon' => $add_icon,
			];
		}

		return $settings;
	}

	/**
	 * Attach element controls buttons to shortcode output in editor.
	 *
	 * @param mixed $controls
	 * @param string $extended_css
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function getColumnControls( $controls, $extended_css = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$output = '<div class="vc_controls vc_control-column vc_controls-visible' . ( ! empty( $extended_css ) ? " {$extended_css}" : '' ) . '">';
		$controls_end = '</div>';

		$control_list = $this->get_column_controls_html_list( $extended_css );
		$controls_move = $control_list['move'] ?? '';
		$controls_edit = $control_list['edit'];
		$controls_paste = $control_list['paste'];
		$controls_delete = $control_list['delete'];
		$controls_add = $control_list['add'] ?? '';

		$editAccess = vc_user_access_check_shortcode_edit( $this->shortcode );
		$allAccess = vc_user_access_check_shortcode_all( $this->shortcode );
		$controls_menu = $this->getColumnControlsMenu( $extended_css, $editAccess, $allAccess );
		if ( is_array( $controls ) && ! empty( $controls ) ) {
			foreach ( $controls as $control ) {
				if ( 'add' === $control || ( $editAccess && 'edit' === $control ) || $allAccess ) {
					$method_name = vc_camel_case( 'output-editor-control-' . $control );
					if ( method_exists( $this, $method_name ) ) {
						$output .= $this->$method_name();
					} else {
						$control_var = 'controls_' . $control;
						if ( isset( ${$control_var} ) ) {
							$output .= ${$control_var};
						}
					}
				}
			}

			return $output . $controls_end;
		} elseif ( is_string( $controls ) && 'full' === $controls ) {
			if ( $allAccess ) {
				return $output . $controls_move . $controls_add . $controls_edit . $controls_paste . $controls_delete . $controls_menu . $controls_end;
			} elseif ( $editAccess ) {
				return $output . $controls_add . $controls_edit . $controls_paste . $controls_menu . $controls_end;
			}

			return $output . $controls_add . $controls_end;
		} elseif ( is_string( $controls ) ) {
			$control_var = 'controls_' . $controls;
			if ( 'add' === $controls || ( $editAccess && 'edit' === $controls || $allAccess ) && isset( ${$control_var} ) ) {
				return $output . ${$control_var} . $controls_end;
			}

			return $output . $controls_end;
		}
		if ( $allAccess ) {
			return $output . $controls_move . $controls_add . $controls_edit . $controls_paste . $controls_delete . $controls_menu . $controls_end;
		} elseif ( $editAccess ) {
			return $output . $controls_add . $controls_edit . $controls_paste . $controls_menu . $controls_end;
		}

		return $output . $controls_add . $controls_end;
	}

	/**
	 * Get responsive column controls menu.
	 *
	 * @param string $extended_css
	 * @param bool $edit_access
	 * @param bool $all_access
	 * @return string
	 */
	protected function getColumnControlsMenu( $extended_css, $edit_access, $all_access ) {
		if ( false !== strpos( $extended_css, 'bottom-controls' ) ) {
			return '';
		}

		$settings = $this->get_column_control_settings( $extended_css );
		$actions = [
			'add' => [
				'label' => esc_html__( 'Add element', 'js_composer' ),
				'allowed' => ! empty( $settings['add'] ),
			],
			'edit' => [
				'label' => esc_html__( 'Edit column', 'js_composer' ),
				'allowed' => $edit_access || $all_access,
			],
			'paste' => [
				'label' => esc_html__( 'Paste', 'js_composer' ),
				'allowed' => $edit_access || $all_access,
			],
			'delete' => [
				'label' => esc_html__( 'Delete column', 'js_composer' ),
				'allowed' => $all_access,
			],
		];
		$menu_actions = [];

		foreach ( $actions as $action => $action_settings ) {
			if ( empty( $settings[ $action ] ) || empty( $action_settings['allowed'] ) ) {
				continue;
			}

			$menu_actions[ $action ] = [
				'icon' => $settings[ $action ]['icon'],
				'label' => $action_settings['label'],
			];
		}

		return vc_get_template( 'editors/partials/backend_column_controls_menu.tpl.php', [
			'actions' => $menu_actions,
		] );
	}

	/**
	 * Update old and new param names.
	 *
	 * @param array $param
	 * @param string $value
	 *
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) {
		$output = '';
		// Compatibility fixes.
		$old_names = [
			'yellow_message',
			'blue_message',
			'green_message',
			'button_green',
			'button_grey',
			'button_yellow',
			'button_blue',
			'button_red',
			'button_orange',
		];
		$new_names = [
			'alert-block',
			'alert-info',
			'alert-success',
			'btn-success',
			'btn',
			'btn-info',
			'btn-primary',
			'btn-danger',
			'btn-warning',
		];
		$value = str_ireplace( $old_names, $new_names, $value );
		$param_name = $param['param_name'] ?? '';
		$type = $param['type'] ?? '';
		$class = $param['class'] ?? '';

		if ( isset( $param['holder'] ) && 'hidden' !== $param['holder'] ) {
			$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '">' . $value . '</' . $param['holder'] . '>';
		}

		return $output;
	}

	/**
	 * Get admin output.
	 *
	 * @param array $atts
	 * @param null|string $content
	 *
	 * @return string
	 */
	public function contentAdmin( $atts, $content = null ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
		extract( $atts );

		$width = $atts['width'] ?? '';
		$this->atts = $atts;

		$output = '';

		$column_controls = $this->getColumnControls( $this->settings( 'controls' ) );
		$column_controls_bottom = $this->getColumnControls( 'add', 'bottom-controls' );

		if ( 'column_14' === $width || '1/4' === $width ) {
			$width = [ 'vc_col-sm-3' ];
		} elseif ( 'column_14-14-14-14' === $width ) {
			$width = [
				'vc_col-sm-3',
				'vc_col-sm-3',
				'vc_col-sm-3',
				'vc_col-sm-3',
			];
		} elseif ( 'column_13' === $width || '1/3' === $width ) {
			$width = [ 'vc_col-sm-4' ];
		} elseif ( 'column_13-23' === $width ) {
			$width = [
				'vc_col-sm-4',
				'vc_col-sm-8',
			];
		} elseif ( 'column_13-13-13' === $width ) {
			$width = [
				'vc_col-sm-4',
				'vc_col-sm-4',
				'vc_col-sm-4',
			];
		} elseif ( 'column_12' === $width || '1/2' === $width ) {
			$width = [ 'vc_col-sm-6' ];
		} elseif ( 'column_12-12' === $width ) {
			$width = [
				'vc_col-sm-6',
				'vc_col-sm-6',
			];
		} elseif ( 'column_23' === $width || '2/3' === $width ) {
			$width = [ 'vc_col-sm-8' ];
		} elseif ( 'column_34' === $width || '3/4' === $width ) {
			$width = [ 'vc_col-sm-9' ];
		} elseif ( 'column_16' === $width || '1/6' === $width ) {
			$width = [ 'vc_col-sm-2' ];
		} elseif ( ' column_56' === $width || ' 5/6' === $width ) {
			$width = [ 'vc_col-sm-10' ];
		} else {
			$width = [ '' ];
		}
		$count = count( $width );
		for ( $i = 0; $i < $count; $i++ ) {
			$output .= '<div ' . $this->mainHtmlBlockParams( $width, $i ) . '>';
			$output .= str_replace( '%column_size%', wpb_translateColumnWidthToFractional( $width[ $i ] ), $column_controls );
			$output .= '<div class="wpb_element_wrapper">';
			$output .= '<div ' . $this->containerHtmlBlockParams( '', '' ) . '>';
			$output .= do_shortcode( shortcode_unautop( $content ) );
			$output .= '</div>';
			if ( isset( $this->settings['params'] ) ) {
				$inner = '';
				foreach ( $this->settings['params'] as $param ) {
					$param_value = ${$param['param_name']} ?? '';
					if ( is_array( $param_value ) ) {
						// Get first element from the array.
						reset( $param_value );
						$first_key = key( $param_value );
						$param_value = $param_value[ $first_key ];
					}
					$inner .= $this->singleParamHtmlHolder( $param, $param_value );
				}
				$output .= $inner;
			}
			$output .= '</div>';
			$output .= str_replace( '%column_size%', wpb_translateColumnWidthToFractional( $width[ $i ] ), $column_controls_bottom );
			$output .= '</div>';
		}

		return $output;
	}

	/**
	 * Set custom admin block params.
	 *
	 * @return string
	 */
	public function customAdminBlockParams() {
		return '';
	}

	/**
	 * Get main html block params.
	 *
	 * @param array $width
	 * @param int $i
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function mainHtmlBlockParams( $width, $i ) {
		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) ? 'wpb_sortable' : $this->nonDraggableClass );

		return 'data-element_type="' . $this->settings['base'] . '" data-vc-column-width="' . wpb_vc_get_column_width_indent( $width[ $i ] ) . '" class="wpb_' . $this->settings['base'] . ' ' . $sortable . '' . ( ! empty( $this->settings['class'] ) ? ' ' . $this->settings['class'] : '' ) . ' ' . $this->templateWidth() . ' wpb_content_holder"' . $this->customAdminBlockParams();
	}

	/**
	 * Get container html block classes.
	 *
	 * @since 9.1 The `$width` and `$i` parameters are deprecated and unused.
	 *
	 * @param string $deprecated Not used.
	 * @param string $deprecated_2 Not used.
	 *
	 * @return string
	 */
	public function containerHtmlBlockParams( $deprecated, $deprecated_2 ) {
		if ( '' !== $deprecated ) {
			_deprecated_argument( __METHOD__, '9.1', '$width' );
		}
		if ( '' !== $deprecated_2 ) {
			_deprecated_argument( __METHOD__, '9.1', '$i' );
		}

		return 'class="wpb_column_container vc_container_for_children"';
	}

	/**
	 * Get element output.
	 *
	 * @param string $content
	 *
	 * @return string
	 */
	public function template( $content = '' ) {
		return $this->contentAdmin( $this->atts );
	}

	/**
	 * Add with attributes to element output.
	 *
	 * @return string
	 */
	protected function templateWidth() {
		return '<%= window.vc_convert_column_size(params.width) %>';
	}

	/**
	 * Build styles.
	 *
	 * @param string $font_color
	 *
	 * @return string
	 */
	public function buildStyle( $font_color = '' ) {
		$style = '';
		if ( ! empty( $font_color ) ) {
			$style .= vc_get_css_color( 'color', $font_color );
		}

		return empty( $style ) ? $style : ' style="' . esc_attr( $style ) . '"';
	}
}
