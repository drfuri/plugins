<?php
/**
 * Class that handles specific [vc_facebook] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_facebook.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Facebook
 */
class WPBakeryShortCode_Vc_Facebook extends WPBakeryShortCode {
	/**
	 * Get shortcode inline html.
	 *
	 * @param array $atts
	 * @param null $content
	 * @return string
	 * @throws \Exception
	 */
	protected function contentInline( $atts, $content = null ) {
		$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
		extract( $atts );

		/**
		 * Shortcode attributes
		 *
		 * @var array $atts
		 * @var string $type
		 * @var string $css_animation
		 */

		$url = get_permalink();

		$css = $atts['css'] ?? '';
		$el_class = $atts['el_class'] ?? '';

		$class_to_filter = 'wpb_googleplus vc_social-placeholder wpb_content_element vc_socialtype-' . $type;
		$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation );
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

		return '<a href="' . esc_url( $url ) . '" class="' . esc_attr( $css_class ) . '"></a>';
	}
}
