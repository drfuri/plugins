<?php
/**
 * Autoload hooks related grids
 *
 * @note we require our autoload files everytime and everywhere after plugin load.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

add_action( 'vc_load_default_params', [ 'Vc_Grid_Item', 'load_grid_item_param' ] );

if ( vc_is_page_editable() ) {
	add_filter( 'vc_gitem_post_data_get_link_link', [ 'Vc_Grid_Item', 'get_link_frontend_editor' ] );
	add_filter( 'vc_gitem_post_data_get_link_real_link', [ 'Vc_Grid_Item', 'get_link_frontend_editor' ] );
	add_filter( 'vc_gitem_post_data_get_link_target', [ 'Vc_Grid_Item', 'get_link_target_frontend_editor' ] );
	add_filter( 'vc_gitem_post_data_get_link_rel', [ 'Vc_Grid_Item', 'get_link_rel_frontend_editor' ] );
	add_filter( 'vc_gitem_post_data_get_link_real_target', [ 'Vc_Grid_Item', 'get_link_target_frontend_editor' ] );
	add_filter( 'vc_gitem_post_data_get_link_real_rel', [ 'Vc_Grid_Item', 'get_link_rel_frontend_editor' ] );
}
