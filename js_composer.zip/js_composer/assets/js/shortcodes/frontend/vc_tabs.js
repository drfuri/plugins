( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_tabsBehaviour ) ) {
		/**
		 * Tabs + Tours
		 * @param $tab
		 * @deprecated
		 */
		window.vc_tabsBehaviour = function ( $tab ) {
			if ( jQuery.ui ) {
				const $call = $tab || jQuery( '.wpb_tabs, .wpb_tour' );
				const ver = jQuery.ui && jQuery.ui.version ? jQuery.ui.version.split( '.' ) : '1.10';
				const oldVersion = 1 === parseInt( ver[ 0 ], 10 ) && 9 > parseInt( ver[ 1 ], 10 );
				$call.each( function () {
					const interval = jQuery( this ).attr( 'data-interval' );
					const tabsArray = [];
					const $tabs = jQuery( this ).find( '.wpb_tour_tabs_wrapper' ).tabs({
						show ( event, ui ) {
							wpb_prepare_tab_content( event, ui );
						},
						activate ( event, ui ) {
							wpb_prepare_tab_content( event, ui );
						}
					});

					/**
					 * Select the previous/next tab for the jQuery UI < 1.9 API.
					 * @param isNext
					 */
					function selectOldVersionTab ( isNext ) {
						let index = $tabs.tabs( 'option', 'selected' );
						index = isNext ? index + 1 : index - 1;
						if ( 0 > index ) {
							index = $tabs.tabs( 'length' ) - 1;
						} else if ( index >= $tabs.tabs( 'length' ) ) {
							index = 0;
						}
						$tabs.tabs( 'select', index );
					}

					/**
					 * Activate the previous/next tab for the current jQuery UI API.
					 * @param isNext
					 */
					function activateTab ( isNext ) {
						const index = $tabs.tabs( 'option', 'active' );
						const { length } = $tabs.find( '.wpb_tab' );
						const nextIndex = isNext ?
							( ( index + 1 ) >= length ? 0 : index + 1 ) :
							( 0 > index - 1 ? length - 1 : index - 1 );
						$tabs.tabs( 'option', 'active', nextIndex );
					}

					if ( interval && 0 < interval ) {
						try {
							$tabs.tabs( 'rotate', interval * 1000 );
						} catch ( err ) {
							if ( window.console && window.console.warn ) {
								console.warn( 'tabs behaviours error', err );
							}
						}
					}

					jQuery( this ).find( '.wpb_tab' ).each( function () {
						tabsArray.push( this.id );
					});

					jQuery( this ).find( '.wpb_tabs_nav li' ).on( 'click', function ( e ) {
						if ( e && e.preventDefault ) {
							e.preventDefault();
						}
						if ( oldVersion ) {
							$tabs.tabs( 'select', jQuery( 'a', this ).attr( 'href' ) );
						} else {
							$tabs.tabs( 'option', 'active', jQuery( this ).index() );
						}
						return false;
					});

					jQuery( this ).find( '.wpb_prev_slide a, .wpb_next_slide a' ).on( 'click', function ( e ) {
						if ( e && e.preventDefault ) {
							e.preventDefault();
						}
						const isNext = jQuery( this ).parent().hasClass( 'wpb_next_slide' );
						if ( oldVersion ) {
							selectOldVersionTab( isNext );
						} else {
							activateTab( isNext );
						}
						return false;
					});
				});
			}
		};
	}

	jQuery( () => window.vc_tabsBehaviour() );
})();
