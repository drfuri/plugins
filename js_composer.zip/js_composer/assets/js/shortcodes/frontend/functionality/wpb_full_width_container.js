( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_fullWidthRow ) ) {
		function clampToZero ( value ) {
			return 0 > value ? 0 : value;
		}

		/**
		 * Compute the left/right padding that keeps a full-width row's content
		 * aligned with the rest of the layout.
		 * @param isRtl
		 * @param offset
		 * @param width
		 * @param $elFull
		 * @param marginLeft
		 * @param marginRight
		 */
		function computeFullWidthPadding ( isRtl, offset, width, $elFull, marginLeft, marginRight ) {
			if ( isRtl ) {
				return {
					padding: clampToZero( offset ),
					paddingRight: clampToZero( offset )
				};
			}
			const padding = clampToZero( - 1 * offset );
			const paddingRight = clampToZero( width - padding - $elFull.width() + marginLeft + marginRight );
			return { padding, paddingRight };
		}

		window.vc_fullWidthRow = function () {
			const $ = window.jQuery;
			if ( 'undefined' !== typeof window.wpb_disable_full_width_row_js && window.wpb_disable_full_width_row_js ) {
				return;
			}
			const $elements = $( '[data-vc-full-width="true"]' );
			$.each( $elements, function () {
				const $el = $( this );
				$el.addClass( 'vc_hidden' );

				let $elFull = $el.next( '.vc_row-full-width' );
				if ( !$elFull.length ) {
					$elFull = $el.parent().next( '.vc_row-full-width' ); // need for vc_ie-flexbox-fixer
				}
				if ( !$elFull.length ) {
					return;
				}
				$el.removeAttr( 'data-vc-full-width-temp' );

				const marginLeft = parseInt( $el.css( 'margin-left' ), 10 );
				const marginRight = parseInt( $el.css( 'margin-right' ), 10 );
				const isRtl = 'rtl' === $el.css( 'direction' );
				const width = $( window ).width();
				let offset = 0 - $elFull.offset().left - marginLeft;
				if ( isRtl ) {
					offset -= $elFull.width();
					offset += width;
					offset += marginLeft;
					offset += marginRight;
				}

				const cssProps = {
					'position': 'relative',
					'left': offset,
					'box-sizing': 'border-box',
					width,
					'max-width': width
				};

				$el.css( cssProps );

				if ( !$el.data( 'vcStretchContent' ) ) {
					const { padding, paddingRight } = computeFullWidthPadding( isRtl, offset, width, $elFull, marginLeft, marginRight );
					$el.css({ 'padding-left': `${padding}px`, 'padding-right': `${paddingRight}px` });
				}
				$el.attr( 'data-vc-full-width-init', 'true' );
				$el.removeClass( 'vc_hidden' );
				$( document ).trigger( 'vc-full-width-row-single', {
					el: $el,
					offset,
					marginLeft,
					marginRight,
					elFull: $elFull,
					width,
					maxWidth: width
				});
			});
			$( document ).trigger( 'vc-full-width-row', $elements );
		};
	}

	jQuery( () => {
		jQuery( window ).off( 'resize.vcFullWidthRow' ).on( 'resize.vcFullWidthRow', window.vc_fullWidthRow );
		window.vc_fullWidthRow();
	});
})();
