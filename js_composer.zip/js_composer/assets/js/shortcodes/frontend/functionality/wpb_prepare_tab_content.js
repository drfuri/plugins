( function () {
	'use strict';
	if ( 'function' !== typeof ( window.wpb_prepare_tab_content ) ) {
		/**
		 * Reinitialize any masonry grid nested inside a tab/accordion panel.
		 * @param $scope
		 */
		function refreshMasonryGrids ( $scope ) {
			$scope.find( '.vc_masonry_media_grid, .vc_masonry_grid' ).each( function () {
				const grid = jQuery( this ).data( 'vcGrid' );
				if ( grid && grid.gridBuilder && grid.gridBuilder.setMasonry ) {
					grid.gridBuilder.setMasonry();
				}
			});
		}

		/**
		 * Reinitialize charts that couldn't render correctly while hidden.
		 * @param $pieCharts
		 * @param $roundCharts
		 * @param $lineCharts
		 */
		function reinitializeCharts ( $pieCharts, $roundCharts, $lineCharts ) {
			if ( $pieCharts.length && jQuery.fn.vcChat ) {
				$pieCharts.vcChat();
			}
			if ( $roundCharts.length && jQuery.fn.vcRoundChart ) {
				$roundCharts.vcRoundChart({ reload: false });
			}
			if ( $lineCharts.length && jQuery.fn.vcLineChart ) {
				$lineCharts.vcLineChart({ reload: false });
			}
		}

		/**
		 * Resize a Bootstrap-style carousel that couldn't measure itself while hidden.
		 * @param $carousel
		 */
		function reinitializeCarousel ( $carousel ) {
			if ( $carousel.length && jQuery.fn.carousel ) {
				$carousel.carousel( 'resizeAction' );
			}
		}

		/**
		 * Reload a Google Map iframe that couldn't render correctly while hidden.
		 * @param $googleMaps
		 */
		function refreshGoogleMap ( $googleMaps ) {
			if ( $googleMaps.length && !$googleMaps.is( '.map_ready' ) ) {
				const $frame = $googleMaps.find( 'iframe' );
				$frame.attr( 'src', $frame.attr( 'src' ) );
				$googleMaps.addClass( 'map_ready' );
			}
		}

		/**
		 * Prepare html to correctly display inside tab container
		 *
		 * @param event - ui tab event 'show'
		 * @param ui - jquery ui tabs object
		 */
		window.wpb_prepare_tab_content = function ( event, ui ) {
			const panel = ui.panel || ui.newPanel;
			const $pieCharts = panel.find( '.vc_pie_chart:not(.vc_ready)' );
			const $roundCharts = panel.find( '.vc_round-chart' );
			const $lineCharts = panel.find( '.vc_line-chart' );
			const $carousel = panel.find( '[data-ride="vc_carousel"]' );

			if ( 'function' === typeof ( window.vc_plugin_flexslider ) ) {
				vc_plugin_flexslider( panel );
			}

			refreshMasonryGrids( ui.newPanel );
			refreshMasonryGrids( panel );
			reinitializeCharts( $pieCharts, $roundCharts, $lineCharts );
			reinitializeCarousel( $carousel );

			const $uiPanel = panel.find( '.isotope, .wpb_image_grid_ul' );
			if ( $uiPanel.length ) {
				$uiPanel.isotope( 'layout' );
			}

			refreshGoogleMap( panel.find( '.wpb_gmaps_widget' ) );

			panel.parents( '.isotope' ).each( function () {
				jQuery( this ).isotope( 'layout' );
			});

			jQuery( document ).trigger( 'wpb_prepare_tab_content', panel );
		};
	}
})();
