( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_fullHeightRow ) ) {
		/**
		 * @todo refactor as plugin.
		 * @returns {*}
		 */
		window.vc_fullHeightRow = function () {
			const $ = window.jQuery;
			const $element = $( '.vc_row-o-full-height:first' );
			if ( $element.length ) {
				const $window = $( window );
				const windowHeight = $window.height();
				const offsetTop = $element.offset().top;
				if ( offsetTop < windowHeight ) {
					const fullHeight = 100 - offsetTop / ( windowHeight / 100 );
					$element.css( 'min-height', `${fullHeight}vh` );
				}
			}
			$( document ).trigger( 'vc-full-height-row', $element );
		};
	}

	jQuery( () => {
		jQuery( window ).off( 'resize.vcFullHeightRow' ).on( 'resize.vcFullHeightRow', window.vc_fullHeightRow );
		window.vc_fullHeightRow();
	});
})();
