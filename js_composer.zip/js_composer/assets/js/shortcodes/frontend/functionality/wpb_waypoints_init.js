( function () {
	if ( 'function' !== typeof ( window.vc_waypoints ) ) {
		/**
		 * Waypoints magic
		 */
		window.vc_waypoints = function () {
			if ( 'undefined' !== typeof ( jQuery.fn.vcwaypoint ) ) {
				jQuery( '.wpb_animate_when_almost_visible:not(.wpb_start_animation)' ).each( function () {
					const $el = jQuery( this );
					$el.vcwaypoint( () => {
						$el.addClass( 'wpb_start_animation animated' );
					}, { offset: '85%' });
				});
			}
		};
	}

	jQuery( () => {
		window.setTimeout( window.vc_waypoints, 500 );
	});
})();
