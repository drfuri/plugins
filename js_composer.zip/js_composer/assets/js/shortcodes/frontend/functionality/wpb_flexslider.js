( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_plugin_flexslider ) ) {
		window.vc_plugin_flexslider = function ( $parent ) {
			const $slider = $parent ? $parent.find( '.wpb_flexslider' ) : jQuery( '.wpb_flexslider' );
			$slider.each( function () {
				const $thisElement = jQuery( this );
				const sliderSpeed = 800;
				const sliderTimeout = parseInt( $thisElement.attr( 'data-interval' ), 10 ) * 1000;
				const sliderFx = $thisElement.attr( 'data-flex_fx' );
				let slideshow = true;
				if ( 0 === sliderTimeout ) {
					slideshow = false;
				}

				if ( $thisElement.is( ':visible' ) ) {
					setTimeout( () => {
						$thisElement.flexslider({
							animation: sliderFx,
							slideshow,
							slideshowSpeed: sliderTimeout,
							sliderSpeed,
							smoothHeight: true
						});
					}, 1 );
				}
			});
		};
	}

	jQuery( () => window.vc_plugin_flexslider() );
})();
