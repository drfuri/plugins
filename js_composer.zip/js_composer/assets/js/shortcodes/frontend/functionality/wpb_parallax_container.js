( function () {
	'use strict';
	window.vcParallaxSkroll = false;

	if ( 'function' !== typeof ( window.vc_parallaxRow ) ) {
		/**
		 * @todo refactor as plugin.
		 * @returns {*}
		 */
		window.vc_parallaxRow = function () {
			const $ = window.jQuery;
			let vcSkrollrOptions;
			let callSkrollInit = false;
			if ( window.vcParallaxSkroll ) {
				window.vcParallaxSkroll.destroy();
			}
			$( '.vc_parallax-inner' ).remove();
			$( '[data-5p-top-bottom]' ).removeAttr( 'data-5p-top-bottom data-30p-top-bottom' );
			$( '[data-vc-parallax]' ).each( function () {
				callSkrollInit = true; // Enable skrollinit;
				if ( 'on' === $( this ).data( 'vcParallaxOFade' ) ) {
					$( this ).children().attr( 'data-5p-top-bottom', 'opacity:0;' ).attr( 'data-30p-top-bottom',
						'opacity:1;' );
				}

				const skrollrSize = $( this ).data( 'vcParallax' ) * 100;
				const $parallaxElement = $( '<div />' ).addClass( 'vc_parallax-inner' ).appendTo( $( this ) );
				$parallaxElement.height( `${skrollrSize}%` );

				const parallaxImage = $( this ).data( 'vcParallaxImage' );
				const youtubeId = vcExtractYoutubeId( parallaxImage );

				if ( youtubeId ) {
					insertYoutubeVideoAsBackground( $parallaxElement, youtubeId );
				} else if ( 'undefined' !== typeof ( parallaxImage ) ) {
					$parallaxElement.css( 'background-image', `url(${parallaxImage})` );
				}

				const skrollrSpeed = skrollrSize - 100;
				const skrollrStart = - skrollrSpeed;
				const skrollrEnd = 0;

				$parallaxElement.attr( 'data-bottom-top', `top: ${skrollrStart}%;` ).attr( 'data-top-bottom',
					`top: ${skrollrEnd}%;` );
			});

			if ( callSkrollInit && window.skrollr ) {
				vcSkrollrOptions = {
					forceHeight: false,
					smoothScrolling: false,
					mobileCheck () {
						return false;
					}
				};
				window.vcParallaxSkroll = skrollr.init( vcSkrollrOptions );
				return window.vcParallaxSkroll;
			}
			return false;
		};
	}

	jQuery( () => window.vc_parallaxRow() );
})();
