( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_initVideoBackgrounds ) ) {
		/**
		 * Reinitialize all video backgrounds
		 */
		window.vc_initVideoBackgrounds = function () {
			jQuery( '.vc_video-bg' ).remove();
			jQuery( '[data-vc-video-bg]' ).each( function () {
				const $element = jQuery( this );

				if ( $element.data( 'vcVideoBg' ) ) {
					const youtubeUrl = $element.data( 'vcVideoBg' );
					const youtubeId = vcExtractYoutubeId( youtubeUrl );

					if ( youtubeId ) {
						$element.find( '.vc_video-bg' ).remove();
						insertYoutubeVideoAsBackground( $element, youtubeId );
					}

					jQuery( window ).on( 'grid:items:added', ( event, $grid ) => {
						if ( !$element.has( $grid ).length ) {
							return;
						}

						vcResizeVideoBackground( $element );
					});
				} else {
					$element.find( '.vc_video-bg' ).remove();
				}
			});
		};
	}

	if ( 'function' !== typeof ( window.insertYoutubeVideoAsBackground ) ) {
		/**
		 * Insert youtube video into element.
		 *
		 * Video will be w/o controls, muted, autoplaying and looping.
		 */
		window.insertYoutubeVideoAsBackground = function ( $element, youtubeId, counter ) {
			if ( 'undefined' == typeof YT || 'undefined' === typeof ( YT.Player ) ) {
				// wait for youtube iframe api to load. try for 10sec, then abort
				counter = 'undefined' === typeof ( counter ) ? 0 : counter;
				if ( 100 < counter ) {
					console.warn( 'Too many attempts to load YouTube api' );
					return;
				}

				setTimeout( () => {
					insertYoutubeVideoAsBackground( $element, youtubeId, counter ++ );
				}, 100 );

				return;
			}

			const $container = $element.prepend( '<div class="vc_video-bg"><div class="inner"></div></div>' ).find( '.inner' );

			new YT.Player( $container[ 0 ], {
				width: '100%',
				height: '100%',
				videoId: youtubeId,
				playerVars: {
					// No playlist/loop — looped manually below to avoid YouTube's nav arrows.
					iv_load_policy: 3, // hide annotations
					enablejsapi: 1,
					disablekb: 1,
					autoplay: 1,
					controls: 0,
					showinfo: 0,
					rel: 0,
					mute: 1,
					wmode: 'transparent'
				},
				events: {
					onReady ( event ) {
						const player = event.target;
						const iframe = player.getIframe();
						player.mute();

						// Loop by restarting just before the end; self-clears when removed.
						const loop = setInterval( () => {
							if ( ! document.body.contains( iframe ) ) {
								clearInterval( loop );
								return;
							}

							const duration = player.getDuration();
							if ( 0 < duration && player.getCurrentTime() > duration - 0.5 ) {
								player.seekTo( 0 );
							}
						}, 250 );
					},
					// Restart on end as a loop fallback
					onStateChange ( event ) {
						if ( YT.PlayerState.ENDED === event.data ) {
							event.target.seekTo( 0 );
							event.target.playVideo();
						}
					}
				}
			});

			vcResizeVideoBackground( $element );

			jQuery( window ).on( 'resize', () => {
				vcResizeVideoBackground( $element );
			});
		};
	}

	if ( 'function' !== typeof ( window.vcResizeVideoBackground ) ) {
		/**
		 * Resize background video iframe so that video content covers whole area
		 */
		window.vcResizeVideoBackground = function ( $element ) {
			const containerW = $element.innerWidth();
			const containerH = $element.innerHeight();
			const ratio = 16 / 9;

			// 3x-wide iframe crops YouTube's corner chrome off-screen; video keeps its cover size.
			const coverHeight = Math.max( containerH, containerW / ratio );
			const videoWidth = coverHeight * ratio;
			const iframeH = Math.round( coverHeight );
			const iframeW = Math.round( videoWidth * 3 );

			$element.find( '.vc_video-bg iframe' ).css({
				maxWidth: '1000%',
				marginLeft: `${- Math.round( ( iframeW - containerW ) / 2 )}px`,
				marginTop: `${- Math.round( ( iframeH - containerH ) / 2 )}px`,
				width: `${iframeW}px`,
				height: `${iframeH}px`
			});
		};
	}

	if ( 'function' !== typeof ( window.vcExtractYoutubeId ) ) {
		/**
		 * Extract video ID from youtube url
		 */
		window.vcExtractYoutubeId = function ( url ) {
			if ( 'undefined' === typeof ( url ) ) {
				return false;
			}

			const id = url.match( /(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/ );

			if ( null !== id ) {
				return id[ 1 ];
			}

			return false;
		};
	}

	jQuery( () => window.vc_initVideoBackgrounds() );
})();
