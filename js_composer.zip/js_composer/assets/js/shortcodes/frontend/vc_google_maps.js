( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_googleMapsPointer ) ) {
		window.vc_googleMapsPointer = function () {
			const $ = window.jQuery;
			const $wpbGmapsWidget = $( '.wpb_gmaps_widget' );
			$wpbGmapsWidget.on( 'click', function () {
				$( 'iframe', this ).css( 'pointer-events', 'auto' );
			});

			$wpbGmapsWidget.on( 'mouseleave', function () {
				$( 'iframe', this ).css( 'pointer-events', 'none' );
			});

			$( '.wpb_gmaps_widget iframe' ).css( 'pointer-events', 'none' );
		};
	}

	jQuery( () => window.vc_googleMapsPointer() );
})();
