( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_progress_bar ) ) {
		/**
		 * Progress bar
		 */
		window.vc_progress_bar = function () {
			if ( 'undefined' !== typeof ( jQuery.fn.vcwaypoint ) ) {
				jQuery( '.vc_progress_bar' ).each( function () {
					const $el = jQuery( this );
					$el.vcwaypoint( () => {
						$el.find( '.vc_single_bar' ).each( function ( index ) {
							const $this = jQuery( this );
							const bar = $this.find( '.vc_bar' );
							const val = bar.data( 'percentage-value' );

							setTimeout( () => {
								bar.css({ 'width': `${val}%` });
							}, index * 200 );
						});
					}, { offset: '85%' });
				});
			}
		};
	}

	jQuery( () => window.vc_progress_bar() );
})();
