/**
 * Behavior for the [vc_googleplus] shortcode.
 *
 * @deprecated 8.0
 * @see include/templates/shortcodes/vc_googleplus.php
 */
( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_googleplus ) ) {
		/**
		 * Google plus
		 */
		window.vc_googleplus = function () {
			if ( 0 < jQuery( '.wpb_googleplus' ).length ) {
				( () => {
					const po = document.createElement( 'script' );
					po.type = 'text/javascript';
					po.async = true;
					po.src = 'https://apis.google.com/js/plusone.js';
					const s = document.getElementsByTagName( 'script' )[ 0 ];
					s.parentNode.insertBefore( po, s );
				})();
			}
		};
	}

	jQuery( () => window.vc_googleplus() );
})();
