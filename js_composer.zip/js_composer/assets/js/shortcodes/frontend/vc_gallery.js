( function () {
	'use strict';

	/**
	 * Init the Nivo slider layout of an image gallery.
	 * @param $el
	 */
	function initNivoSlider ( $el ) {
		if ( !jQuery.fn.nivoSlider || $el.data( 'nivo-initialized' ) ) {
			return;
		}
		$el.data( 'nivo-initialized', true );

		const sliderSpeed = 800;
		let sliderTimeout = $el.attr( 'data-interval' ) * 1000;
		if ( 0 === sliderTimeout ) {
			sliderTimeout = 9999999999;
		}

		$el.find( '.nivoSlider' ).nivoSlider({
			effect: 'boxRainGrow,boxRain,boxRainReverse,boxRainGrowReverse', // Specify sets like: 'fold,fade,sliceDown'
			slices: 15, // For slice animations
			boxCols: 8, // For box animations
			boxRows: 4, // For box animations
			animSpeed: sliderSpeed, // Slide transition speed
			pauseTime: sliderTimeout, // How long each slide will show
			startSlide: 0, // Set starting Slide (0 index)
			directionNav: true, // Next & Prev navigation
			directionNavHide: true, // Only show on hover
			controlNav: true, // 1,2,3... navigation
			keyboardNav: false, // Use left & right arrows
			pauseOnHover: true, // Stop animation while hovering
			manualAdvance: false, // Force manual transitions
			prevText: 'Prev', // Prev directionNav text
			nextText: 'Next' // Next directionNav text
		});
	}

	/**
	 * Init the Isotope image grid layout of an image gallery.
	 * @param $el
	 */
	function initImageGrid ( $el ) {
		const $imageGridUl = $el.find( '.wpb_image_grid_ul' );
		if ( !( $imageGridUl && $imageGridUl.isotope ) ) {
			return;
		}

		const isotopeOptions = {
			itemSelector: '.isotope-item',
			layoutMode: 'fitRows',
			percentPosition: true
		};

		if ( jQuery.fn.imagesLoaded ) {
			$imageGridUl.imagesLoaded( () => $imageGridUl.isotope( isotopeOptions ) );
		} else {
			$imageGridUl.isotope( isotopeOptions );
		}
	}

	if ( 'function' !== typeof ( window.vc_slidersBehaviour ) ) {
		window.vc_slidersBehaviour = function () {
			jQuery( '.wpb_gallery_slides' ).each( function () {
				const $this = jQuery( this );
				if ( $this.hasClass( 'wpb_slider_nivo' ) ) {
					initNivoSlider( $this );
				} else if ( $this.hasClass( 'wpb_image_grid' ) ) {
					initImageGrid( $this );
				}
			});
		};
	}

	jQuery( () => window.vc_slidersBehaviour() );
})();
