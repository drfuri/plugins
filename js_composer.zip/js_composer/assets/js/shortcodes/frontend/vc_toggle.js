( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_toggleBehaviour ) ) {
		/**
		 * Toggle/FAQ
		 * @param $el
		 */
		window.vc_toggleBehaviour = function ( $el ) {
			function event ( e ) {
				if ( e && e.preventDefault ) {
					e.preventDefault();
				}
				const title = jQuery( this );
				const element = title.closest( '.vc_toggle' );
				const content = element.find( '.vc_toggle_content' );
				if ( element.hasClass( 'vc_toggle_active' ) ) {
					content.slideUp({
						duration: 300,
						complete () {
							element.removeClass( 'vc_toggle_active' );
						}
					});
				} else {
					content.slideDown({
						duration: 300,
						complete () {
							element.addClass( 'vc_toggle_active' );
						}
					});
				}
			}

			if ( $el ) {
				if ( $el.hasClass( 'vc_toggle_title' ) ) {
					$el.unbind( 'click' ).on( 'click', event );
				} else {
					$el.find( '.vc_toggle_title' ).off( 'click' ).on( 'click', event );
				}
			} else {
				jQuery( '.vc_toggle_title' ).off( 'click' ).on( 'click', event );
			}
		};
	}

	jQuery( () => window.vc_toggleBehaviour() );
})();
