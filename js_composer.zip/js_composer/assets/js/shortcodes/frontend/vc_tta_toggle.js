( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_ttaToggleBehaviour ) ) {
		/**
		 * Toggle content element.
		 * @param $el
		 */
		window.vc_ttaToggleBehaviour = function ( $el ) {
			if ( $el ) {
				$el.find( '.wpb-tta-toggle' ).off( 'click' ).on( 'click', event );
			} else {
				jQuery( '.wpb-tta-toggle' ).off( 'click' ).on( 'click', event );
			}

			// if first pagination element already active than we should activate toggle true
			setTimeout( () => {
				jQuery( '.wpb-tta-toggle' ).each( function () {
					const toggle = jQuery( this );

					const wrapper = toggle.parent().parent().parent();

					const firstPaginationElement = wrapper.find( '.vc_tta-panels-container .vc_pagination li:first' );
					if ( !firstPaginationElement.hasClass( 'vc_active' ) ) {
						toggle.addClass( 'wpb-tta-toggle-active' );
					}
				});
			}, 1000 );

			// if clicking on toggle that click on pagination
			function event () {
				const toggle = jQuery( this );

				toggle.toggleClass( 'wpb-tta-toggle-active' );

				const wrapper = toggle.parent().parent().parent();

				const pagination = wrapper.find( '.vc_pagination-item' );

				pagination.each( function () {
					if ( ! jQuery( this ).hasClass( 'vc_active' ) ) {
						jQuery( this ).find( 'a' ).click();
						return false;
					}
				});
			}
		};
	}

	jQuery( () => window.vc_ttaToggleBehaviour() );
})();
