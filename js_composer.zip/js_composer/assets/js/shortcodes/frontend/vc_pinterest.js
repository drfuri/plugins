( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_pinterest ) ) {
		/**
		 * Pinterest
		 */
		window.vc_pinterest = function () {
			if ( 0 < jQuery( '.wpb_pinterest' ).length ) {
				( () => {
					const po = document.createElement( 'script' );
					po.type = 'text/javascript';
					po.async = true;
					po.src = 'https://assets.pinterest.com/js/pinit.js';
					const s = document.getElementsByTagName( 'script' )[ 0 ];
					s.parentNode.insertBefore( po, s );
				})();
			}
		};
	}

	jQuery( () => window.vc_pinterest() );
})();
