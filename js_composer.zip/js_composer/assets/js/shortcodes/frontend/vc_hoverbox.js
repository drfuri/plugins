( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_setHoverBoxPerspective ) ) {
		window.vc_setHoverBoxPerspective = function ( hoverBox ) {
			hoverBox.each( function () {
				const $this = jQuery( this );
				const width = $this.width();

				$this.css( 'perspective', `${width * 4}px` );
			});
		};
	}

	if ( 'function' !== typeof ( window.vc_setHoverBoxHeight ) ) {
		window.vc_setHoverBoxHeight = function ( hoverBox ) {
			hoverBox.each( function () {
				const $this = jQuery( this );
				const hoverBoxInner = $this.find( '.vc-hoverbox-inner' );

				hoverBoxInner.css( 'min-height', 0 );

				const frontHeight = $this.find( '.vc-hoverbox-front-inner' ).outerHeight();
				const backHeight = $this.find( '.vc-hoverbox-back-inner' ).outerHeight();
				const maxMin = 250;
				const hoverBoxHeight = Math.max( frontHeight, backHeight, maxMin );

				hoverBoxInner.css( 'min-height', `${hoverBoxHeight}px` );
			});
		};
	}

	if ( 'function' !== typeof ( window.vc_prepareHoverBox ) ) {
		window.vc_prepareHoverBox = function () {
			const hoverBox = jQuery( '.vc-hoverbox' );

			vc_setHoverBoxHeight( hoverBox );
			vc_setHoverBoxPerspective( hoverBox );
		};
	}

	jQuery( document ).ready( window.vc_prepareHoverBox );
	jQuery( window ).on( 'resize', window.vc_prepareHoverBox );
})();
