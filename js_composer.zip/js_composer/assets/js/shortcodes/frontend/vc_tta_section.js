( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_ttaActivation ) ) {
		window.vc_ttaActivation = function () {
			jQuery( '[data-vc-accordion]' ).on( 'show.vc.accordion', function ( e ) {
				const ui = { newPanel: jQuery( this ).data( 'vc.accordion' ).getTarget() };
				window.wpb_prepare_tab_content( e, ui );
			});
		};
	}

	jQuery( () => window.vc_ttaActivation() );
})();
