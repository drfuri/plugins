( function () {
	'use strict';
	if ( 'function' !== typeof ( window.vc_accordionBehaviour ) ) {
		/**
		 * Accordions old
		 *
		 * @deprecated
		 */
		window.vc_accordionBehaviour = function () {
			jQuery( '.wpb_accordion' ).each( function () {
				const $this = jQuery( this );

				// TODO: check if interval is used
				/* eslint-disable no-unused-vars */
				const interval = $this.attr( 'data-interval' );
				/* eslint-enable */
				const activeTab = !isNaN( jQuery( this ).data( 'active-tab' ) ) && 0 < parseInt( $this.data( 'active-tab' ), 10 ) ? parseInt( $this.data( 'active-tab' ), 10 ) - 1 : false;
				const collapsible = false === activeTab || 'yes' === $this.data( 'collapsible' );
				const $tabs = $this.find( '.wpb_accordion_wrapper' ).accordion({
					header: '> div > h3',
					autoHeight: false,
					heightStyle: 'content',
					active: activeTab,
					collapsible,
					navigation: true,

					activate ( event, ui ) {
						vc_accordionActivate( event, ui );
					},
					change ( event, ui ) {
						if ( 'undefined' !== typeof ( jQuery.fn.isotope ) ) {
							ui.newContent.find( '.isotope' ).isotope( 'layout' );
						}
					}
				});
				if ( true === $this.data( 'vcDisableKeydown' ) ) {
					$tabs.data( 'uiAccordion' )._keydown = function () {
					};
				}
			});
		};
	}

	if ( 'function' !== typeof ( window.vc_accordionActivate ) ) {
		/**
		 * Reinitialize any masonry grid nested inside an accordion panel.
		 * @param $scope
		 */
		function refreshMasonryGrids ( $scope ) {
			$scope.find( '.vc_masonry_media_grid, .vc_masonry_grid' ).each( function () {
				const grid = jQuery( this ).data( 'vcGrid' );
				if ( grid && grid.gridBuilder && grid.gridBuilder.setMasonry ) {
					grid.gridBuilder.setMasonry();
				}
			});
		}

		/**
		 * Reinitialize charts that couldn't render correctly while hidden.
		 * @param $pieCharts
		 * @param $roundCharts
		 * @param $lineCharts
		 */
		function reinitializeCharts ( $pieCharts, $roundCharts, $lineCharts ) {
			if ( $pieCharts.length && jQuery.fn.vcChat ) {
				$pieCharts.vcChat();
			}
			if ( $roundCharts.length && jQuery.fn.vcRoundChart ) {
				$roundCharts.vcRoundChart({ reload: false });
			}
			if ( $lineCharts.length && jQuery.fn.vcLineChart ) {
				$lineCharts.vcLineChart({ reload: false });
			}
		}

		/**
		 * Resize a Bootstrap-style carousel that couldn't measure itself while hidden.
		 * @param $carousel
		 */
		function reinitializeCarousel ( $carousel ) {
			if ( $carousel.length && jQuery.fn.carousel ) {
				$carousel.carousel( 'resizeAction' );
			}
		}

		window.vc_accordionActivate = function ( event, ui ) {
			if ( !( ui.newPanel.length && ui.newHeader.length ) ) {
				return;
			}
			const $pieCharts = ui.newPanel.find( '.vc_pie_chart:not(.vc_ready)' );
			const $roundCharts = ui.newPanel.find( '.vc_round-chart' );
			const $lineCharts = ui.newPanel.find( '.vc_line-chart' );
			const $carousel = ui.newPanel.find( '[data-ride="vc_carousel"]' );

			if ( 'undefined' !== typeof ( jQuery.fn.isotope ) ) {
				ui.newPanel.find( '.isotope, .wpb_image_grid_ul' ).isotope( 'layout' );
			}

			refreshMasonryGrids( ui.newPanel );

			if ( 'function' === typeof ( window.vc_plugin_flexslider ) ) {
				vc_plugin_flexslider( ui.newPanel );
			}

			reinitializeCharts( $pieCharts, $roundCharts, $lineCharts );
			reinitializeCarousel( $carousel );

			ui.newPanel.parents( '.isotope' ).each( function () {
				jQuery( this ).isotope( 'layout' );
			});
		};
	}

	jQuery( () => window.vc_accordionBehaviour() );
})();
