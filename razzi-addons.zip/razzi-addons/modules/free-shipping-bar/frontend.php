<?php

namespace Razzi\Addons\Modules\Free_Shipping_Bar;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Frontend {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Has variation images
	 *
	 * @var $has_variation_images
	 */
	protected static $has_variation_images = null;

	/**
	 * Cached template arguments for the bar
	 *
	 * @var $bar_args
	 */
	protected static $bar_args = null;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		if ( get_option( 'rz_free_shipping_bar_cart_page' ) == 'yes' ) {
			add_action('woocommerce_before_cart_table', array( $this, 'free_shipping_bar' ));
		}
		if ( get_option( 'rz_free_shipping_bar_checkout_page' ) == 'yes' ) {
			add_action('woocommerce_checkout_before_order_review', array( $this, 'free_shipping_bar' ));
		}
		if ( get_option( 'rz_free_shipping_bar_product_page' ) == 'yes' ) {
			add_action('woocommerce_before_add_to_cart_button', array( $this, 'free_shipping_bar' ), 9);
		}
		add_action('woocommerce_widget_shopping_cart_before_buttons', array( $this, 'free_shipping_bar' ), 100);
	}

		/**
	 * Enqueue scripts
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		wp_enqueue_style( 'razzi-free-shipping-bar', RAZZI_ADDONS_URL . 'modules/free-shipping-bar/assets/free-shipping-bar.css', array(), '1.0.0' );
	}

	/**
	 * Render the free shipping bar.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function free_shipping_bar() {
		$args = $this->get_free_shipping_bar_args();

		if ( empty( $args ) ) {
			return;
		}

		wc_get_template(
			'cart/free-shipping-bar.php',
			$args,
			'',
			RAZZI_ADDONS_DIR . 'modules/free-shipping-bar/templates/'
		);
	}

	/**
	 * Build the template arguments for the bar.
	 *
	 * WooCommerce itself decides whether free shipping is unlocked, so the bar
	 * can never disagree with the cart totals. Only the remaining amount and
	 * the progress percentage are calculated here, mirroring the math in
	 * WC_Shipping_Free_Shipping::is_available().
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function get_free_shipping_bar_args() {
		if ( isset( self::$bar_args ) ) {
			return self::$bar_args;
		}

		self::$bar_args = array();

		$package = $this->get_shipping_package();
		$method  = $this->get_free_shipping_method( $package );

		if ( ! $method ) {
			return self::$bar_args;
		}

		if ( $method->is_available( $package ) ) {
			self::$bar_args = array(
				'message' => __( 'Congratulations! You have got <strong>free shipping</strong>', 'razzi-addons' ),
				'percent' => '100%',
			);

			return self::$bar_args;
		}

		$min_amount = apply_filters( 'razzi_free_shipping_bar_min_amount', (float) $method->min_amount, $method );

		if ( $min_amount <= 0 ) {
			return self::$bar_args;
		}

		$current_total = $this->get_qualifying_total( $method );
		$amount_more   = $min_amount - $current_total;

		// Free shipping is unavailable for a reason the bar cannot show, such
		// as a required coupon that has not been applied yet.
		if ( $amount_more <= 0 ) {
			return self::$bar_args;
		}

		$percent = max( 0, min( 100, $current_total / $min_amount * 100 ) );

		self::$bar_args = array(
			'message' => sprintf( __( 'You are missing %s to get <strong>free shipping!</strong>', 'razzi-addons' ), '<strong>' . wc_price( $amount_more ) . '</strong>' ),
			'percent' => number_format( $percent, 2, '.', '' ) . '%',
		);

		return self::$bar_args;
	}

	/**
	 * Get the shipping package the bar reports on.
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function get_shipping_package() {
		$packages = ! empty( WC()->cart ) ? WC()->cart->get_shipping_packages() : array();

		return ! empty( $packages ) ? reset( $packages ) : array();
	}

	/**
	 * Get the free shipping method the bar reports on.
	 *
	 * Methods come from the shipping zone matching the customer, so the bar
	 * follows the same zone and instance settings as the cart. When a zone has
	 * several free shipping instances, the one available now wins, otherwise
	 * the cheapest threshold is used as the goal to work towards.
	 *
	 * @since 1.0.0
	 *
	 * @param array $package Shipping package.
	 *
	 * @return \WC_Shipping_Free_Shipping|false
	 */
	public function get_free_shipping_method( $package = null ) {
		$package = is_null( $package ) ? $this->get_shipping_package() : $package;

		if ( empty( $package ) || ! WC()->shipping() ) {
			return false;
		}

		$shipping_methods = WC()->shipping()->load_shipping_methods( $package );

		if ( ! $shipping_methods ) {
			return false;
		}

		$found = false;

		foreach ( $shipping_methods as $shipping_method ) {
			if ( ! $shipping_method instanceof \WC_Shipping_Free_Shipping ) {
				continue;
			}

			// Skip the class registered globally by WooCommerce: it carries the
			// default settings instead of the ones saved on a shipping zone.
			if ( empty( $shipping_method->instance_id ) ) {
				continue;
			}

			if ( ! isset( $shipping_method->enabled ) || 'yes' !== $shipping_method->enabled ) {
				continue;
			}

			// Shipping is free no matter what, so there is no goal to show.
			if ( empty( $shipping_method->requires ) ) {
				return false;
			}

			if ( $shipping_method->is_available( $package ) ) {
				return $shipping_method;
			}

			if ( ! in_array( $shipping_method->requires, array( 'min_amount', 'either', 'both' ), true ) ) {
				continue;
			}

			if ( ! $found || $shipping_method->min_amount < $found->min_amount ) {
				$found = $shipping_method;
			}
		}

		return $found;
	}

	/**
	 * Get the cart total that counts towards the free shipping threshold.
	 *
	 * Mirrors WC_Shipping_Free_Shipping::is_available(): the displayed subtotal
	 * (excluding tax unless the store shows prices inclusive of tax) minus the
	 * discounts, unless the method is set to ignore them.
	 *
	 * @since 1.0.0
	 *
	 * @param \WC_Shipping_Free_Shipping $method Free shipping method.
	 *
	 * @return float
	 */
	public function get_qualifying_total( $method ) {
		$cart  = WC()->cart;
		$total = $cart->get_displayed_subtotal();

		if ( 'no' === $method->ignore_discounts ) {
			$total = $total - $cart->get_discount_total();

			if ( $cart->display_prices_including_tax() ) {
				$total = $total - $cart->get_discount_tax();
			}
		}

		return round( $total, wc_get_price_decimals() );
	}

	/**
	 * Get the free shipping threshold of the current shipping zone.
	 *
	 * @since 1.0.0
	 *
	 * @return float
	 */
	public function get_min_amount() {
		$method = $this->get_free_shipping_method();

		return $method ? (float) $method->min_amount : 0;
	}

}
