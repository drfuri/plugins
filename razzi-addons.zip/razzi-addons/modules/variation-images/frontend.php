<?php

namespace Razzi\Addons\Modules\Variation_Images;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Frontend {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Has variation images
	 *
	 * @var $has_variation_images
	 */
	protected static $has_variation_images = null;

	/**
	 * Default variation the initial render describes, resolved once per request
	 *
	 * @var \WC_Product|false|null
	 */
	protected static $initial_variation = null;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_filter( 'post_class', array( $this, 'product_class' ), 10, 3 );

		add_filter('razzi_single_product_image_id', array( $this, 'get_variation_image' ));
		add_filter('razzi_single_product_gallery_image_ids', array( $this, 'get_variation_gallery_image_ids' ));
		add_action( 'wc_ajax_razzi_get_variation_images', array( $this, 'get_variation_images' ) );
	}

	public function has_variation_images() {
		if( isset( self::$has_variation_images ) ) {
			return self::$has_variation_images;
		}
		global $product;
		if( empty( $product ) ) {
			return self::$has_variation_images;
		}
		self::$has_variation_images = false;
		if( $product->get_type() != 'variable' ) {
			return self::$has_variation_images;
		}
		$variation_ids        = $product->get_children();
		if( empty($variation_ids) ) {
			return self::$has_variation_images;
		}
		foreach( $variation_ids as $variation_id ) {
			$variation_images = get_post_meta( $variation_id, 'razzi_variation_images', true );
			if( $variation_images ) {
				self::$has_variation_images = true;
				return self::$has_variation_images;
			}
		}

	}

	/**
	 * Adds classes to products
     *
	 * @since 1.0.0
	 *
	 * @param string $class Post class.
	 *
	 * @return array
	 */
	public function product_class( $classes ) {
		if ( is_admin() || get_post_type(get_the_ID()) != 'product') {
			return $classes;
		}
		if( $this->has_variation_images() ) {
			$classes[] = 'product-has-variation-images';
		}

		return $classes;
	}

	/**
	 * Enqueue Scripts
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'razzi_variation_images', RAZZI_ADDONS_URL . 'modules/variation-images/js/variation-images-frontend.js', array( 'jquery', 'razzi-helpers' ), '20260827', true );

		$variation = $this->get_initial_variation();

		wp_localize_script( 'razzi_variation_images', 'razziVariationImages', array(
			// The variation this page already rendered the gallery for. The script seeds its state
			// with it so the `found_variation` the form fires on load stops re-requesting markup
			// the server has just produced.
			'variation_id_rendered' => $variation ? $variation->get_id() : 0,
		) );
	}

	public function get_variation_images() {
		if ( isset( $_POST['product_id'] ) && ! empty( $_POST['product_id'] ) ) {
			$product_id       = absint( $_POST['product_id'] );
			$GLOBALS['post'] = get_post( $product_id  ); // WPCS: override ok.
			setup_postdata( $GLOBALS['post'] );
			ob_start();
			woocommerce_show_product_images();
			wp_reset_postdata();
			wp_send_json_success( ob_get_clean() );
			die();
		}

	}

	public function get_variation_image($image_id) {
		$variation = $this->get_filter_variation();

		return $variation ? $variation->get_image_id() : $image_id;
	}

	public function get_variation_gallery_image_ids($image_ids) {
		$variation = $this->get_filter_variation();

		if ( ! $variation ) {
			return $image_ids;
		}

		$variation_images = get_post_meta( $variation->get_id(), 'razzi_variation_images', true );

		return $variation_images ? explode( ',', $variation_images ) : $image_ids;
	}

	/**
	 * The variation the gallery filters should describe.
	 *
	 * During the AJAX swap that is whichever variation the visitor picked. On the initial render
	 * it is the default variation, so the gallery WooCommerce prints already matches the selection
	 * the variation form is about to make.
	 *
	 * @since 1.0.0
	 *
	 * @return \WC_Product|false
	 */
	protected function get_filter_variation() {
		if ( isset( $_POST['variation_id'] ) && ! empty( $_POST['variation_id'] ) ) {
			$variation = wc_get_product( absint( $_POST['variation_id'] ) );

			return $variation ? $variation : false;
		}

		return $this->get_initial_variation();
	}

	/**
	 * The default variation this request renders the gallery for, if there is one.
	 *
	 * Rendering it server side lets the browser pick the LCP image straight from `srcset` instead
	 * of waiting on a request that returns the same markup. Both filters resolve the variation the
	 * same way the AJAX branch does, so the two produce identical output - which is what lets the
	 * script skip the request altogether.
	 *
	 * @since 1.0.0
	 *
	 * @return \WC_Product|false
	 */
	protected function get_initial_variation() {
		if ( isset( self::$initial_variation ) ) {
			return self::$initial_variation;
		}

		self::$initial_variation = false;

		// A reset carries a `variation_id` of 0 and the quick view renders its own markup, and both
		// want the parent gallery, so the default variation must not stand in for them.
		if ( wp_doing_ajax() || ! is_product() ) {
			return self::$initial_variation;
		}

		$variation_id = $this->get_variation_id_default( $this->get_current_product() );

		if ( $variation_id ) {
			$variation = wc_get_product( $variation_id );

			self::$initial_variation = $variation ? $variation : false;
		}

		return self::$initial_variation;
	}

	/**
	 * Resolve the variation the product's default attributes select.
	 *
	 * @since 1.0.0
	 *
	 * @param \WC_Product|false $product Product to read the defaults from.
	 *
	 * @return int Variation ID, or 0 when the defaults do not select exactly one.
	 */
	public function get_variation_id_default( $product = null ) {
		$product = $product ? $product : $this->get_current_product();

		if ( empty( $product ) || 'variable' !== $product->get_type() ) {
			return 0;
		}

		$default_attributes = $product->get_default_attributes();

		if ( empty( $default_attributes ) ) {
			return 0;
		}

		$match_attributes = array();

		foreach ( $default_attributes as $key => $value ) {
			// A partly filled default selection leaves the visitor to finish choosing, so no single
			// variation is on screen to render.
			if ( '' === $value ) {
				return 0;
			}

			$match_attributes[ 'attribute_' . sanitize_title( $key ) ] = $value;
		}

		return (int) \WC_Data_Store::load( 'product' )->find_matching_product_variation( $product, $match_attributes );
	}

	/**
	 * The product being viewed.
	 *
	 * The global is not set yet while scripts are enqueued, so fall back to the queried object.
	 *
	 * @since 1.0.0
	 *
	 * @return \WC_Product|false
	 */
	protected function get_current_product() {
		global $product;

		if ( $product instanceof \WC_Product ) {
			return $product;
		}

		$product_id = get_queried_object_id();

		return $product_id ? wc_get_product( $product_id ) : false;
	}

}