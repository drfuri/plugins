<?php
/**
 * Razzi Addons Modules functions and definitions.
 *
 * @package Razzi
 */

namespace Razzi\Addons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Modules {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Razzi\Addons\Auto_Loader::register( [
			'Razzi\Addons\Modules\Size_Guide'             		=> RAZZI_ADDONS_DIR . 'modules/size-guide/class-razzi-size-guide.php',
			'Razzi\Addons\Modules\Size_Guide\Settings'    		=> RAZZI_ADDONS_DIR . 'modules/size-guide/class-razzi-size-guide-settings.php',
			'Razzi\Addons\Modules\Catalog_Mode'           		=> RAZZI_ADDONS_DIR . 'modules/catalog-mode/class-razzi-catalog-mode.php',
			'Razzi\Addons\Modules\Catalog_Mode\Settings'  		=> RAZZI_ADDONS_DIR . 'modules/catalog-mode/class-razzi-catalog-mode-settings.php',
			'Razzi\Addons\Modules\Product_Deals'          		=> RAZZI_ADDONS_DIR . 'modules/product-deals/class-razzi-product-deals.php',
			'Razzi\Addons\Modules\Product_Deals\Settings' 		=> RAZZI_ADDONS_DIR . 'modules/product-deals/class-razzi-product-deals-settings.php',
			'Razzi\Addons\Modules\Buy_Now'                		=> RAZZI_ADDONS_DIR . 'modules/buy-now/class-razzi-buy-now.php',
			'Razzi\Addons\Modules\Buy_Now\Settings'       		=> RAZZI_ADDONS_DIR . 'modules/buy-now/class-razzi-buy-now-settings.php',
			'Razzi\Addons\Modules\Mega_Menu'              		=> RAZZI_ADDONS_DIR . 'modules/mega-menu/class-razzi-mega-menu.php',
			'Razzi\Addons\Modules\Mega_Menu\Settings'     		=> RAZZI_ADDONS_DIR . 'modules/mega-menu/class-razzi-mega-menu-settings.php',
			'Razzi\Addons\Modules\Products_Filter\Settings'     => RAZZI_ADDONS_DIR . 'modules/products-filter/class-razzi-products-filter-settings.php',
		] );
	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		$this->get( 'size_guide', 'frontend' );
		$this->get( 'size_guide', 'settings' );

		$this->get( 'catalog_mode', 'frontend' );
		$this->get( 'catalog_mode', 'settings' );

		$this->get( 'product_deals', 'frontend' );
		$this->get( 'product_deals', 'settings' );

		$this->get( 'buy_now', 'frontend' );
		$this->get( 'buy_now', 'settings' );

		$this->get( 'mega_menu', 'frontend' );
		$this->get( 'mega_menu', 'settings' );

		$this->get( 'product_filter' );
	}

	/**
	 * Get Modules Class instance
	 *
	 * @since 1.0.0
	 *
	 * @return object
	 */
	public function get( $class, $type = '' ) {
		switch ( $class ) {
			case 'size_guide':
				if ( $type == 'settings' ) {
					if ( is_admin() ) {
						return \Razzi\Addons\Modules\Size_Guide\Settings::instance();
					}
				} elseif ( get_option( 'razzi_size_guide' ) == 'yes' ) {
					return \Razzi\Addons\Modules\Size_Guide::instance();
				}

				break;

			case 'catalog_mode':
				if ( $type == 'settings' ) {
					if ( is_admin() ) {
						return \Razzi\Addons\Modules\Catalog_Mode\Settings::instance();
					}
				} elseif ( get_option( 'rz_catalog_mode' ) == 'yes' ) {
					return \Razzi\Addons\Modules\Catalog_Mode::instance();
				}

				break;

			case 'product_deals':
				if ( $type == 'settings' ) {
					if ( is_admin() ) {
						return \Razzi\Addons\Modules\Product_Deals\Settings::instance();
					}
				} elseif ( get_option( 'rz_product_deals' ) == 'yes' ) {
					return \Razzi\Addons\Modules\Product_Deals::instance();
				}

				break;

			case 'buy_now':
				if ( $type == 'settings' ) {
					if ( is_admin() ) {
						return \Razzi\Addons\Modules\Buy_Now\Settings::instance();
					}
				} elseif ( get_option( 'rz_buy_now' ) == 'yes' ) {
					return \Razzi\Addons\Modules\Buy_Now::instance();
				}

				break;

			case 'mega_menu':
				if ( $type == 'settings' ) {
					if ( is_admin() ) {
						return \Razzi\Addons\Modules\Mega_Menu\Settings::instance();
					}
				} elseif ( get_option( 'rz_mega_menu' ) != '1' ) {
					return \Razzi\Addons\Modules\Mega_Menu::instance();
				}

				break;

			case 'product_filter':
				return \Razzi\Addons\Modules\Products_Filter\Settings::instance();

				break;
		}
	}
}
