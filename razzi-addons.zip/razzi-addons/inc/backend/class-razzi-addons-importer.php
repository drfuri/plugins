<?php
/**
 * Hooks for importer
 *
 * @package Razzi
 */

namespace Razzi\Addons;


/**
 * Class Importter
 */
class Importer {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'soo_demo_packages', array( $this, 'importer' ), 20 );
	}

	/**
	 * Importer the demo content
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	function importer() {
		return array(
			array(
				'name'       => 'Home Minimal',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 1',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Classic',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-classic/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-classic/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 2',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Fashion',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-fashion/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-fashion/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 3',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Fashion v2',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-fashion-v2/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 10',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Boxes',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-boxes/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-boxes/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 4',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Simple',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-simple/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-simple/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-simple/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-simple/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 5',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Asymmetric',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-asymmetric/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-asymmetric/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 6',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Masonry',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-masonry/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-masonry/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-masonry/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-masonry/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 7',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Landing',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-landing/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-landing/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-landing/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-landing/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 8',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Furniture',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 1',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Furniture v2',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v2/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v2/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v2/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v2/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 12',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Furniture v3',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v3/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v3/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v3/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v3/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 2',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Furniture v4',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v4/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v4/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v4/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-v4/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 3',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Furniture Boxes',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-boxes/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-boxes/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-boxes/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-furniture-boxes/widgets.wie',
				'pages'      => array(
					'front_page' => 'Shop',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Cases',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-cases/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-cases/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-cases/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-cases/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home 11',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
			array(
				'name'       => 'Home Instagram',
				'preview'    => 'http://demo2.drfuri.com/soo-importer/razzi/home-instagram/preview.png',
				'content'    => 'http://demo2.drfuri.com/soo-importer/razzi/demo-content.xml',
				'customizer' => 'http://demo2.drfuri.com/soo-importer/razzi/home-instagram/customizer.dat',
				'widgets'    => 'http://demo2.drfuri.com/soo-importer/razzi/widgets.wie',
				'pages'      => array(
					'front_page' => 'Home Instagram',
					'blog'       => 'Blog',
					'shop'       => 'Shop',
					'cart'       => 'Cart',
					'checkout'   => 'Checkout',
					'my_account' => 'My Account',
				),
				'menus'      => array(
					'primary' 		=> 'primary-menu',
					'secondary' 	=> 'secondary-menu',
					'hamburger' 	=> 'primary-menu',
					'socials' 		=> 'social-menu',
					'department' 	=> 'department-menu',
					'mobile' 		=> 'primary-menu',
				),
				'options'    => array(
					'shop_catalog_image_size'   => array(
						'width'  => 370,
						'height' => 370,
						'crop'   => 1,
					),
					'shop_single_image_size'    => array(
						'width'  => 670,
						'height' => 670,
						'crop'   => 1,
					),
					'shop_thumbnail_image_size' => array(
						'width'  => 70,
						'height' => 70,
						'crop'   => 1,
					),
				),
			),
		);
	}
}
