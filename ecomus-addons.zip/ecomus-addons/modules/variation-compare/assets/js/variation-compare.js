(function ($) {
	'use strict';

	var ecomus = ecomus || {};

	ecomus.init = function () {
        this.foundVariation();
    }

    ecomus.foundVariation = function() {
        var $selector = $( '#product-variation-compare-modal' );
        if ( !$selector.length ) {
            return;
        }
        $selector.find( 'form.cart' ).on('change', 'select', function (e) {
            var optionSelected = $("option:selected", this),
                attributes = optionSelected.data('attributes'),
                self = $(this);

            if( attributes !== undefined ) {
                self.closest('form.cart').find('.single_add_to_cart_button').removeClass('disabled');
                for( var key in attributes) {
                    self.closest('form.cart').find('input[name="'+ key +'"]').val( attributes[key] );
                }
            } else {
                self.closest('form.cart').find('.single_add_to_cart_button').addClass('disabled');
            }

        });
    }
	/**
	 * Document ready
	 */
	$(function () {
		ecomus.init();
	});

})(jQuery);