jQuery(document).ready(function ($) {
	// Switch status
	$('.dynamic-pricing-discount__switch').on( 'change', 'input', function () {
		var $switch = $(this).closest('.dynamic-pricing-discount__switch'),
			$text	= $(this).siblings( '.text' ),
			status  = $switch.hasClass( 'enabled' ) ? 'yes' : 'no';

		if( $switch.hasClass( 'enable' ) ) {
			$switch.removeClass( 'enable' ).addClass( 'disable' );
            $text.text( $text.data( 'disable' ) );
			status = 'no';
		} else {
			$switch.removeClass( 'disable' ).addClass( 'enable' );
            $text.text( $text.data( 'enable' ) );
			status = 'yes';
		}

		if( $switch.hasClass( 'dynamic-pricing-discount__switch--column' ) ) {
			var post_id = $switch.data( 'post_id' );

			if ( $switch.data( 'requestRunning' ) ) {
				return;
			}

			$switch.data( 'requestRunning', true );

			$.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
					action: 'ecomus_dynamic_pricing_discount_status_update',
					post_id: post_id,
					status: status
				},
				success: function( response ) {
					$switch.data( 'requestRunning', false );
				}
			});
		}
	});

	// Change field product tab type
	var $settings = $('#ecomus-dynamic-pricing-discounts-display'),
		$display = $settings.find('select[name="_dynamic_pricing_discounts_display"]'),
		$product = $settings.find('.ecomus-dynamic-pricing-discounts--product'),
		$categories = $settings.find('.ecomus-dynamic-pricing-discounts--categories');

	$display.on( 'change', function() {
		var display = $(this).val();

		if( display == 'products' ) {
			$product.removeClass( 'hidden' );
			$categories.addClass( 'hidden' );

		} else if( display == 'categories' ) {
			$product.addClass( 'hidden' );
			$categories.removeClass( 'hidden' );
		}
	});

	$(document.body).on( 'click', '.ecomus-dynamic-pricing-discount__addnew', function ( e ) {
		e.preventDefault();

		var $clone = $(this).closest( '.ecomus-dynamic-pricing-discounts' ).find( '.ecomus-dynamic-pricing-discount__group' ).first().clone(),
			$last  = $(this).closest( '.ecomus-dynamic-pricing-discounts' ).find( '.group-items' ).last(),
			number = $last.find( '#dynamic_pricing_discounts_to' ).val();

		$clone.find( 'input' ).val( '' );

		if( number && number !== 0 ) {
			$clone.find( '#dynamic_pricing_discounts_from' ).val( parseInt( number ) + 1 );
		}

		$clone.addClass( 'ecomus-dynamic-pricing-discount__group--clone' );
		$clone.find( '.ecomus-dynamic-pricing-discount__remove' ).removeClass( 'hidden' );
		$(this).closest( '.ecomus-dynamic-pricing-discounts' ).find( '.ecomus-dynamic-pricing-discount__button' ).before( $clone );
	});

	$(document.body).on( 'click', '.ecomus-dynamic-pricing-discount__remove', function ( e ) {
        e.preventDefault();
        $(this).closest( '.ecomus-dynamic-pricing-discount__group--clone' ).remove();
    });

	$(document.body).on( 'change', '#dynamic_pricing_discounts_from', function () {
		var $item = $(this).closest( '.group-items' ),
			$value = $(this).val(),
			$prevFrom = $item.prev().find( '#dynamic_pricing_discounts_from' ),
			prevFromVal = $item.prev().find( '#dynamic_pricing_discounts_from' ).val(),
			$prevTo = $item.prev().find( '#dynamic_pricing_discounts_to' ),
			prevToVal = $item.prev().find( '#dynamic_pricing_discounts_to' ).val();

		if( prevFromVal > ( parseInt( $value ) - 2 ) ) {
			$prevFrom.val( parseInt( $value ) - 2 );
		}

		if( prevToVal > ( parseInt( $value ) - 1 ) ) {
			$prevTo.val( parseInt( $value ) - 1 );
		}
	});

	$(document.body).on( 'change', '#dynamic_pricing_discounts_to', function () {
		var $item = $(this).closest( '.group-items' ),
			$value = $(this).val(),
			$nextFrom = $item.next().find( '#dynamic_pricing_discounts_from' ),
			nextFromVal = $item.next().find( '#dynamic_pricing_discounts_from' ).val(),
			$nextTo = $item.next().find( '#dynamic_pricing_discounts_to' ),
			nextToVal = $item.next().find( '#dynamic_pricing_discounts_to' ).val();

		$nextFrom.attr( 'min', parseInt( $value ) + 1 );
		if( nextFromVal < ( parseInt( $value ) + 1 ) ) {
			$nextFrom.val( parseInt( $value ) + 1 );
		}

		$nextTo.attr( 'min', parseInt( $value ) + 2 );

		if( nextToVal < ( parseInt( $value ) + 2 ) ) {
			$nextTo.val( parseInt( $value ) + 2 );
		}
	});
});