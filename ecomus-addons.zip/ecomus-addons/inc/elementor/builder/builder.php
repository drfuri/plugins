<?php
/**
 * Ecomus Addons Modules functions and definitions.
 *
 * @package Ecomus
 */

namespace Ecomus\Addons\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Builder {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	private static $is_elementor;
	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		add_action('init', array( $this, 'actions'));
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Ecomus\Addons\Auto_Loader::register( [
			'Ecomus\Addons\Elementor\Builder\Settings'           => ECOMUS_ADDONS_DIR . 'inc/elementor/builder/inc/settings.php',
			'Ecomus\Addons\Elementor\Builder\Post_Type'          => ECOMUS_ADDONS_DIR . 'inc/elementor/builder/inc/post-type.php',
			'Ecomus\Addons\Elementor\Builder\Helper'             => ECOMUS_ADDONS_DIR . 'inc/elementor/builder/inc/helper.php',
			'Ecomus\Addons\Elementor\Builder\Elementor_Settings' => ECOMUS_ADDONS_DIR . 'inc/elementor/builder/inc/elementor-settings.php',
			'Ecomus\Addons\Elementor\Builder\Footer'             => ECOMUS_ADDONS_DIR . 'inc/elementor/builder/inc/footer.php',
		] );

	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if( is_admin() ) {
			\Ecomus\Addons\Elementor\Builder\Settings::instance();
		}

		if( $this->is_elementor() ) {
			\Ecomus\Addons\Elementor\Builder\Post_Type::instance();
			\Ecomus\Addons\Elementor\Builder\Footer::instance();

			if( class_exists('Elementor\Core\Base\Module') ) {
				\Ecomus\Addons\Elementor\Builder\Elementor_Settings::instance();
			}
		}
	}

	public function is_elementor() {
		if ( isset( self::$is_elementor ) ) {
			return self::$is_elementor;
		}

		self::$is_elementor = true;
		if( ! class_exists('\Elementor\Plugin') ) {
			self::$is_elementor = false;
		}

		return self::$is_elementor;
	}
}
