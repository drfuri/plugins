<?php
/**
 * Ecomus Addons Elementor Builder Helper init
 *
 *
 * @package Ecomus
 */

namespace Ecomus\Addons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Helper
 */
class Helper {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	public static function is_preview_mode(){
		if( self::is_elementor_editor_mode() || get_post_type() === 'ecomus_builder' ) {
			return true;
		} else {
			return false;
		}
	}

	public static function is_elementor_editor_mode(){
		if( class_exists('\Elementor\Plugin') && \Elementor\Plugin::instance()->editor->is_edit_mode() ){
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Get template elementor settings
	 *
	 * @return void
	 */
	public static function get_template_settings( $template_id ) {
		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );
		$page_settings_model = $page_settings_manager->get_model( $template_id );

		return $page_settings_model->get_settings();
	}
}
