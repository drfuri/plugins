<?php
namespace Ecomus\Addons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase as PageBase;

class Elementor_Settings extends Module {
	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'ecomus-elementor-settings';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/documents/register_controls', [ $this, 'register_display_controls' ] );

		add_action( 'elementor/document/after_save', array( $this, 'save_post_meta' ), 10, 2 );
	}


	/**
	 * Register display controls.
	 *
	 * @param object $document
	 */
	public function register_display_controls( $document ) {
		if ( ! $document instanceof PageBase ) {
			return;
		}

		$post_type = get_post_type( $document->get_main_id() );

		if ( 'ecomus_builder' != $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), 'ecomus_builder_type' );
        $terms = ! is_wp_error( $terms ) &&  $terms ? wp_list_pluck($terms, 'slug') : '';

        if( ! $terms || ! in_array( 'footer', $terms ) ) {
            return;
        }

		$this->register_builder_footer_content($document);
	}

	/**
	 * Register template footer controls of display.
	 *
	 * @param object $document
	 */
	protected function register_builder_footer_content( $document ) {
		$document->start_controls_section(
			'section_footer_settings',
			[
				'label' => __( 'Footer Settings', 'ecomus-addons' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$document->add_control(
			'include_page_ids',
			[
				'label' => __( 'Include Pages', 'ecomus-addons' ),
				'type' => 'ecomus-autocomplete',
				'placeholder' => esc_html__( 'Click here and start typing...', 'ecomus-addons' ),
				'default' => '',
				'multiple'    => true,
				'source'      => 'page',
				'sortable'    => true,
				'label_block' => true,
			]
		);

		$document->add_control(
			'exclude_page_ids',
			[
				'label' => __( 'Exclude Pages', 'ecomus-addons' ),
				'type' => 'ecomus-autocomplete',
				'placeholder' => esc_html__( 'Click here and start typing...', 'ecomus-addons' ),
				'default' => '',
				'multiple'    => true,
				'source'      => 'page',
				'sortable'    => true,
				'label_block' => true,
			]
		);

		$document->end_controls_section();

	}

	/**
	 * Save post meta when save page settings in Elementor
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function save_post_meta( $document, $data ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( 'ecomus_builder' != $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), 'ecomus_builder_type' );
        $terms = ! is_wp_error( $terms ) &&  $terms ? wp_list_pluck($terms, 'slug') : '';

        if( ! $terms || ! in_array( 'footer', $terms ) ) {
            return;
        }

		if ( ! isset( $data['settings'] ) ) {
			return;
		}

		$settings = $data['settings'];

		// Footer
		$include_ids = ! empty( $settings['include_page_ids'] ) ? $settings['include_page_ids'] . ',' : 0;
		$exclude_ids = ! empty( $settings['exclude_page_ids'] ) ? $settings['exclude_page_ids'] . ',' : 0;

		update_post_meta( $document->get_main_id(), 'page_include', $include_ids );
		update_post_meta( $document->get_main_id(), 'page_exclude', $exclude_ids );
	}
}