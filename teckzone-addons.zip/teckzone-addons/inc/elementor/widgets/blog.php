<?php

namespace TeckzoneAddons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Controls_Stack;
use TeckzoneAddons\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Blog widget
 */
class Blog extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'teckzone-blog-shortcode';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Teckzone - Blog', 'teckzone' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'teckzone' ];
	}

	public function get_script_depends() {
		return [
			'techzone-elementor'
		];
	}
	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->section_content();
		$this->section_style();
	}

	/**
	 * Section Content
	 */
	protected function section_content() {
		$this->blog_settings_controls();
	}

	protected function blog_settings_controls() {

		// Blogs Settings
		$this->start_controls_section(
			'section_blogs',
			[ 'label' => esc_html__( 'Posts', 'teckzone' ) ]
		);

		$this->add_control(
			'source',
			[
				'label'       => esc_html__( 'Source', 'teckzone' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'default' => esc_html__( 'Default', 'teckzone' ),
					'custom'  => esc_html__( 'Custom', 'teckzone' ),
				],
				'default'     => 'default',
				'label_block' => true,
			]
		);
		$this->add_control(
			'ids',
			[
				'label'       => esc_html__( 'Posts', 'teckzone' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'teckzone' ),
				'type'        => 'tzautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'post',
				'sortable'    => true,
				'condition'   => [
					'source' => 'custom',
				],
			]
		);

		$this->add_control(
			'blog_cats',
			[
				'label'       => esc_html__( 'Categories', 'teckzone' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => Elementor::get_taxonomy('category'),
				'default'     => '',
				'multiple'    => true,
				'label_block' => true,
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'limit',
			[
				'label'     => esc_html__( 'Total post', 'teckzone' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 8,
				'min'       => 2,
				'max'       => 50,
				'step'      => 1,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'teckzone' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''           => esc_html__( 'Default', 'teckzone' ),
					'date'       => esc_html__( 'Date', 'teckzone' ),
					'name'       => esc_html__( 'Name', 'teckzone' ),
					'id'         => esc_html__( 'Ids', 'teckzone' ),
					'rand'       => esc_html__( 'Random', 'teckzone' ),
				],
				'default'    => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'source',
							'value' => 'default',
						]
					]
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'teckzone' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'teckzone' ),
					'asc'  => esc_html__( 'Ascending', 'teckzone' ),
					'desc' => esc_html__( 'Descending', 'teckzone' ),
				],
				'default'    => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'source',
							'value' => 'default',
						]
					]
				],
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'     => esc_html__( 'Excerpt Length', 'teckzone' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 15,
				'min'       => 2,
				'max'       => 100,
				'separator'  => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				// Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default'   => 'full',
				'separator' => 'none',
			]
		);

		$this->end_controls_section();
	}
	/**
	 * Section Style
	 */
	protected function section_style() {
		$this->section_blog_style();
	}

	protected function section_blog_style() {
		// Heading Style
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'teckzone' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'date_author',
			[
				'label'                => esc_html__( 'Date & Author', 'teckzone' ),
				'type'                 => Controls_Manager::SWITCHER,
				'label_on'             => esc_html__( 'Yes', 'teckzone' ),
				'label_off'            => esc_html__( 'No', 'teckzone' ),
				'return_value'         => 'yes',
				'desktop_default'      => 'yes',
				'tablet_default'       => 'yes',
				'mobile_default'       => 'yes',
				'selectors_dictionary' => [
					''    => 'display: none',
					'yes' => 'display: block',
				],
				'device_args'          => [
					Controls_Stack::RESPONSIVE_DESKTOP => [
						'selectors' => [
							'{{WRAPPER}} .teckzone-blog-shortcode .blog-wrapper .entry-meta' => '{{VALUE}}',
						],
					],
					Controls_Stack::RESPONSIVE_TABLET  => [
						'selectors' => [
							'{{WRAPPER}} .teckzone-blog-shortcode .blog-wrapper .entry-meta' => '{{VALUE}}',
						],
					],
					Controls_Stack::RESPONSIVE_MOBILE  => [
						'selectors' => [
							'{{WRAPPER}} .teckzone-blog-shortcode .blog-wrapper .entry-meta' => '{{VALUE}}',
						],
					],
				]
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'teckzone' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .teckzone-blog-shortcode .list-post--wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'teckzone' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .teckzone-blog-shortcode .list-post--wrapper' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'content_border',
				'label'    => esc_html__( 'Border', 'teckzone' ),
				'selector' => '{{WRAPPER}} .teckzone-blog-shortcode .list-post--wrapper',
				'fields_options'  => [
					'border' => [
						'default' => 'solid',
					],
				],
			]
		);

		$this->add_control(
			'item_divider',
			[
				'label' => esc_html__( 'Divider', 'teckzone' ),
				'type'  => Controls_Manager::HEADING,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'item_divider_background_color',
			[
				'label'     => __( 'Color', 'teckzone' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-items .blog-wrapper' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_heading' );
		$this->start_controls_tab(
			'tab_first_item',
			[
				'label' => esc_html__( 'First Item', 'teckzone' ),
			]
		);

		$this->add_control(
			'first_item_heading',
			[
				'label' => esc_html__( 'Title', 'teckzone' ),
				'type'  => Controls_Manager::HEADING,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'first_item_title_color',
			[
				'label'     => esc_html__( 'Color', 'teckzone' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-first-item .entry-title a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'first_item_title_typography',
				'selector' => '{{WRAPPER}} .teckzone-blog-shortcode .blog-first-item .entry-title',
			]
		);

		$this->add_control(
			'first_item_description',
			[
				'label' => esc_html__( 'Description', 'teckzone' ),
				'type'  => Controls_Manager::HEADING,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'first_item_description_color',
			[
				'label'     => esc_html__( 'Color', 'teckzone' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-first-item .entry-excerpt' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'first_item_description_typography',
				'selector' => '{{WRAPPER}} .teckzone-blog-shortcode .blog-first-item .entry-excerpt',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_items',
			[
				'label' => esc_html__( 'Items', 'teckzone' ),
			]
		);

		$this->add_control(
			'items_heading',
			[
				'label' => esc_html__( 'Title', 'teckzone' ),
				'type'  => Controls_Manager::HEADING,
				'separator'   => 'before',
			]
		);

		$this->add_responsive_control(
			'items_padding',
			[
				'label'      => esc_html__( 'Padding', 'teckzone' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-items .blog-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'items_margin',
			[
				'label'      => esc_html__( 'Margin', 'teckzone' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-items .blog-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'items_title_color',
			[
				'label'     => esc_html__( 'Color', 'teckzone' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .teckzone-blog-shortcode .blog-items .entry-title a' => 'color: {{VALUE}}',
				],
				'separator'   => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'items_title_typography',
				'selector' => '{{WRAPPER}} .teckzone-blog-shortcode .blog-items .entry-title',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this -> end_controls_section();
	}

	protected function _register_responsive_settings_controls() {
		$this->add_control(
			'responsive_settings_divider',
			[
				'label' => __( 'Additional Settings', 'teckzone' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
	
		$repeater = new \Elementor\Repeater();
	
		$repeater->add_control(
			'responsive_breakpoint', [
				'label' => __( 'Breakpoint', 'teckzone' ) . ' (px)',
				'description' => __( 'Below this breakpoint the options below will be triggered', 'teckzone' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 1200,
				'min'             => 320,
				'max'             => 1920,
			]
		);
		$repeater->add_control(
			'responsive_slidesToShow',
			[
				'label'           => esc_html__( 'Slides to show', 'teckzone' ),
				'type'            => Controls_Manager::NUMBER,
				'min'             => 1,
				'max'             => 7,
				'default' => 1,
			]
		);
		$repeater->add_control(
			'responsive_slidesToScroll',
			[
				'label'           => esc_html__( 'Slides to scroll', 'teckzone' ),
				'type'            => Controls_Manager::NUMBER,
				'min'             => 1,
				'max'             => 7,
				'default' => 1,
			]
		);
		$repeater->add_control(
			'responsive_navigation',
			[
				'label'           => esc_html__( 'Navigation', 'teckzone' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => [
					'both'   => esc_html__( 'Arrows and Dots', 'teckzone' ),
					'arrows' => esc_html__( 'Arrows', 'teckzone' ),
					'dots'   => esc_html__( 'Dots', 'teckzone' ),
					'none'   => esc_html__( 'None', 'teckzone' ),
				],
				'default' => 'dots',
				'toggle'          => false,
			]
		);
	
		$this->add_control(
			'carousel_responsive_settings',
			[
				'label' => __( 'Settings', 'teckzone' ),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'default' => [
					
				],
				'title_field' => '{{{ responsive_breakpoint }}}' . 'px',
				'prevent_empty' => false,
			]
		);
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper', 'class', [
				'teckzone-blog-shortcode',
			]
		);

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div class="list-post--wrapper">
				<div class="list-post">
					<?php 
						if ($settings['source'] == 'default'){
							$query_args = array(
								'post_status' => 'publish',
								'orderby' => $settings['orderby'],
								'order' => $settings['order'],
								'ignore_sticky_posts' => true,
								'posts_per_page' => $settings['limit'],
							);
				
							if ( ! empty( $settings['blog_cats'] ) ) {
								$query_args['tax_query'] = array(
									'relation' => 'OR',
									array(
										'taxonomy' => 'category',
										'field'    => 'slug',
										'terms'    => $settings['blog_cats'],
										'operator' => 'IN',
									),
								);
							}
						} else {
							$query_args['post__in'] =  explode(",",$settings['ids']) ;
						}
						$query = new \WP_Query($query_args);
						while ($query->have_posts()) : $query->the_post();

						$current = $query->current_post + 1;

						$classes = 'blog-wrapper';
						$thumbnail_id = absint( get_post_thumbnail_id() );
						$image['url'] = wp_get_attachment_image_src( $thumbnail_id );
						$image['id']  = $thumbnail_id;

						$settings['image'] = $image;

						$excerpt_length = $settings['excerpt_length'];
					?>
						<?php
						if( $current == 1) {
							echo '<div class="blog-first-item">';
								$this->tz_blog_first_content($classes, $excerpt_length, $settings);
							echo '</div>';
						} else {
							if( $current == 2) {
								echo '<div class="blog-items">';
							}
								$this->tz_blog_items_content($classes);
							if( $current == $settings['limit']) {
								echo '</div>';
							}
						}
							
						?>
					<?php endwhile; ?>
				</div>
			</div>
		</div>
		<?php

	}

	/**
	 * Render icon box widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 */
	protected
	function _content_template() {
	}

	protected function tz_blog_first_content($classes, $excerpt_length, $settings) {
		?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
				<div class="blog-inner">
					<div class="entry-format format-image">
						<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings ); ?>
					</div>
					<div class="entry-summary">
						<div class="entry-content">
							<?php teckzone_blog_meta(); ?>
							<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
							<div class="entry-excerpt"><?php echo teckzone_content_limit( $excerpt_length, '' ); ?></div>
						</div>
					</div>
				</div>
			</article><!-- #post-<?php the_ID(); ?> -->
		<?php
	}

	protected function tz_blog_items_content($classes) {
		?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
				<div class="blog-inner">
					<div class="entry-summary">
						<div class="entry-content">
							<div class="entry-meta">
								<div class="meta-wrapper">
									<?php echo teckzone_meta_date(); ?>
								</div>
							</div>
							<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
						</div>
					</div>
				</div>
			</article><!-- #post-<?php the_ID(); ?> -->
		<?php
	}

	protected function get_link_control( $link_key, $url, $content, $attr = [] ) {
		$attr_default = [
			'href' => $url['url'] ? $url['url'] : '#',
		];

		if ( $url['is_external'] ) {
			$attr_default['target'] = '_blank';
		}

		if ( $url['nofollow'] ) {
			$attr_default['rel'] = 'nofollow';
		}

		$attr = wp_parse_args( $attr, $attr_default );

		$this->add_render_attribute( $link_key, $attr );

		return sprintf( '<a %1$s>%2$s</a>', $this->get_render_attribute_string( $link_key ), $content );
	}
}