<?php
/**
 * Custom functions for Visual Composer
 *
 * @package    Unero
 * @subpackage Visual Composer
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/**
 * Class fos_VC
 *
 * @since 1.0.0
 */
class Unero_VC {

	/**
	 * Construction
	 */
	function __construct() {
		// Stop if VC is not installed
		if ( ! is_plugin_active( 'js_composer/js_composer.php' ) ) {
			return false;
		}

		add_action( 'init', array( $this, 'map_shortcodes' ), 20 );
	}


	/**
	 * Add new params or add new shortcode to VC
	 *
	 * @since 1.0
	 *
	 * @return void
	 */
	function map_shortcodes() {

		// get form id of mailchimp
		$forms    = get_posts( 'post_type=mc4wp-form&number=-1' );
		$form_ids = array(
			esc_html( 'Select a form', 'unero' ) => '0',
		);
		foreach ( $forms as $form ) {
			$form_ids[ $form->post_title ] = $form->ID;
		}

		// Add instagram shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Instagram Photos', 'unero' ),
				'base'     => 'unero_instagram',
				'class'    => '',
				'category' => esc_html__( 'Content', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Access Token', 'unero' ),
						'param_name' => 'access_token',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Numbers', 'unero' ),
						'param_name'  => 'numbers',
						'value'       => 6,
						'description' => esc_html__( 'Enter number of photos you want to show.', 'unero' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Image Size', 'unero' ),
						'param_name' => 'image_size',
						'value'      => array(
							esc_html__( 'Medium', 'unero' ) => 'low_resolution',
							esc_html__( 'Small', 'unero' )  => 'thumbnail',
							esc_html__( 'Large', 'unero' )  => 'standard_resolution',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'unero' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '5 Columns', 'unero' ) => '5',
							esc_html__( '3 Columns', 'unero' ) => '3',
							esc_html__( '4 Columns', 'unero' ) => '4',
							esc_html__( '6 Columns', 'unero' ) => '6',
							esc_html__( '8 Columns', 'unero' ) => '8',
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Hashtag', 'unero' ),
						'param_name' => 'hashtag',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'unero' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'unero' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'No Space', 'unero' ),
						'param_name'  => 'no_space',
						'value'       => '',
						'description' => esc_html__( 'Check this option to remove space between slides.', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)

		);

		// Section title
		vc_map(
			array(
				'name'     => esc_html__( 'Section Title', 'unero' ),
				'base'     => 'unero_section_title',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Description', 'unero' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Unero Sliders
		vc_map(
			array(
				'name'            => esc_html__( 'Banner Slider', 'unero' ),
				'base'            => 'unero_sliders',
				'category'        => esc_html__( 'Unero', 'unero' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'unero' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'unero' ) => '1',
							esc_html__( 'Style 2', 'unero' ) => '2',
							esc_html__( 'Style 3', 'unero' ) => '3',
							esc_html__( 'Style 4', 'unero' ) => '4',
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Full Width', 'unero' ),
						'param_name' => 'full_width',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Min Height(px)', 'unero' ),
						'param_name' => 'min_height',
						'value'      => 550,
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Effect', 'unero' ),
						'param_name' => 'effect',
						'value'      => array(
							esc_html__( 'Fade', 'unero' )  => 'fade',
							esc_html__( 'Slide', 'unero' ) => 'slide',
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Parallax', 'unero' ),
						'param_name' => 'parallax',
						'value'      => '',
						'dependency' => array(
							'element' => 'effect',
							'value'   => array( 'fade' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Auto Play', 'unero' ),
						'param_name'  => 'auto_play',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'unero' ),
					),
					array(
						'heading'    => esc_html__( 'Sliders', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'sliders',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'unero' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'unero' ),
							),
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'MP4 Video URL', 'unero' ),
								'param_name'  => 'video_url',
								'description' => esc_html__( 'Paste your MP4 video URL', 'unero' ),
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Title', 'unero' ),
								'param_name' => 'title',
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Title Color', 'unero' ),
								'param_name' => 'title_color',
							),
							array(
								'type'       => 'dropdown',
								'heading'    => esc_html__( 'Text Align', 'unero' ),
								'param_name' => 'text_align',
								'value'      => array(
									esc_html__( 'Left', 'unero' )   => 'left',
									esc_html__( 'Center', 'unero' ) => 'center',
									esc_html__( 'Right', 'unero' )  => 'right',
								),
							),
							array(
								'type'       => 'vc_link',
								'heading'    => esc_html__( 'Link', 'unero' ),
								'param_name' => 'link',
								'value'      => '',
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Link Color', 'unero' ),
								'param_name' => 'link_color',
							),
							array(
								'type'       => 'checkbox',
								'heading'    => esc_html__( 'Link for slider', 'unero' ),
								'param_name' => 'link_type',
								'value'      => array( esc_html__( 'Yes', 'unero' ) => 'true' ),
							),

						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Banner
		vc_map(
			array(
				'name'     => esc_html__( 'Banner', 'unero' ),
				'base'     => 'unero_banner',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'unero' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'unero' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'SubTitle', 'unero' ),
						'param_name' => 'subtitle',
						'value'      => '',
					),
					array(
						'type'       => 'colorpicker',
						'heading'    => esc_html__( 'SubTitle Color', 'unero' ),
						'param_name' => 'subtitle_color',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'SubTitle Align', 'unero' ),
						'param_name' => 'subtitle_align',
						'value'      => array(
							esc_html__( 'Left', 'unero' )  => 'left',
							esc_html__( 'Right', 'unero' ) => 'right',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'SubTitle Position', 'unero' ),
						'param_name' => 'subtitle_position',
						'value'      => array(
							esc_html__( 'Top', 'unero' )    => 'top',
							esc_html__( 'Center', 'unero' ) => 'center',
							esc_html__( 'Bottom', 'unero' ) => 'bottom',
						),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'URL(Link)', 'unero' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)

		);

		// Banners Grid
		vc_map(
			array(
				'name'            => esc_html__( 'Banners Grid', 'unero' ),
				'base'            => 'unero_banners_grid',
				'category'        => esc_html__( 'Unero', 'unero' ),
				'content_element' => true,
				'params'          => array(
					array(
						'heading'    => esc_html__( 'Banners', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'banners',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'unero' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'unero' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'unero' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Title Color', 'unero' ),
								'param_name' => 'title_color',
							),
							array(
								'type'       => 'vc_link',
								'heading'    => esc_html__( 'Link', 'unero' ),
								'param_name' => 'link',
								'value'      => '',
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Link Color', 'unero' ),
								'param_name' => 'link_color',
							),
							array(
								'type'       => 'checkbox',
								'heading'    => esc_html__( 'Link for image', 'unero' ),
								'param_name' => 'link_image',
								'value'      => '',
							),

						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Banners Carousel
		vc_map(
			array(
				'name'            => esc_html__( 'Banners Carousel', 'unero' ),
				'base'            => 'unero_banners_carousel',
				'category'        => esc_html__( 'Unero', 'unero' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Auto Play', 'unero' ),
						'param_name'  => 'auto_play',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'unero' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Number of columns', 'unero' ),
						'param_name' => 'number',
						'value'      => array(
							esc_html__( '3 Columns', 'unero' ) => '3',
							esc_html__( '4 Columns', 'unero' ) => '4',
							esc_html__( '5 Columns', 'unero' ) => '5',
							esc_html__( '6 Columns', 'unero' ) => '6',
						),
					),
					array(
						'heading'    => esc_html__( 'Banners', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'banners',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'unero' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'unero' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'unero' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'heading'    => esc_html__( 'Link', 'unero' ),
								'param_name' => 'link',
								'value'      => '',
							),
							array(
								'type'       => 'checkbox',
								'heading'    => esc_html__( 'Link for slider', 'unero' ),
								'param_name' => 'link_type',
								'value'      => array( esc_html__( 'Yes', 'unero' ) => 'true' ),
							),

						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Banners Carousel
		vc_map(
			array(
				'name'            => esc_html__( 'Hero Slider', 'unero' ),
				'base'            => 'unero_hero_slider',
				'category'        => esc_html__( 'Unero', 'unero' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Full Width', 'unero' ),
						'param_name' => 'full_width',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Layout', 'unero' ),
						'param_name' => 'layout',
						'value'      => array(
							esc_html__( 'Tabs', 'unero' ) => 'tabs',
							esc_html__( 'Grid', 'unero' ) => 'grid',
						),
					),
					array(
						'heading'    => esc_html__( 'Sliders', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'sliders',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'unero' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'unero' ),
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'Title', 'unero' ),
								'param_name' => 'title',
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Description', 'unero' ),
								'param_name' => 'desc',
							),
							array(
								'type'       => 'vc_link',
								'heading'    => esc_html__( 'Link', 'unero' ),
								'param_name' => 'link',
								'value'      => '',
							),

						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Newsletter
		vc_map(
			array(
				'name'     => esc_html__( 'Newsletter', 'unero' ),
				'base'     => 'unero_newsletter',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'unero' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'unero' ) => '1',
							esc_html__( 'Style 2', 'unero' ) => '2',
						),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Description', 'unero' ),
						'param_name' => 'desc',
						'value'      => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Mailchimp Form', 'unero' ),
						'param_name' => 'form',
						'value'      => $form_ids,
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Links
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Link', 'unero' ),
				'base'     => 'unero_link',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Text', 'unero' ),
						'param_name'  => 'content',
						'admin_label' => true,
						'value'       => esc_html__( 'Text on the link', 'unero' ),
					),
					array(
						'type'        => 'vc_link',
						'heading'     => esc_html__( 'URL (link)', 'unero' ),
						'param_name'  => 'link',
						'value'       => '',
						'description' => esc_html__( 'Add URL link', 'unero' ),
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Add products carousel shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Products Carousel', 'unero' ),
				'base'     => 'unero_products_carousel',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'unero' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'unero' ) => '1',
							esc_html__( 'Style 2', 'unero' ) => '2',
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Products', 'unero' ),
						'param_name' => 'products',
						'value'      => array(
							esc_html__( 'Recent', 'unero' )       => 'recent',
							esc_html__( 'Featured', 'unero' )     => 'featured',
							esc_html__( 'Best Selling', 'unero' ) => 'best_selling',
							esc_html__( 'Top Rated', 'unero' )    => 'top_rated',
							esc_html__( 'On Sale', 'unero' )      => 'sale',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Product Categories', 'unero' ),
						'param_name'  => 'categories',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
							'values'   => $this->get_categories( 'product_cat' ),
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter product categories', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Products per view', 'unero' ),
						'param_name'  => 'per_page',
						'value'       => '12',
						'description' => esc_html__( 'Set numbers of products you want to display at the same time.', 'unero' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Number of columns', 'unero' ),
						'param_name' => 'number',
						'value'      => array(
							esc_html__( '4 Columns', 'unero' ) => '4',
							esc_html__( '3 Columns', 'unero' ) => '3',
							esc_html__( '5 Columns', 'unero' ) => '5',
							esc_html__( '6 Columns', 'unero' ) => '6',
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'unero' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Date', 'unero' )       => 'date',
							esc_html__( 'Title', 'unero' )      => 'title',
							esc_html__( 'Menu Order', 'unero' ) => 'menu_order',
							esc_html__( 'Random', 'unero' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order products. Leave empty to use the default order by of theme.', 'unero' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'unero' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                   => '',
							esc_html__( 'Ascending ', 'unero' )  => 'asc',
							esc_html__( 'Descending ', 'unero' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort products. Leave empty to use the default sort of theme', 'unero' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'View More Link', 'unero' ),
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'unero' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Add post
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Posts', 'unero' ),
				'base'     => 'unero_posts',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Categories', 'unero' ),
						'param_name'  => 'categories',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
							'values'   => $this->get_categories(),
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter categories', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Posts per view', 'unero' ),
						'param_name'  => 'per_page',
						'value'       => 3,
						'description' => esc_html__( 'Set numbers of posts you want to display at the same time.', 'unero' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Excerpt Length', 'unero' ),
						'param_name' => 'excerpt_length',
						'value'      => 15,
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'unero' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Date', 'unero' )       => 'date',
							esc_html__( 'Title', 'unero' )      => 'title',
							esc_html__( 'Menu Order', 'unero' ) => 'menu_order',
							esc_html__( 'Random', 'unero' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order products. Leave empty to use the default order by of theme.', 'unero' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'unero' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                   => '',
							esc_html__( 'Ascending ', 'unero' )  => 'asc',
							esc_html__( 'Descending ', 'unero' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort products. Leave empty to use the default sort of theme', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Newsletter
		vc_map(
			array(
				'name'     => esc_html__( 'About', 'unero' ),
				'base'     => 'unero_about',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Description', 'unero' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'unero' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Unero FAQs
		vc_map(
			array(
				'name'            => esc_html__( 'Unero FAQs', 'unero' ),
				'base'            => 'unero_faqs',
				'category'        => esc_html__( 'Unero', 'unero' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'unero' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'heading'    => esc_html__( 'FAQs', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'faqs',
						'params'     => array(
							array(
								'type'       => 'textfield',
								'heading'    => esc_html__( 'Title', 'unero' ),
								'param_name' => 'title',
								'value'      => '',
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Content', 'unero' ),
								'param_name' => 'desc',
							),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Call to Action
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Call To Action', 'unero' ),
				'base'     => 'unero_cta',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Text', 'unero' ),
						'param_name' => 'content',
					),
					array(
						'type'        => 'vc_link',
						'heading'     => esc_html__( 'URL (link)', 'unero' ),
						'param_name'  => 'link',
						'value'       => '',
						'description' => esc_html__( 'Add URL link', 'unero' ),
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Add icon box shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Icon Box', 'unero' ),
				'base'     => 'unero_icon_box',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'iconpicker',
						'heading'    => esc_html__( 'Icon', 'unero' ),
						'param_name' => 'icon',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'unero' ),
						'description' => esc_html__( 'Enter the title here!', 'unero' ),
						'param_name'  => 'title',
						'value'       => '',
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Content', 'unero' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'unero' ),
					),
				),
			)
		);

		// get form id of mailchimp
		$contact_forms    = get_posts( 'post_type=wpcf7_contact_form&number=-1' );
		$contact_form_ids = array( esc_html__( 'Choose a from', 'unero' ) => 0 );
		foreach ( $contact_forms as $form ) {
			$contact_form_ids[ $form->post_title ] = $form->ID;
		}

		// Add Contact Form 7 shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Contact Form 7', 'unero' ),
				'base'     => 'unero_contact_form',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Contact Form', 'unero' ),
						'param_name' => 'form',
						'value'      => $contact_form_ids,
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Add contact shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Google Maps', 'unero' ),
				'base'     => 'unero_gmap',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Api Key', 'unero' ),
						'param_name'  => 'api_key',
						'value'       => '',
						'description' => sprintf( __( 'Please go to <a href="%s">Google Maps APIs</a> to get a key', 'unero' ), esc_url( 'https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key' ) ),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Marker', 'unero' ),
						'param_name'  => 'marker',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'unero' ),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Address', 'unero' ),
						'param_name' => 'address',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Width(px)', 'unero' ),
						'param_name'  => 'width',
						'value'       => '',
						'description' => esc_html__( 'Enter number of the width', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height(px)', 'unero' ),
						'param_name'  => 'height',
						'value'       => '450',
						'description' => esc_html__( 'Enter number of the height', 'unero' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Zoom', 'unero' ),
						'param_name' => 'zoom',
						'value'      => '13',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Content', 'unero' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		// Add custom single image
		vc_map(
			array(
				'name'     => esc_html__( 'Unero Single Image', 'unero' ),
				'base'     => 'unero_single_image',
				'class'    => '',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'unero' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'unero' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'unero' ),
					),
				),
			)
		);

		vc_map(
			array(
				'name'     => esc_html__( 'Video Banner', 'unero' ),
				'base'     => 'unero_video',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video file URL', 'unero' ),
						'description' => esc_html__( 'Only allow mp4, webm, ogv files', 'unero' ),
						'param_name'  => 'video',
						'value'       => '',
					),
					array(
						'type'       => 'attach_image',
						'heading'    => esc_html__( 'Poster Image', 'unero' ),
						'param_name' => 'image',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height', 'unero' ),
						'param_name'  => 'height',
						'value'       => '',
						'description' => esc_html__( 'Specify height of video banner. Enter height in pixels (Example: 160px)', 'unero' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Mute', 'unero' ),
						'param_name'  => 'mute',
						'value'       => array( esc_html__( 'Yes', 'unero' ) => 'true' ),
						'description' => esc_html__( 'Mute this video by default', 'unero' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video Subtitle', 'unero' ),
						'description' => esc_html__( 'Enter the subtitle of video', 'unero' ),
						'param_name'  => 'subtitle',
						'value'       => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video title', 'unero' ),
						'description' => esc_html__( 'Enter the title of video', 'unero' ),
						'param_name'  => 'title',
						'value'       => '',
					),

					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Description', 'unero' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the description', 'unero' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Button', 'unero' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'unero' ),
					),
				),
			)
		);

		vc_map(
			array(
				'name'     => esc_html__( 'Box Content', 'unero' ),
				'base'     => 'unero_box_content',
				'category' => esc_html__( 'Unero', 'unero' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'unero' ),
						'description' => esc_html__( 'Enter the subtitle', 'unero' ),
						'param_name'  => 'subtitle',
						'value'       => '',
					),
					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Title', 'unero' ),
						'description' => esc_html__( 'Enter the title', 'unero' ),
						'param_name'  => 'content',
						'value'       => '',
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Button', 'unero' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'unero' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'unero' ),
					),
				),
			)
		);


	}

	/**
	 * Get categories
	 *
	 * @return array|string
	 */
	function get_categories( $taxonomy = 'category' ) {
		$output     = array();
		$categories = get_terms( $taxonomy, 'hide_empty=0' );
		if ( ! is_wp_error( $categories ) && $categories ) {
			foreach ( $categories as $category ) {
				if ( $category ) {
					$output[] = array(
						'value' => $category->slug,
						'label' => $category->name,
					);
				}
			}
		}

		return $output;
	}

}