<?php
/**
 * Hooks for importer
 *
 * @package Supro
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function supro_vc_addons_importer() {
	return array(
		array(
			'name'       => 'Home Default',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-default/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-default/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-default/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-default/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-default/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Default',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Minimal',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-minimal/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-minimal/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-minimal/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-minimal/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-minimal/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Minimal',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Best Selling',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-best-selling/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-best-selling/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-best-selling/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-best-selling/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Best Selling',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Modern',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-modern/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-modern/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-modern/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-modern/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-modern/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Modern',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Carousel',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-carousel/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-carousel/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-carousel/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-carousel/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Carousel',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Left Sidebar',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-left-sidebar/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-left-sidebar/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-left-sidebar/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-left-sidebar/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-left-sidebar/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Left Sidebar',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Classic',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-classic/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-classic/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-classic/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-classic/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-classic/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Classic',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Full Slider',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-slider/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-slider/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-slider/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-slider/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-slider/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Full Slider',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Full Width',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-width/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-width/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-width/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-width/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-full-width/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Full Slider',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Categories',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-categories/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-categories/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-categories/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-categories/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Categories',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Instagram',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-instagram/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-instagram/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-instagram/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-instagram/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Instagram',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Metro',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-metro/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-metro/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-metro/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-metro/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Metro',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Masonry',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-masonry/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-masonry/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-masonry/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-masonry/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Masonry',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Parallax',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-parallax/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-parallax/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-parallax/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-parallax/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-parallax/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Parallax',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Shoppable Image',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-shoppable-image/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-shoppable-image/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-shoppable-image/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-shoppable-image/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Shoppable Image',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Boxed',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-boxed/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-boxed/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-boxed/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-boxed/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-boxed/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Boxed',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Simple',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-simple/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-simple/demo-content.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-simple/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-simple/widgets.wie',
			'sliders'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/supro/home-simple/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Simple',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 400,
					'height' => 400,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
	);
}

add_filter( 'soo_demo_packages', 'supro_vc_addons_importer', 20 );
