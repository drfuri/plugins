<?php
/**
 * Plugin Name: Naix Addons
 * Plugin URI: http://drfuri.com/naix
 * Description: Extra elements for Visual Composer. It was built for Naix theme.
 * Version: 1.0.9
 * Author: DrFuri
 * Author URI: http://drfuri.com/
 * License: GPL2+
 * Text Domain: naix-addons
 * Domain Path: lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'NAIX_ADDONS_DIR' ) ) {
	define( 'NAIX_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'NAIX_ADDONS_URL' ) ) {
	define( 'NAIX_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once NAIX_ADDONS_DIR . '/inc/visual-composer.php';
require_once NAIX_ADDONS_DIR . '/inc/shortcodes.php';
require_once NAIX_ADDONS_DIR . '/inc/socials.php';
require_once NAIX_ADDONS_DIR . '/inc/widgets/widgets.php';

if ( is_admin() ) {
	require_once NAIX_ADDONS_DIR . '/inc/importer.php';
}

/**
 * Init
 */
function naix_vc_addons_init() {
	new Naix_VC;
	new Naix_Shortcodes;

}

add_action( 'after_setup_theme', 'naix_vc_addons_init', 20 );
