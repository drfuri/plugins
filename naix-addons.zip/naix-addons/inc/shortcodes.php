<?php

/**
 * Define theme shortcodes
 *
 * @package Naix
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

class Naix_Shortcodes {
	/**
	 * Store variables for js
	 *
	 * @var array
	 */
	public $l10n = array();

	public $maps = array();

	public $api_key = '';

	/**
	 * Check if Portfolio plugin is actived or not
	 *
	 * @var bool
	 */
	private $portfolio_actived = false;

	/**
	 * Construction
	 *
	 * @return Mrbara_Shortcodes
	 */
	function __construct() {
		if ( is_plugin_active( 'drf-portfolio/drf-portfolio.php' ) ) {
			$this->portfolio_actived = true;
		}

		$shortcodes = array(
			'section_text_effect',
			'section_title',
			'portfolios_list',
			'portfolios_list_filter',
			'portfolios_grid',
			'featured_portfolio',
			'portfolios_free',
			'portfolios_grid_gap',
			'portfolios_masonry',
			'clients_text',
			'services_text',
			'awards_text',
			'banner',
			'images_grid',
			'testimonial',
			'member',
			'posts_grid',
			'vsslider1',
			'vsslider2',
			'vsslider3',
			'hsslider1',
			'image_box',
			'empty_space',
			'gmap',
			'contact_form',
			'socials',
			'image_gallery',
			'countdown',
			'about',

		);

		foreach ( $shortcodes as $shortcode ) {
			add_shortcode( 'naix_' . $shortcode, array( $this, $shortcode ) );
		}

		add_action( 'wp_footer', array( $this, 'footer' ) );
	}


	/**
	 * Load custom js in footer
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function footer() {

		// Load Google maps only when needed
		if ( isset( $this->l10n['map'] ) ) {
			echo '<script>if ( typeof google !== "object" || typeof google.maps !== "object" )
				document.write(\'<script src="//maps.google.com/maps/api/js?sensor=false&key=' . $this->api_key . '"><\/script>\')</script>';
		}

		wp_enqueue_script( 'naix-shortcodes', NAIX_ADDONS_URL . '/assets/js/frontend.js', array( 'jquery' ), '20170530', true );

		$this->l10n['days']    = esc_html__( 'days', 'naix-addons' );
		$this->l10n['hours']   = esc_html__( 'hours', 'naix-addons' );
		$this->l10n['minutes'] = esc_html__( 'minutes', 'naix-addons' );
		$this->l10n['seconds'] = esc_html__( 'seconds', 'naix-addons' );
		wp_localize_script( 'naix-shortcodes', 'naixShortCode', $this->l10n );
	}

	/**
	 * Get about
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function about( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'        => '',
				'name'         => '',
				'job'          => '',
				'socials_text' => '',
				'source_texts' => '',
				'el_class'     => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];
		$output      = array();

		$output[] = sprintf(
			'<div class="aheader">' .
			'<h2 class="name">%s</h2>' .
			'<p>%s</p>' .
			'</div>',
			$atts['name'],
			$atts['job']
		);

		if ( $content ) {
			$output[] = sprintf(
				'<div class="acontent">' .
				'%s' .
				'</div>',
				$content
			);
		}


		$socials = array();
		if ( $atts['socials_text'] ) {
			$socials[] = sprintf( '<h5>%s</h5>', $atts['socials_text'] );
		}
		$texts = (array) json_decode( urldecode( $atts['source_texts'] ), true );

		if ( $texts ) {
			$socials[] = '<div class="socials-list">';
		}

		foreach ( $texts as $text ) {
			$title = '';
			if ( isset( $text['text'] ) && $text['text'] ) {
				$title = $text['text'];
			}

			$link = '';
			if ( isset( $text['link'] ) && $text['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $text['link'] ) );
					if ( ! empty( $link ) ) {
						$link = sprintf(
							'<a href="%s" class="link" %s%s>%s <span>-</span></a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							esc_html( $title )
						);
					}
				}
			}

			$socials[] = $link ? $link : $title;
		}

		if ( $texts ) {
			$socials[] = '</div>';
		}

		$output[] = sprintf( '<div class="afooter">%s</div>', implode( ' ', $socials ) );

		$bg_html = '';

		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( $atts['image'], 'full' );
			if ( $image ) {
				$bg_html = sprintf( '<div class="featured-img" style="background-image: url(%s)"></div>', esc_url( $image[0] ) );
			}
		}

		return sprintf(
			'<div class="naix-about %s">' .
			'%s' .
			'<div class="container">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			$bg_html,
			implode( ' ', $output )

		);

	}


	/**
	 * Get Section Title
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function section_text_effect( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'        => '',
				'source_texts' => '',
				'el_class'     => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];


		$texts = (array) json_decode( urldecode( $atts['source_texts'] ), true );

		$text_arr  = array();
		$color_arr = array();
		foreach ( $texts as $text ) {
			if ( isset( $text['text'] ) && $text['text'] ) {
				$text_arr[] = $text['text'];
			}

			if ( isset( $text['color'] ) && $text['color'] ) {
				$color_arr[] = $text['color'];
			}
		}

		$id                              = uniqid( 'text-effect-' );
		$this->l10n['textEffect'][ $id ] = array(
			'texts'  => $text_arr,
			'colors' => $color_arr,
		);

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h6 class="title">%s</h6>', $atts['title'] );
		}

		if ( $content ) {
			$output[] = sprintf( '<h2 class="desc" >%s <span class="source-text" id="%s"></span><span class="console-cursor">|</span></h2>', $content, esc_attr( $id ) );
		}

		return sprintf(
			'<div class="naix-section-text-effect %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get Section Title
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function section_title( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'text_align' => '',
				'title'      => '',
				'link'       => '',
				'el_class'   => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];

		if ( $atts['style'] == '2' ) {
			$css_class[] = 'text-' . $atts['text_align'];
		}

		$output = array();

		$link_html = '';
		if ( $atts['style'] != '3' ) {
			if ( isset( $atts['link'] ) && $atts['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $atts['link'] ) );
					if ( ! empty( $link ) ) {
						$link_html = sprintf(
							'<a href="%s" class="link" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							esc_html( $link['title'] )
						);
					}
				}
			}

			$css_class[] = $link_html ? 'has-link' : '';
			if ( $atts['title'] ) {
				$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
			}
		}


		$output[] = $link_html;

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc" >%s</div>', $content );
		}

		return sprintf(
			'<div class="naix-section-title %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}


	/**
	 * Get clients text
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function clients_text( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'source_texts' => '',
				'text_align'   => '',
				'el_class'     => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];
		$css_class[] = 'text-' . $atts['text_align'];


		$texts  = (array) json_decode( urldecode( $atts['source_texts'] ), true );
		$output = array();

		if ( $texts ) {
			$output[] = '<div class="clients-content">';

			foreach ( $texts as $text ) {

				$text_html = '';
				if ( isset( $text['text'] ) && $text['text'] ) {
					$text_html = $text['text'];
				}

				$link_html = '';
				if ( isset( $text['link'] ) && $text['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $text['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="text" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								esc_html( $text_html )
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$output[] = $link_html;
			}

			$output[] = '</div>';

		}


		return sprintf(
			'<div class="naix-clients-texts %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get testimonial
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function testimonial( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'text_align' => '',
				'name'       => '',
				'job'        => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];
		if ( $atts['style'] == '2' ) {
			$css_class[] = 'text-' . $atts['text_align'];
		}

		$output = array();

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = $content;
		}

		$cite = '';
		if ( $atts['name'] ) {
			$cite .= sprintf( '<span class="name">%s</span>', $atts['name'] );
		}

		if ( $atts['job'] ) {
			$cite .= sprintf( '<span class="job">%s</span>', $atts['job'] );
		}

		if ( $cite ) {
			$output[] = sprintf( '<cite>%s</cite>', $cite );
		}


		return sprintf(
			'<div class="naix-testimonial %s">' .
			'<blockquote>' .
			'%s' .
			'</blockquote>' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get member
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function member( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'    => '',
				'name'     => '',
				'job'      => '',
				'socials'  => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['name'] ) {
			$output[] = sprintf( '<h4 class="name">%s</h4>', $atts['name'] );
		}

		if ( $atts['job'] ) {
			$output[] = sprintf( '<span class="job">%s</span>', $atts['job'] );
		}

		$socials = (array) json_decode( urldecode( $atts['socials'] ), true );

		$socials_html = '';
		if ( $socials ) {
			foreach ( $socials as $social ) {

				$text_html = '';
				if ( isset( $social['icon_ionicons'] ) && $social['icon_ionicons'] ) {
					$text_html = sprintf( '<i class="%s"></i>', esc_attr( $social['icon_ionicons'] ) );
				}

				$link_html = '';
				if ( isset( $social['link'] ) && $social['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $social['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="link" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								$text_html
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$socials_html .= $link_html;
			}

		}

		if ( $socials_html ) {
			$output[] = sprintf( '<div class="socials">%s</div>', $socials_html );
		}

		$image_html = '';
		if ( $atts['image'] ) {
			$image_html = wp_get_attachment_image( $atts['image'], 'full' );
		}


		return sprintf(
			'<div class="naix-member %s">' .
			'%s' .
			'<div class="member-content">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			$image_html,
			implode( ' ', $output )

		);

	}

	/**
	 * Get socials
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function socials( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'type'         => 'icon',
				'title'        => '',
				'size'         => '',
				'socials'      => '',
				'socials_text' => '',
				'el_class'     => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'type-' . $atts['type'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['type'] == 'icon' ) {

			$css_class[] = 'size-' . $atts['size'];
			$socials     = (array) json_decode( urldecode( $atts['socials'] ), true );

			if ( $socials ) {
				foreach ( $socials as $social ) {

					$color = '';
					if ( isset( $social['color'] ) && $social['color'] ) {
						$color = 'style="color:' . $social['color'] . '"';
					}

					$text_html = '';
					if ( isset( $social['icon_ionicons'] ) && $social['icon_ionicons'] ) {
						$text_html = sprintf( '<i class="%s" %s></i>', esc_attr( $social['icon_ionicons'] ), $color );
					}

					$link_html = '';
					if ( isset( $social['link'] ) && $social['link'] ) {
						if ( function_exists( 'vc_build_link' ) ) {
							$link = array_filter( vc_build_link( $social['link'] ) );
							if ( ! empty( $link ) ) {
								$link_html = sprintf(
									'<a href="%s" class="link" %s%s>%s</a>',
									esc_url( $link['url'] ),
									! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
									! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
									$text_html
								);
							}
						}
					}

					if ( empty ( $link_html ) ) {
						$link_html = $text_html;
					}

					$output[] = $link_html;
				}

			}
		} else {
			$socials = (array) json_decode( urldecode( $atts['socials_text'] ), true );

			if ( $socials ) {
				foreach ( $socials as $social ) {

					$color = '';
					if ( isset( $social['color'] ) && $social['color'] ) {
						$color = 'style="color:' . $social['color'] . '"';
					}

					$text_html = '';
					if ( isset( $social['text'] ) && $social['text'] ) {
						$text_html = sprintf( '<span class="text" %s>%s</span>', $color, esc_attr( $social['text'] ) );
					}

					$link_html = '';
					if ( isset( $social['link'] ) && $social['link'] ) {
						if ( function_exists( 'vc_build_link' ) ) {
							$link = array_filter( vc_build_link( $social['link'] ) );
							if ( ! empty( $link ) ) {
								$link_html = sprintf(
									'<a href="%s" class="link" %s%s>%s</a>',
									esc_url( $link['url'] ),
									! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
									! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
									$text_html
								);
							}
						}
					}

					if ( empty ( $link_html ) ) {
						$link_html = $text_html;
					}

					$output[] = $link_html;
				}

			}
		}


		return sprintf(
			'<div class="naix-socials %s">' .
			'<div class="socials-list">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Comming soon shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function countdown( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'date'     => '',
				'el_class' => '',
			), $atts
		);

		$output = array();

		$second = 0;
		if ( $atts['date'] ) {
			$second_current = strtotime( date_i18n( 'Y/m/d H:i:s' ) );
			$date           = new DateTime( $atts['date'] );
			if ( $date ) {
				$second_discount = strtotime( date_i18n( 'Y/m/d H:i:s', $date->getTimestamp() ) );
				if ( $second_discount > $second_current ) {
					$second = $second_discount - $second_current;
				}
			}

		}

		if ( $second ) :
			$output[] = sprintf( '<div class="countdown-date">%s</div>', $second );
		endif;

		return sprintf(
			'<div class="naix-countdown %s">%s</div>',
			esc_attr( $atts['el_class'] ),
			implode( '', $output )
		);
	}

	/**
	 * Get clients text
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function services_text( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'        => '',
				'source_texts' => '',
				'el_class'     => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];


		$texts  = (array) json_decode( urldecode( $atts['source_texts'] ), true );
		$output = array();
		if ( $atts['title'] ) {
			$output[] = sprintf( '<h6 class="title">%s</h6>', $atts['title'] );
		}

		if ( $texts ) {
			foreach ( $texts as $text ) {

				$text_html = '';
				if ( isset( $text['text'] ) && $text['text'] ) {
					$text_html = $text['text'];
				}

				$link_html = '';
				if ( isset( $text['link'] ) && $text['link'] ) {
					if ( function_exists( 'vc_build_link' ) ) {
						$link = array_filter( vc_build_link( $text['link'] ) );
						if ( ! empty( $link ) ) {
							$link_html = sprintf(
								'<a href="%s" class="text" %s%s>%s</a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
								esc_html( $text_html )
							);
						}
					}
				}

				if ( empty ( $link_html ) ) {
					$link_html = sprintf(
						'<span class="text">%s</span>',
						esc_html( $text_html )
					);
				}

				$output[] = $link_html;
			}

		}


		return sprintf(
			'<div class="naix-services-texts %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get clients text
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function awards_text( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'year'         => '',
				'source_texts' => '',
				'el_class'     => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];


		$texts  = (array) json_decode( urldecode( $atts['source_texts'] ), true );
		$output = array();
		if ( $atts['year'] ) {
			$output[] = sprintf( '<div class="col-md-3 col-sm-3 col-xs-12>"> <h6 class="year">%s</h6></div>', $atts['year'] );
		}

		$text_ouput = array();
		if ( $texts ) {
			foreach ( $texts as $text ) {

				$text_html = '';
				if ( isset( $text['subtitle'] ) && $text['subtitle'] ) {
					$text_html .= sprintf( '<span class="subtitle">%s</span>', $text['subtitle'] );
				}

				if ( isset( $text['title'] ) && $text['title'] ) {
					$text_html .= sprintf( '<h2 class="title">%s</h2>', $text['title'] );
				}

				$text_ouput[] = sprintf( '<div class="award-item">%s</div>', $text_html );
			}

		}

		$output[] = sprintf( '<div class="col-md-9 col-sm-9 col-xs-12>">%s</div>', implode( ' ', $text_ouput ) );


		return sprintf(
			'<div class="naix-awards-texts %s">' .
			'<div class="row">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get empty space
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function empty_space( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'height'        => '',
				'height_mobile' => '',
				'height_tablet' => '',
				'el_class'      => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];

		$height        = $atts['height'] ? (float) $atts['height'] : '';
		$height_tablet = $atts['height_tablet'] ? (float) $atts['height_tablet'] : $height;
		$height_mobile = $atts['height_mobile'] ? (float) $atts['height_mobile'] : $height_tablet;

		$inline_css        = $height >= 0.0 ? ' style="height: ' . esc_attr( $height ) . 'px"' : '';
		$inline_css_mobile = $height_mobile >= 0.0 ? ' style="height: ' . esc_attr( $height_mobile ) . 'px"' : '';
		$inline_css_tablet = $height_tablet >= 0.0 ? ' style="height: ' . esc_attr( $height_tablet ) . 'px"' : '';


		return sprintf(
			'<div class="naix-empty-space %s">' .
			'<div class="nx_empty_space_lg" %s></div>' .
			'<div class="nx_empty_space_md" %s></div>' .
			'<div class="nx_empty_space_xs" %s></div>' .
			'</div>',
			implode( ' ', $css_class ),
			$inline_css,
			$inline_css_tablet,
			$inline_css_mobile
		);

	}

	/**
	 * Get portfolio list
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_list( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'    => '1',
				'items'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		$i            = 0;
		$first_image  = '';
		$second_image = '';
		foreach ( $items as $item ) {

			$image_src = '';
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image     = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$image_src = $image ? $image[0] : '';
			}

			$title_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$title_html .= sprintf( '<h2>%s</h2>', $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$title_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			$item_html = '';
			if ( isset( $item['link'] ) && $item['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['link'] ) );
					if ( ! empty( $link ) ) {
						$item_html = sprintf(
							'<a href="%s" class="port-title" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$title_html
						);
					}
				}
			}

			if ( empty( $item_html ) ) {
				$item_html = $title_html;
			}

			if ( $atts['style'] == '1' ) {

				$item_class = '';
				if ( isset( $item['text_color'] ) && $item['text_color'] ) {
					$item_class = 'text-' . $item['text_color'];
				}

				$output[] = sprintf(
					'<div class="port-item %s"> ' .
					'<div class="port-content" > ' .
					'%s' .
					'</div > ' .
					'<div class="port-bg-white" ></div>' .
					'<div class="port-bg"  style="background-image: url(%s)"></div>' .
					'</div > ',
					esc_attr( $item_class ),
					$item_html,
					esc_url( $image_src )
				);
			} else {
				$class_active = '';
				if ( $i == 0 ) {
					$first_image  = $image_src;
					$class_active = 'active';
				}

				if ( $i == 1 ) {
					$second_image = $image_src;
				}

				$i ++;
				$output[] = sprintf(
					'<div class="port-item %s">' .
					'<div class="port-content" data-image="%s"> ' .
					'%s' .
					'</div > ' .
					'</div > ',
					esc_attr( $class_active ),
					esc_url( $image_src ),
					$item_html

				);
			}

		}

		if ( $output ) {
			if ( $atts['style'] == '1' ) {
				return sprintf(
					'<div class="naix-portfolios-list %s">' .
					'%s' .
					'</div>',
					implode( ' ', $css_class ),
					implode( ' ', $output )
				);
			} else {
				$second_image = $second_image ? $second_image : $first_image;

				return sprintf(
					'<div class="naix-portfolios-list %s">' .
					'<div class="port-list">' .
					'<div class="row">' .
					'<div class="col-md-6 col-sm-12 col-xs-12">' .
					'%s' .
					'</div>' .
					'<div class="col-md-6 hidden-sm hidden-xs">' .
					'<div class="port-first-image port-image" style="background-image: url(%s);"></div>' .
					'<div class="port-second-image port-image noactive" style="background-image: url(%s);"></div>' .
					'</div>' .
					'</div>' .
					'</div>' .
					'</div>',
					implode( ' ', $css_class ),
					implode( ' ', $output ),
					esc_url( $first_image ),
					esc_url( $second_image )
				);
			}
		}

	}

	/**
	 * Get portfolio list filter
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_list_filter( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'        => '',
				'subtitle'     => '',
				'source'       => 'default',
				'cats_filters' => '1',
				'cats'         => '',
				'per_page'     => '5',
				'orderby'      => 'date',
				'order'        => 'desc',
				'ids'          => '',
				'el_class'     => '',
			), $atts
		);


		if ( ! $this->portfolio_actived ) {
			return '';
		}

		$css_class[] = $atts['el_class'];

		$args = array(
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<div class="subtitle">%s</div>', $atts['subtitle'] );
		}

		if ( $atts['source'] == 'default' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];
			$args['posts_per_page'] = intval( $atts['per_page'] );


			if ( intval( $atts['cats_filters'] ) ) {
				if ( empty( $atts['cats'] ) ) {
					return;
				}

				$cats        = explode( ',', $atts['cats'] );
				$filter_html = '';
				$item_html   = array();
				foreach ( $cats as $cat ) {

					$cat_item = get_term_by( 'slug', $cat, 'portfolio_category' );

					if ( $cat_item ) {
						$filter_html .= sprintf( '<li><a href="#">%s</a></li>', $cat_item->name );
					}
					$args['tax_query'] = array(
						array(
							'taxonomy' => 'portfolio_category',
							'field'    => 'slug',
							'terms'    => $cat,
						),
					);
					$query             = new WP_Query( $args );
					$item_html[]       = $this->get_portfolios_list_filter( $query );
					wp_reset_postdata();
				}

				if ( $filter_html ) {
					$output[] = sprintf( '<ul class="cats-filter tabs-nav">%s</ul>', $filter_html );
				}

				if ( $item_html ) {
					$output[] = sprintf( '<div class="port-list">%s</div>', implode( ' ', $item_html ) );
				}

			} else {
				if ( $atts['cats'] ) {
					$cats              = explode( ',', $atts['cats'] );
					$args['tax_query'] = array(
						array(
							'taxonomy' => 'portfolio_category',
							'field'    => 'slug',
							'terms'    => $cats,
						),
					);
				}

				$query    = new WP_Query( $args );
				$output[] = sprintf( '<div class="port-list">%s</div>', $this->get_portfolios_list_filter( $query ) );
				wp_reset_postdata();
			}


		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids                    = explode( ',', $atts['ids'] );
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = '-1';

			$query    = new WP_Query( $args );
			$output[] = sprintf( '<div class="port-list">%s</div>', $this->get_portfolios_list_filter( $query ) );
			wp_reset_postdata();
		}


		return sprintf(
			'<div class="naix-portfolios-list-filter tabs %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )
		);

	}

	/**
	 * Get portfolio list filter
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function get_portfolios_list_filter( $query ) {
		$output = array();
		while ( $query->have_posts() ) : $query->the_post();

			$image_size = '1175x740';
			$image_src  = '';
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => get_post_thumbnail_id( get_the_ID() ),
						'thumb_size' => $image_size,
					)
				);

				if ( $image['thumbnail'] ) {
					$image_src = $image['thumbnail'];
				} elseif ( $image['p_img_large'] ) {
					$image_src = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
				}

			}

			if ( empty( $image_src ) ) {
				$image_src = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), $image_size );
			}

			$term_list      = wp_get_post_terms( get_the_ID(), 'portfolio_category', array( 'fields' => 'names' ) );
			$term_list_html = '';
			if ( ! is_wp_error( $term_list ) && $term_list ) {
				$term_list_html = '<p>' . implode( ', ', $term_list ) . '</p>';
			}

			$item_class = '';
			$text_color = get_post_meta( get_the_ID(), 'pl_text_color', true );
			if ( $text_color ) {
				$item_class .= ' portfolio-text-' . $text_color;
			}

			$output[] = sprintf(
				'<div class="port-item %s">' .
				'%s' .
				'<div class="port-content"> ' .
				'<a href="%s" class="port-title" > ' .
				'%s' .
				'<h2 >%s </h2 > ' .
				'</a > ' .
				'<a href="%s" class="port-link" > ' .
				'<i class="icon-arrow-right"></i>' .
				'</a > ' .
				'</div > ' .
				'</div > ',
				esc_attr( $item_class ),
				$image_src,
				esc_url( get_the_permalink() ),
				$term_list_html,
				get_the_title(),
				esc_url( get_the_permalink() )

			);

		endwhile;

		return sprintf( '<div class="port-group tabs-panel">%s</div>', implode( ' ', $output ) );
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_grid( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'              => '1',
				'columns'            => '2',
				'source'             => '1',
				'cats'               => '',
				'per_page'           => '7',
				'orderby'            => 'date',
				'order'              => 'desc',
				'ids'                => '',
				'button'             => '',
				'cats_filter'        => '',
				'cats_filter_number' => '4',
				'cats_text_align'    => 'center',
				'hover_style'        => '1',
				'el_class'           => '',
			), $atts
		);

		if ( ! $this->portfolio_actived ) {
			return '';
		}


		$css_class[] = $atts['el_class'];
		$css_class[] = 'portfolio-grid-' . $atts['style'];
		$output      = array();

		$args = array(
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		if ( $atts['source'] == '1' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];
			$args['posts_per_page'] = intval( $atts['per_page'] );

			if ( $atts['cats'] ) {
				$cats              = explode( ',', $atts['cats'] );
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio_category',
						'field'    => 'slug',
						'terms'    => $cats,
					),
				);
			}

		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids                    = explode( ',', $atts['ids'] );
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = '-1';
		}
		global $naix_portfolio_loop;

		if ( in_array( $atts['style'], array( '2', '3' ) ) ) {
			$naix_portfolio_loop['hover_style'] = $atts['hover_style'];
		}

		$query       = new WP_Query( $args );
		$cats_filter = array();
		while ( $query->have_posts() ) : $query->the_post();
			if ( $atts['cats_filter'] ) {
				$post_categories = wp_get_post_terms( get_the_ID(), 'portfolio_category' );
				if ( ! is_wp_error( $post_categories ) && $post_categories ) {
					foreach ( $post_categories as $cat ) {
						if ( empty( $cats_filter[ $cat->term_id ] ) ) {
							$cats_filter[ $cat->term_id ] = array( 'name' => $cat->name, 'slug' => $cat->slug, );
						}
					}
				}
			}

			$naix_portfolio_loop['size']            = 'naix-portfolio-grid';
			$naix_portfolio_loop['portfolio_class'] = 'col-md-6 col-sm-6 col-xs-6';

			if ( $atts['columns'] == '3' ) {
				$naix_portfolio_loop['portfolio_class'] = 'col-md-4 col-sm-4 col-xs-6';
			} elseif ( $atts['columns'] == '4' ) {
				$naix_portfolio_loop['portfolio_class'] = 'col-lg-3 col-md-4 col-sm-6 col-xs-6';
			}
			ob_start();
			get_template_part( 'template-parts/content', 'portfolio' );
			$output[] = ob_get_clean();

		endwhile;
		wp_reset_postdata();


		$link_html = '';
		if ( isset( $atts['button'] ) && $atts['button'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<div class="ports-footer"><a href="%s" class="text" %s%s>%s</a></div>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						esc_html( $link['title'] )
					);
				}
			}
		}

		$filters = '';
		$j       = 1;
		$number  = intval( $atts['cats_filter_number'] );
		foreach ( $cats_filter as $category ) {
			if ( $j > $number ) {
				break;
			}
			$j ++;
			$filters .= sprintf( '<li><a href="#filter" data-option-value=".%s-%s">%s</a></li>', esc_attr( 'portfolio_category' ), esc_attr( $category['slug'] ), esc_html( $category['name'] ) );
		}

		if ( $filters ) {
			$filters = sprintf(
				'<div class="portfolio-cats-filter text-%s"><ul data-option-key="filter">
				<li><a href="#filter" class="selected" data-option-value="*">%s</a></li>
				 %s
			</ul></div>',
				esc_attr( $atts['cats_text_align'] ),
				esc_html__( 'All', 'naix-addons' ),
				$filters
			);
		}

		return sprintf(
			'<div class="naix-portfolios-grid portfolio-layout-grid %s">' .
			'%s' .
			'<div class="row">' .
			'<div class="naix-portfolio-list">' .
			'%s' .
			'</div>' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$filters,
			implode( ' ', $output ),
			$link_html
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function featured_portfolio( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'cat'       => '',
				'cat_color' => '',
				'title'     => '',
				'link'      => '',
				'el_class'  => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$output      = array();

		if ( $atts['cat'] ) {
			$color_style = '';
			if ( $atts['cat_color'] ) {
				$color_style = sprintf( 'style="color: %s"', $atts['cat_color'] );
			}
			$output[] = sprintf( '<span class="entry-cats" %s>%s</span>', $color_style, $atts['cat'] );
		}

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( isset( $atts['link'] ) && $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$output[] = sprintf(
						'<a href="%s" class="entry-link" %s%s></a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : ''
					);
				}
			}
		}

		return sprintf(
			'<div class="naix-featured-portfolio %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_masonry( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'              => '1',
				'source'             => '1',
				'cats'               => '',
				'per_page'           => '7',
				'orderby'            => 'date',
				'order'              => 'desc',
				'ids'                => '',
				'button'             => '',
				'cats_filter'        => '',
				'cats_filter_number' => '4',
				'cats_text_align'    => 'center',
				'hover_style'        => '1',
				'el_class'           => '',
			), $atts
		);

		if ( ! $this->portfolio_actived ) {
			return '';
		}

		$css_class[] = $atts['el_class'];
		$css_class[] = 'portfolio-masonry-' . $atts['style'];
		$output      = array();

		$args = array(
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		if ( $atts['source'] == '1' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];
			$args['posts_per_page'] = intval( $atts['per_page'] );

			if ( $atts['cats'] ) {
				$cats              = explode( ',', $atts['cats'] );
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio_category',
						'field'    => 'slug',
						'terms'    => $cats,
					),
				);
			}

		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids                    = explode( ',', $atts['ids'] );
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = '-1';
		}
		global $naix_portfolio_loop;

		if ( in_array( $atts['style'], array( '1', '2', '3', '5' ) ) ) {
			$naix_portfolio_loop['hover_style'] = $atts['hover_style'];
		}

		$naix_portfolio_loop['portfolio_layout'] = 'masonry';

		$query       = new WP_Query( $args );
		$cats_filter = array();

		$i = 0;
		while ( $query->have_posts() ) : $query->the_post();
			if ( $atts['cats_filter'] ) {
				$post_categories = wp_get_post_terms( get_the_ID(), 'portfolio_category' );
				if ( ! is_wp_error( $post_categories ) && $post_categories ) {
					foreach ( $post_categories as $cat ) {
						if ( empty( $cats_filter[ $cat->term_id ] ) ) {
							$cats_filter[ $cat->term_id ] = array( 'name' => $cat->name, 'slug' => $cat->slug, );
						}
					}
				}

			}

			if ( $atts['style'] == '1' ) {
				$mod                         = $i % 13;
				$naix_portfolio_loop['size'] = 'naix-portfolio-grid';
				if ( $mod == 3 || $mod == 5 || $mod == 7 ) {
					$naix_portfolio_loop['size'] = 'naix-portfolio-masonry1';
				}
				$naix_portfolio_loop['portfolio_class'] = 'col-md-3 col-sm-6 col-xs-12';
			} elseif ( $atts['style'] == '2' ) {
				$naix_portfolio_loop['size'] = 'naix-portfolio-grid';
				$mod                         = $i % 8;
				if ( in_array( $mod, array( 1, 3, 4, 5 ) ) ) {
					$naix_portfolio_loop['size']            = 'naix-portfolio-masonry2';
					$naix_portfolio_loop['size_registered'] = 1;
				}

				$naix_portfolio_loop['portfolio_class'] = 'col-md-4 col-sm-6 col-xs-12';
			} elseif ( $atts['style'] == '3' ) {
				$naix_portfolio_loop['size']            = 'naix-portfolio-grid';
				$mod                                    = $i % 8;
				$naix_portfolio_loop['portfolio_class'] = 'col-md-12 col-sm-12 col-xs-12';
				if ( in_array( $mod, array( 0, 5 ) ) ) {
					$naix_portfolio_loop['size']            = 'naix-portfolio-masonry3';
					$naix_portfolio_loop['portfolio_class'] = 'portfolio-full';
					$naix_portfolio_loop['size_registered'] = 1;
				} elseif ( $mod == 2 ) {
					$naix_portfolio_loop['size']            = 'naix-portfolio-masonry1';
					$naix_portfolio_loop['portfolio_class'] = 'portfolio-long';
					$naix_portfolio_loop['size_registered'] = 1;
				} elseif ( $mod == 4 ) {
					$naix_portfolio_loop['size']            = 'naix-portfolio-masonry4';
					$naix_portfolio_loop['portfolio_class'] = 'portfolio-wide';
					$naix_portfolio_loop['size_registered'] = 1;
				}
			} elseif ( $atts['style'] == '4' ) {
				$naix_portfolio_loop['size']            = 'naix-portfolio-masonry5';
				$naix_portfolio_loop['portfolio_class'] = 'col-md-4 col-sm-6 col-xs-12';
				$naix_portfolio_loop['size_registered'] = 1;
			} elseif ( $atts['style'] == '5' ) {
				$naix_portfolio_loop['size']            = '480x500';
				$naix_portfolio_loop['size_registered'] = 0;
				$mod                                    = $i % 9;
				$naix_portfolio_loop['portfolio_class'] = 'col-lg-3 col-md-4 col-sm-6 col-xs-6';
				if ( in_array( $mod, array( 1, 4, 8 ) ) ) {
					$naix_portfolio_loop['size'] = '480x380';
				} elseif ( $mod == 2 ) {
					$naix_portfolio_loop['size'] = '480x605';
				} elseif ( $mod == 3 ) {
					$naix_portfolio_loop['size'] = '480x446';
				} elseif ( $mod == 5 ) {
					$naix_portfolio_loop['size'] = '480x694';
				} elseif ( $mod == 6 ) {
					$naix_portfolio_loop['size'] = '480x640';
				} elseif ( $mod == 7 ) {
					$naix_portfolio_loop['size'] = '480x535';
				}
			}

			$naix_portfolio_loop['current_portfolio'] = $i;

			$i ++;
			ob_start();
			get_template_part( 'template-parts/content', 'portfolio' );
			$output[] = ob_get_clean();

		endwhile;
		wp_reset_postdata();


		$link_html = '';
		if ( isset( $atts['button'] ) && $atts['button'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<div class="ports-footer"><a href="%s" class="text" %s%s>%s</a></div>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						esc_html( $link['title'] )
					);
				}
			}
		}

		$filters = '';
		$j       = 1;
		$number  = intval( $atts['cats_filter_number'] );
		foreach ( $cats_filter as $category ) {
			if ( $j > $number ) {
				break;
			}
			$j ++;
			$filters .= sprintf( '<li><a href="#filter" data-option-value=".%s-%s">%s</a></li>', esc_attr( 'portfolio_category' ), esc_attr( $category['slug'] ), esc_html( $category['name'] ) );
		}

		if ( $filters ) {
			$filters = sprintf(
				'<div class="portfolio-cats-filter text-%s"><ul data-option-key="filter">
				<li><a href="#filter" class="selected" data-option-value="*">%s</a></li>
				 %s
			</ul></div>',
				esc_attr( $atts['cats_text_align'] ),
				esc_html__( 'All', 'naix-addons' ),
				$filters
			);
		}

		return sprintf(
			'<div class="naix-portfolios-masonry portfolio-layout-masonry %s">' .
			'%s' .
			'<div class="row">' .
			'<div class="naix-portfolio-list">' .
			'%s' .
			'</div>' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$filters,
			implode( ' ', $output ),
			$link_html
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_free( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'              => '1',
				'hover_style'        => '1',
				'source'             => '1',
				'cats'               => '',
				'per_page'           => '7',
				'orderby'            => 'date',
				'order'              => 'desc',
				'ids'                => '',
				'button'             => '',
				'cats_filter'        => '',
				'cats_filter_number' => '4',
				'el_class'           => '',
			), $atts
		);

		if ( ! $this->portfolio_actived ) {
			return '';
		}

		$css_class[] = $atts['el_class'];
		$css_class[] = 'portfolio-free-' . $atts['style'];
		$output      = array();

		$args = array(
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		if ( $atts['source'] == '1' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];
			$args['posts_per_page'] = intval( $atts['per_page'] );

			if ( $atts['cats'] ) {
				$cats              = explode( ',', $atts['cats'] );
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio_category',
						'field'    => 'slug',
						'terms'    => $cats,
					),
				);
			}

		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids                    = explode( ',', $atts['ids'] );
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = '-1';
		}

		global $naix_portfolio_loop;
		$naix_portfolio_loop['portfolio_layout'] = 'free';
		if ( in_array( $atts['style'], array( '1', '2' ) ) ) {
			$naix_portfolio_loop['hover_style'] = $atts['hover_style'];
		}

		$query       = new WP_Query( $args );
		$i           = 0;
		$cats_filter = array();
		while ( $query->have_posts() ) : $query->the_post();

			if ( $atts['cats_filter'] ) {
				$post_categories = wp_get_post_terms( get_the_ID(), 'portfolio_category' );
				if ( ! is_wp_error( $post_categories ) && $post_categories ) {
					foreach ( $post_categories as $cat ) {
						if ( empty( $cats_filter[ $cat->term_id ] ) ) {
							$cats_filter[ $cat->term_id ] = array( 'name' => $cat->name, 'slug' => $cat->slug, );
						}
					}
				}
			}
			$naix_portfolio_loop['current_portfolio'] = $i;
			$naix_portfolio_loop['size']              = 'naix-portfolio-grid';
			$naix_portfolio_loop['portfolio_class']   = 'col-md-6 col-sm-6 col-xs-12';

			if ( $atts['style'] == '1' ) {
				$naix_portfolio_loop['portfolio_class'] = '';
				$naix_portfolio_loop['size']            = 'naix-portfolio-free1';
				$naix_portfolio_loop['size_registered'] = 1;

				$mod = $i % 8;
				if ( $mod == 1 || $mod == 3 ) {
					$naix_portfolio_loop['portfolio_class'] = 'portfolio-wide';
					$naix_portfolio_loop['size']            = 'naix-portfolio-free2';
					$naix_portfolio_loop['size_registered'] = 1;
				} elseif ( $mod == 2 ) {
					$naix_portfolio_loop['portfolio_class'] = 'portfolio-full';
					$naix_portfolio_loop['size']            = 'naix-portfolio-free3';
					$naix_portfolio_loop['size_registered'] = 1;
				}
			} elseif ( $atts['style'] == '2' ) {
				$naix_portfolio_loop['portfolio_class'] = 'col-md-3 col-sm-3 col-xs-6';
				$naix_portfolio_loop['size']            = '270x440';
				$naix_portfolio_loop['size_registered'] = 0;
				$mod                                    = $i % 7;
				if ( $mod == 0 ) {
					$naix_portfolio_loop['portfolio_class'] = 'col-md-6 col-sm-6 col-xs-12';
					$naix_portfolio_loop['size']            = '570x440';
					$naix_portfolio_loop['size_registered'] = 0;
				}
			}
			$i ++;

			ob_start();
			get_template_part( 'template-parts/content', 'portfolio' );
			$output[] = ob_get_clean();

		endwhile;
		wp_reset_postdata();


		$link_html = '';
		if ( isset( $atts['button'] ) && $atts['button'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<div class="ports-footer"><a href="%s" class="text" %s%s>%s</a></div>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						esc_html( $link['title'] )
					);
				}
			}
		}

		$filters = '';
		$j       = 1;
		$number  = intval( $atts['cats_filter_number'] );
		foreach ( $cats_filter as $category ) {
			if ( $j > $number ) {
				break;
			}
			$j ++;
			$filters .= sprintf( '<li><a href="#filter" data-option-value=".%s-%s">%s</a></li>', esc_attr( 'portfolio_category' ), esc_attr( $category['slug'] ), esc_html( $category['name'] ) );
		}

		if ( $filters ) {
			$filters = sprintf(
				'<div class="portfolio-cats-filter"> <ul class="cats-filter" data-option-key="filter">
				<li><a href="#filter" class="selected" data-option-value="*">%s</a></li>
				 %s
			</ul></div>',
				esc_html__( 'All', 'naix-addons' ),
				$filters
			);
		}

		return sprintf(
			'<div class="naix-portfolios-free portfolio-layout-free %s">' .
			'%s' .
			'<div class="row">' .
			'<div class="naix-portfolio-list">' .
			'%s' .
			'</div>' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$filters,
			implode( ' ', $output ),
			$link_html
		);
	}

	/**
	 * Get portfolio grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function portfolios_grid_gap( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'source'   => '1',
				'cats'     => '',
				'per_page' => '9',
				'orderby'  => 'date',
				'order'    => 'desc',
				'ids'      => '',
				'button'   => '',
				'el_class' => '',
			), $atts
		);

		if ( ! $this->portfolio_actived ) {
			return '';
		}

		$css_class[] = $atts['el_class'];
		$output      = array();

		$args = array(
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		if ( $atts['source'] == '1' ) {
			$args['orderby']        = $atts['orderby'];
			$args['order']          = $atts['order'];
			$args['posts_per_page'] = intval( $atts['per_page'] );

			if ( $atts['cats'] ) {
				$cats              = explode( ',', $atts['cats'] );
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio_category',
						'field'    => 'slug',
						'terms'    => $cats,
					),
				);
			}

		} else {
			if ( empty( $atts['ids'] ) ) {
				return false;
			}

			$ids                    = explode( ',', $atts['ids'] );
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = '-1';
		}

		$query = new WP_Query( $args );
		$i     = 1;
		while ( $query->have_posts() ) : $query->the_post();

			$image_size = '490x320';
			$item_class = 'port-wide';

			$mod = $i % 9;
			if ( $mod == 2 ||
			     $mod == 4 ||
			     $mod == 6 ||
			     $mod == 8
			) {
				$image_size = '320x490';
				$item_class = 'port-long';
			}
			$i ++;

			$image_src = '';
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => get_post_thumbnail_id( get_the_ID() ),
						'thumb_size' => $image_size,
					)
				);

				if ( $image['thumbnail'] ) {
					$image_src = $image['thumbnail'];
				} elseif ( $image['p_img_large'] ) {
					$image_src = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
				}

			}

			if ( empty( $image_src ) ) {
				$image_src = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), $image_size );
			}

			$term_list      = wp_get_post_terms( get_the_ID(), 'portfolio_category', array( 'fields' => 'names' ) );
			$term_list_html = '';
			if ( ! is_wp_error( $term_list ) && $term_list ) {
				$term_list_html = '<p><span>' . $term_list[0] . '</span></p>';
			}

			$output[] = sprintf(
				'<div class="col-md-4 col-sm-4 col-xs-6 port-item %s" > ' .
				'<div class="port-content" > ' .
				'%s' .
				'</div > ' .
				'<a href= "%s" class="port-title" > ' .
				'</a> ' .
				'<div class="port-heading" > ' .
				'<h2>%s</h2> ' .
				'%s' .
				'</div > ' .
				'</div > ',
				esc_attr( $item_class ),
				$image_src,
				esc_url( get_the_permalink() ),
				get_the_title(),
				$term_list_html
			);


		endwhile;
		wp_reset_postdata();


		$link_html = '';
		if ( isset( $atts['button'] ) && $atts['button'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<div class="ports-footer"><a href="%s" class="text" %s%s>%s</a></div>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						esc_html( $link['title'] )
					);
				}
			}
		}

		return sprintf(
			'<div class="naix-portfolios-grid-gap %s">' .
			'<div class="ports-list">' .
			'%s' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output ),
			$link_html
		);
	}

	/**
	 * Get posts grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */

	function posts_grid( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'cats'     => '',
				'per_page' => '3',
				'orderby'  => 'date',
				'order'    => 'desc',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$output      = array();

		$args = array(
			'ignore_sticky_posts' => true,
			'post_type'           => 'post',
		);

		$args['orderby']        = $atts['orderby'];
		$args['order']          = $atts['order'];
		$args['posts_per_page'] = intval( $atts['per_page'] );

		if ( $atts['cats'] ) {
			$args['category_name'] = $atts['cats'];
		}


		$query = new WP_Query( $args );
		while ( $query->have_posts() ) : $query->the_post();
			$time_string   = '<time class="e-date" datetime="%1$s">%2$s</time>';
			$time_string   = sprintf(
				$time_string,
				esc_attr( get_the_date( 'c' ) ),
				esc_html( get_the_date() )
			);
			$archive_year  = get_the_time( 'Y' );
			$archive_month = get_the_time( 'm' );
			$archive_day   = get_the_time( 'd' );

			$image_html = wp_get_attachment_image( get_post_thumbnail_id(), 'naix-blog-grid' );

			if ( $image_html ) {
				$image_html = sprintf( '<a class="image-link" href="%s">%s</a>', esc_url( get_the_permalink() ), $image_html );
			}

			$categories_list = get_the_category_list( ', ' );

			$posted_on = sprintf(
				'<span class="entry-author entry-meta">' . ' ' . esc_html__( 'by', 'naix-addons' ) . ' ' . '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
			);

			$output[] = sprintf(
				'<div class="col-md-4 col-sm-4 col-xs-12">' .
				'<div class="post-item ">' .
				'%s' .
				'<div class="post-content">' .
				'%s' .
				'<h2 class="post-title"><a href="%s">%s</a></h2>' .
				'<a href="%s" class="entry-date">%s</a>' .
				'%s' .
				'</div>' .
				'</div>' .
				'</div>',
				$image_html,
				$categories_list,
				esc_url( get_the_permalink() ),
				get_the_title(),
				esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ),
				$time_string,
				$posted_on
			);
		endwhile;
		wp_reset_postdata();

		return sprintf(
			'<div class="naix-posts %s">' .
			'<div class="row">' .
			'%s' .
			'</div>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Get banner
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function banner( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'         => '1',
				'background'    => 'image',
				'bg_image'      => '',
				'poster'        => '',
				'video'         => '',
				'mute'          => '',
				'image_content' => '',
				'height'        => '',
				'title'         => '',
				'subtitle'      => '',
				'text_left'     => '',
				'text_right'    => '',
				'items_text'    => '',
				'items'         => '',
				'button'        => '',
				'parallax'      => '',
				'opacity'       => '',
				'el_class'      => '',
			), $atts
		);

		$output = array();

		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];


		if ( $atts['parallax'] ) {
			if ( $atts['style'] == '1' ) {
				$css_class[] = 'parallax-2';
			} else {
				$css_class[] = 'parallax';
			}
		}

		if ( $atts['opacity'] ) {
			$css_class[] = 'opacity';
		}

		$header_output = '';
		$item_banner   = array();

		if ( $atts['background'] == 'image' ) {

			if ( $atts['bg_image'] ) {
				$header_output = sprintf(
					'<div class="featured-image" style="background-image:url(%s)"></div>',
					esc_url( wp_get_attachment_image_url( $atts['bg_image'], 'full' ) )
				);
			}

		} else {
			$poster = '';
			if ( $atts['poster'] ) {
				$poster = wp_get_attachment_image_url( $atts['poster'], 'full' );
			}
			$ext = wp_check_filetype( $atts['video'] );

			$v_style = '';
			if ( $atts['height'] ) {
				$v_style = 'height="' . esc_attr( $atts['height'] ) . '"';
			}

			$v_style .= ! empty( $atts['mute'] ) ? ' muted' : ' ';


			$header_output = sprintf(
				'<video  preload="none" poster="%s" loop autoplay %s>
					<source src="%s" type="%s">
				</video>',
				esc_url( $poster ),
				$v_style,
				esc_url( $atts['video'] ),
				esc_attr( $ext['type'] )
			);
		}

		if ( $atts['text_left'] ) {
			$header_output .= sprintf(
				'<div class="text-left"><span class="text">%s</span></div>',
				$atts['text_left']
			);
		}

		if ( $atts['text_right'] ) {
			$header_output .= sprintf(
				'<div class="text-right"><span class="text">%s</span></div>',
				$atts['text_right']
			);
		}

		if ( $atts['style'] == '1' ) {
			if ( $atts['image_content'] ) {
				$output[] = wp_get_attachment_image( $atts['image_content'], 'full' );
			}
		} else if ( $atts['style'] == '2' ) {
			if ( $atts['title'] ) {
				$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
			}

			if ( $content ) {
				$output[] = sprintf( '<p class="desc">%s</p>', $content );
			}

			if ( isset( $atts['button'] ) && $atts['button'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $atts['button'] ) );
					if ( ! empty( $link ) ) {
						$output[] = sprintf(
							'<a href="%s" class="link" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							esc_html( $link['title'] )
						);
					}
				}
			}
		} else if ( $atts['style'] == '3' ) {
			if ( $atts['subtitle'] ) {
				$output[] = sprintf( '<span class="subtitle">%s</span>', $atts['subtitle'] );
			}
			if ( $atts['title'] ) {
				$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
			}

			$item_banner[] = '<div class="items-banner">';
			if ( $atts['items_text'] ) {
				$item_banner[] = sprintf( '<div class="items-text">%s</div>', $atts['items_text'] );
			}

			$texts = (array) json_decode( urldecode( $atts['items'] ), true );

			if ( $texts ) {
				$item_banner[] = '<div class="items-content">';

				foreach ( $texts as $text ) {

					$text_html = '';
					if ( isset( $text['text'] ) && $text['text'] ) {
						$text_html = $text['text'];
					}

					$link_html = '';
					if ( isset( $text['link'] ) && $text['link'] ) {
						if ( function_exists( 'vc_build_link' ) ) {
							$link = array_filter( vc_build_link( $text['link'] ) );
							if ( ! empty( $link ) ) {
								$link_html = sprintf(
									'<a href="%s" class="text" %s%s>%s</a>',
									esc_url( $link['url'] ),
									! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
									! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
									esc_html( $text_html )
								);
							}
						}
					}

					if ( empty ( $link_html ) ) {
						$link_html = sprintf(
							'<span class="text">%s</span>',
							esc_html( $text_html )
						);
					}

					$item_banner[] = $link_html;
				}

				$item_banner[] = '</div>';

			}

			$item_banner[] = '</div>';

		}


		$style_css = '';
		if ( $atts['height'] ) {
			$style_css = sprintf( 'style="height:%spx"', intval( $atts['height'] ) );
		}

		return sprintf(
			'<div class="naix-banner %s" %s>' .
			'%s' .
			'<div class="banner-content">' .
			'<div class="container">' .
			'%s' .
			'</div>' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$style_css,
			$header_output,
			implode( ' ', $output ),
			implode( ' ', $item_banner )
		);

	}

	/**
	 * Image box shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function image_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'    => '',
				'title'    => '',
				'subtitle' => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$output      = array();

		$image_html = '';

		if ( $atts['image'] ) {
			$image_html = wp_get_attachment_image( $atts['image'], 'full' );
		}

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<div class="subtitle">%s</div>', $atts['subtitle'] );
		}

		return sprintf(
			'<div class="naix-image-box %s">' .
			'<div class="image">' .
			'%s' .
			'</div>' .
			'<div class="image-content">' .
			'%s' .
			'</div>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$image_html,
			implode( '', $output )
		);
	}

	/**
	 * Images shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function images_grid( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'images'              => '',
				'custom_links'        => '',
				'columns'             => '4',
				'custom_links_target' => '_self',
				'opacity'             => '',
				'el_class'            => '',
			), $atts
		);

		$columns = intval( $atts['columns'] );

		$css_class[] = $atts['el_class'];
		$css_class[] = 'columns-' . $columns;

		if ( $atts['opacity'] ) {
			$css_class[] = 'has-opacity';
		}

		$custom_links = '';
		if ( function_exists( 'vc_value_from_safe' ) ) {
			$custom_links = vc_value_from_safe( $atts['custom_links'] );
			$custom_links = explode( ',', $custom_links );
		}

		$output = array();
		$images = $atts['images'] ? explode( ',', $atts['images'] ) : '';

		$i = 0;

		foreach ( $images as $attachment_id ) {

			$image = wp_get_attachment_image( $attachment_id, 'full' );

			if ( $image ) {

				if ( $i % $columns == 0 ) {
					$output[] = '<div class="images-list">';
				}

				$link = '';
				if ( $custom_links && isset( $custom_links[ $i ] ) ) {
					$link = preg_replace( '/<br \/>/iU', '', $custom_links[ $i ] );

					if ( $link ) {
						$link = 'href="' . esc_url( $link ) . '"';
					}

				}
				$output[] = sprintf(
					'<div class="image-item"><a %s target="%s">%s</a></div>',
					$link,
					esc_attr( $atts['custom_links_target'] ),
					$image
				);

				if ( $i % $columns == $columns - 1 ) {
					$output[] = '</div>';
				}


			}
			$i ++;
		}


		return sprintf(
			'<div class="naix-image-grid %s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Get Vertical Scroll Slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function vsslider1( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'    => '',
				'el_class' => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];
		$output      = array();

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		foreach ( $items as $item ) {

			$bg_image = '';
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image    = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$bg_image = $image ? sprintf( '<div class="featured-img" style="background-image: url(%s)"></div>', esc_url( $image[0] ) ) : '';
			}

			$item_html = '';
			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$item_html = sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			$title_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$title_html = $item['title'];
			}

			if ( isset( $item['link'] ) && $item['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['link'] ) );
					if ( ! empty( $link ) ) {
						$title_html = sprintf(
							'<a href="%s" class="link" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$title_html
						);
					}
				}
			}

			$item_html .= sprintf( '<h2 class="title">%s</h2>', $title_html );

			if ( $item_html ) {
				$item_html = sprintf( '<div class="slider-content">%s</div>', $item_html );
			}

			$item_class = '';
			if ( isset( $item['text_position'] ) && $item['text_position'] ) {
				$item_class = 'position-' . $item['text_position'];
			}

			$output[] = sprintf(
				'<div class="slider-section">' .
				'<div class="slider-item %s">' .
				'%s' .
				'<div class="container">' .
				'<div class="row">' .
				'<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 col-left">' .
				'%s' .
				'</div>' .
				'<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 col-right">' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</div>',
				esc_attr( $item_class ),
				$bg_image,
				$item_html
			);
		}


		return sprintf(
			'<div class="naix-vs-slider1 %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get Vertical Slider Effect
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function vsslider2( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'       => '',
				'autoplay'    => '0',
				'button_link' => '',
				'no_keyboard' => '',
				'no_mouse'    => '',
				'bg_color'    => '',
				'text_color'  => '',
				'el_class'    => '',
			), $atts
		);

		$autoplay = intval( $atts['autoplay'] );

		$css_class[] = $atts['el_class'];
		if ( $atts['text_color'] ) {
			$css_class[] = 'text-color-' . $atts['text_color'];
		}
		$output = array();

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		foreach ( $items as $item ) {

			$item_output = array();
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image         = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$item_output[] = $image ? sprintf( '<div class="featured-img"  style="background-image: url(%s)"></div>', esc_url( $image[0] ) ) : '';
			}

			$title_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$title_html .= sprintf( '<h2>%s</h2>', $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$title_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			$item_html = '';
			if ( isset( $item['item_link'] ) && $item['item_link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['item_link'] ) );
					if ( ! empty( $link ) ) {
						$item_html = sprintf(
							'<a href="%s" class="title" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$title_html
						);
					}
				}
			}

			if ( empty( $item_html ) ) {
				$item_html = $title_html;
			}


			if ( $item_html ) {
				$item_output[] = sprintf( '<div class="slider-content"><div class="container">%s</div></div>', $item_html );
			}

			$output[] = sprintf(
				'<div class="slider-section swiper-slide" data-swiper-autoplay="%s">' .
				'<div class="slider-item">' .
				'%s' .
				'</div>' .

				'</div>',
				esc_attr( $autoplay ),
				implode( ' ', $item_output )
			);
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$keyboard = 1;
		if ( $atts['no_keyboard'] ) {
			$keyboard = 0;
		}

		$mouse = 1;
		if ( $atts['no_mouse'] ) {
			$mouse = 0;
		}

		$id                                 = uniqid( 'naxi-veslider-' );
		$this->l10n['naixvsSlider2'][ $id ] = array(
			'autoplay' => $auto,
			'keyboard' => $keyboard,
			'mouse'    => $mouse,
		);

		$button_link = '';
		if ( isset( $atts['button_link'] ) && $atts['button_link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['button_link'] ) );
				if ( ! empty( $link ) ) {
					$button_link = sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						isset( $link['url'] ) ? esc_url( $link['url'] ) : '',
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		$bg_style = '';
		if ( $atts['bg_color'] ) {
			$bg_style = 'style="background-color:' . $atts['bg_color'] . '"';
		}

		return sprintf(
			'<div class="naix-vs-slider2 swiper-container %s" id="%s" %s>' .
			'<div class="veslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="custom-arrow">' .
			'<div class="container">' .
			'<div class="slick-prev slick-arrow"><span class="icon-chevron-left slick-prev-arrow"></span></div>' .
			'<div class="slick-next slick-arrow"><span class="icon-chevron-right slick-next-arrow"></span></div>' .
			'%s' .
			'</div>' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $id ),
			$bg_style,
			implode( ' ', $output ),
			$button_link

		);

	}

	/**
	 * Get Vertical Slider 3
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function vsslider3( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'         => '',
				'link'          => '',
				'autoplay'      => 0,
				'no_keyboard'   => '',
				'no_mouse'      => '',
				'slider_repeat' => 1,
				'el_class'      => '',
			), $atts
		);

		$autoplay    = intval( $atts['autoplay'] );
		$css_class[] = $atts['el_class'];
		$output      = array();

		$items = (array) json_decode( urldecode( $atts['items'] ), true );
		foreach ( $items as $item ) {

			$bg_image = '';
			if ( isset( $item['image'] ) && $item['image'] ) {
				$image = wp_get_attachment_image_src( $item['image'], 'full' );
				if ( $image ) {
					$link_image = '';
					if ( isset( $item['link'] ) && $item['link'] ) {
						if ( function_exists( 'vc_build_link' ) ) {
							$link = array_filter( vc_build_link( $item['link'] ) );
							if ( ! empty( $link ) ) {
								$link_image = sprintf(
									'<a href="%s" class="link" %s%s>
									</a>',
									esc_url( $link['url'] ),
									! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
									! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
									'-50%'
								);
							}
						}
					}

					if ( empty( $bg_image ) ) {
						$bg_image = sprintf( '<div class="featured-img parallax-bg" >%s<img alt="" data-swiper-parallax="%s" src="%s"></div>', $link_image, '-50%', esc_url( $image[0] ) );
					}
				}

			}


			$item_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$item_html .= sprintf( '<h2 class="title">%s</h2>', $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$item_html .= sprintf( '<span class="subtitle">%s</span>', $item['subtitle'] );
			}

			if ( isset( $item['desc'] ) && $item['desc'] ) {
				$item_html .= sprintf( '<div data-swiper-parallax="%s" class="desc">%s</div>', '-300', $item['desc'] );
			}


			if ( isset( $item['link'] ) && $item['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['link'] ) );
					if ( ! empty( $link ) ) {
						$item_html .= sprintf(
							'<a href="%s" data-swiper-parallax="%s" class="link" %s%s>%s</a>',
							esc_url( $link['url'] ),
							'-300',
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$link['title']
						);
					}
				}
			}

			$output[] = sprintf(
				'<div class="slider-item swiper-slide" data-swiper-autoplay="%s">' .
				'<div class="container">' .
				'<div class="item-content">' .
				'%s' .
				'<div class="slider-content">' .
				'%s' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</div>',
				esc_attr( $autoplay ),
				$bg_image,
				$item_html
			);
		}

		$button_link = '';
		if ( isset( $atts['link'] ) && $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$button_link = sprintf(
						'<a href="%s" class="button-link" %s%s>%s</a>',
						isset( $link['url'] ) ? esc_url( $link['url'] ) : '',
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$keyboard = 1;
		if ( $atts['no_keyboard'] ) {
			$keyboard = 0;
		}

		$mouse = 1;
		if ( $atts['no_mouse'] ) {
			$mouse = 0;
		}

		$repeat = 1;
		if ( $atts['slider_repeat'] ) {
			$repeat = 0;
		}

		$id                                 = uniqid( 'naxi-vsslider3-' );
		$this->l10n['naixVsslider3'][ $id ] = array(
			'autoplay' => $auto,
			'keyboard' => $keyboard,
			'mouse'    => $mouse,
			'repeat'   => $repeat,
		);


		return sprintf(
			'<div class="naix-vs-slider3 swiper-container %s" id="%s">' .
			'<div class="hsslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="naix-buttons">' .
			'<div class="naix-button-prev naix-button-white"><i class="icon-arrow-up"></i></div>' .
			'<div class="naix-button-next naix-button-white"><i class="icon-arrow-down"></i></div>' .
			'</div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $id ),
			implode( ' ', $output ),
			$button_link

		);

	}

	/**
	 * Get Horizontal Swipe Slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function hsslider1( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'items'       => '',
				'link'        => '',
				'no_keyboard' => '',
				'no_mouse'    => '',
				'autoplay'    => 0,
				'el_class'    => '',
			), $atts
		);

		$autoplay    = intval( $atts['autoplay'] );
		$css_class[] = $atts['el_class'];
		$output      = array();

		$items = (array) json_decode( urldecode( $atts['items'] ), true );

		foreach ( $items as $item ) {

			$bg_image = '';
			if ( isset( $item['bg_image'] ) && $item['bg_image'] ) {
				$image    = wp_get_attachment_image_src( $item['bg_image'], 'full' );
				$bg_image = $image ? sprintf( '<div class="featured-img parallax-bg"  style="background-image: url(%s)"></div>', esc_url( $image[0] ) ) : '';
			}

			$parallax = '-300';

			$item_html = '';
			if ( isset( $item['title'] ) && $item['title'] ) {
				$item_html .= sprintf( '<h2 data-swiper-parallax="%s" class="title">%s</h2>', esc_attr( $parallax ), $item['title'] );
			}

			if ( isset( $item['subtitle'] ) && $item['subtitle'] ) {
				$item_html .= sprintf( '<span data-swiper-parallax="%s" class="subtitle">%s</span>', esc_attr( $parallax ), $item['subtitle'] );
			}

			if ( isset( $item['desc'] ) && $item['desc'] ) {
				$item_html .= sprintf( '<div data-swiper-parallax="%s" class="desc">%s</div>', esc_attr( $parallax ), $item['desc'] );
			}


			if ( isset( $item['link'] ) && $item['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $item['link'] ) );
					if ( ! empty( $link ) ) {
						$item_html .= sprintf(
							'<a href="%s" data-swiper-parallax="%s" class="link" %s%s>%s</a>',
							esc_url( $link['url'] ),
							esc_attr( $parallax ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$link['title']
						);
					}
				}
			}

			$item_class = '';
			if ( isset( $item['text_color'] ) && $item['text_color'] ) {
				$item_class = 'text-color-' . $item['text_color'];
			}

			$output[] = sprintf(
				'<div class="slider-item swiper-slide %s" data-swiper-autoplay="%s">' .
				'%s' .
				'<div class="container">' .
				'<div class="slider-content">' .
				'%s' .
				'</div>' .
				'</div>' .
				'</div>',
				esc_attr( $item_class ),
				esc_attr( $autoplay ),
				$bg_image,
				$item_html
			);
		}

		$button_link = '';
		if ( isset( $atts['link'] ) && $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$button_link = sprintf(
						'<a href="%s" class="button-link" %s%s>%s</a>',
						isset( $link['url'] ) ? esc_url( $link['url'] ) : '',
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		$auto = 0;

		if ( $autoplay ) {
			$auto = 1;
		}

		$keyboard = 1;
		if ( $atts['no_keyboard'] ) {
			$keyboard = 0;
		}

		$mouse = 1;
		if ( $atts['no_mouse'] ) {
			$mouse = 0;
		}

		$id                                = uniqid( 'naxi-hsslider-' );
		$this->l10n['naixHsslider'][ $id ] = array(
			'autoplay' => $auto,
			'keyboard' => $keyboard,
			'mouse'    => $mouse,
		);


		return sprintf(
			'<div class="naix-hs-slider1 swiper-container %s" id="%s">' .
			'<div class="hsslider-list swiper-wrapper">' .
			'%s' .
			'</div>' .
			'<div class="swiper-button-prev swiper-button-white"><i class="icon-arrow-left"></i></div>' .
			'<div class="swiper-button-next swiper-button-white"><i class="icon-arrow-right"></i></div>' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $id ),
			implode( ' ', $output ),
			$button_link

		);

	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function gmap( $atts, $content ) {
		$atts  = shortcode_atts(
			array(
				'api_key' => '',
				'marker'  => '',
				'address' => '',
				'width'   => '',
				'height'  => '450',
				'zoom'    => '13',
				'css'     => '',
			), $atts
		);
		$class = array(
			'naix-map-shortcode',
			$atts['css'],
		);

		if ( empty( $atts['api_key'] ) ) {
			return;
		}

		$style = '';
		if ( $atts['width'] ) {
			$unit = 'px';
			if ( strpos( $atts['width'], '%' ) ) {
				$unit = '%;';
			}

			$atts['width'] = intval( $atts['width'] );
			$style         .= 'width: ' . $atts['width'] . $unit . ';';
		}
		if ( $atts['height'] ) {
			$unit = 'px';
			if ( strpos( $atts['height'], '%' ) ) {
				$unit = '%;';
			}

			$atts['height'] = intval( $atts['height'] );
			$style          .= 'height: ' . $atts['height'] . $unit . ';';
		}
		if ( $atts['zoom'] ) {
			$atts['zoom'] = intval( $atts['zoom'] );
		}

		$id   = uniqid( 'naix_map_' );
		$html = sprintf(
			'<div class="%s"><div id="%s" class="ta-map" style="%s"></div></div>',
			implode( ' ', $class ),
			$id,
			$style
		);

		$coordinates = $this->get_coordinates( $atts['address'], $atts['api_key'] );

		if ( isset( $coordinates['error'] ) ) {
			return $coordinates['error'];
		}
		$marker = '';
		if ( $atts['marker'] ) {
			if ( filter_var( $atts['marker'], FILTER_VALIDATE_URL ) ) {
				$marker = $atts['marker'];
			} else {
				$attachment_image = wp_get_attachment_image_src( intval( $atts['marker'] ), 'full' );
				$marker           = $attachment_image ? $attachment_image[0] : '';
			}
		}

		$this->api_key = $atts['api_key'];

		$this->l10n['map'][ $id ] = array(
			'type'    => 'normal',
			'lat'     => $coordinates['lat'],
			'lng'     => $coordinates['lng'],
			'address' => $atts['address'],
			'zoom'    => $atts['zoom'],
			'marker'  => $marker,
			'height'  => $atts['height'],
			'info'    => $content,
		);

		return $html;
	}

	/**
	 * Shortcode to display contact form
	 *
	 * @param  array $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function contact_form( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'form'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		return sprintf(
			'<div class="naix-contact-form %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			do_shortcode( '[contact-form-7 id="' . esc_attr( $atts['form'] ) . '"]' )
		);
	}

	/**
	 * Image Gallery shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function image_gallery( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'images'      => '',
				'image_size'  => 'full',
				'columns'     => '1',
				'lightbox'    => '',
				'image_align' => 'center',
				'el_class'    => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'text-' . $atts['image_align'];

		$output = array();
		$images = $atts['images'] ? explode( ',', $atts['images'] ) : '';

		$cols = 12 / intval( $atts['columns'] );

		$cols_class = sprintf( 'col-md-%s col-sm-%s  col-xs-12', esc_attr( $cols ), esc_attr( $cols ) );

		$css_item = '';
		if ( $atts['lightbox'] ) {
			$css_item = 'photoswipe';
		}
		foreach ( $images as $attachment_id ) {

			$image_html = '';
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize(
					array(
						'attach_id'  => $attachment_id,
						'thumb_size' => $atts['image_size'],
					)
				);

				if ( $image['thumbnail'] ) {
					$image_html = $image['thumbnail'];
				} elseif ( $image['p_img_large'] ) {
					$image_html = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
				}

			}

			if ( empty( $image_html ) ) {
				$image_html = wp_get_attachment_image( $attachment_id, 'full' );
			}

			$image_full = wp_get_attachment_image_src( $attachment_id, 'full' );

			if ( $image_html ) {
				$output[] = sprintf(
					'<div class="%s"><a class="image-item %s" href="%s" data-width="%s" data-height="%s">%s</a></div>',
					esc_attr( $cols_class ),
					esc_attr( $css_item ),
					esc_url( $image_full[0] ),
					esc_attr( $image_full[1] ),
					esc_attr( $image_full[2] ),
					$image_html
				);
			}
		}


		return sprintf(
			'<div class="naix-image-gallery %s"><div class="images-list"><div class="row">%s</div></div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	// Get template part

	/**
	 * Helper function to get coordinates for map
	 *
	 * @since 1.0.0
	 *
	 * @param string $address
	 * @param bool $refresh
	 *
	 * @return array
	 */
	function get_coordinates( $address, $api_key, $refresh = false ) {
		$address_hash = md5( $address );
		$coordinates  = get_transient( $address_hash );
		$results      = array( 'lat' => '', 'lng' => '' );

		if ( $refresh || $coordinates === false ) {
			$args     = array( 'address' => urlencode( $address ), 'sensor' => 'false', 'key' => $api_key );
			$url      = add_query_arg( $args, 'https://maps.googleapis.com/maps/api/geocode/json' );
			$response = wp_remote_get( $url );

			if ( is_wp_error( $response ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'naix-addons' );

				return $results;
			}

			$data = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $data ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'naix-addons' );

				return $results;
			}

			if ( $response['response']['code'] == 200 ) {
				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {
					$coordinates = $data->results[0]->geometry->location;

					$results['lat']     = $coordinates->lat;
					$results['lng']     = $coordinates->lng;
					$results['address'] = (string) $data->results[0]->formatted_address;

					// cache coordinates for 3 months
					set_transient( $address_hash, $results, 3600 * 24 * 30 * 3 );
				} elseif ( $data->status === 'ZERO_RESULTS' ) {
					$results['error'] = esc_html__( 'No location found for the entered address.', 'naix-addons' );
				} elseif ( $data->status === 'INVALID_REQUEST' ) {
					$results['error'] = esc_html__( 'Invalid request. Did you enter an address?', 'naix-addons' );
				} else {
					$results['error'] = esc_html__( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'naix-addons' );
				}
			} else {
				$results['error'] = esc_html__( 'Unable to contact Google API service.', 'naix-addons' );
			}
		} else {
			$results = $coordinates; // return cached results
		}

		return $results;
	}

}
