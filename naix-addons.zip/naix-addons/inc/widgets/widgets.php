<?php
/**
 * Load and register widgets
 *
 * @package Naix
 */


require_once NAIX_ADDONS_DIR . '/inc/widgets/language.php';
require_once NAIX_ADDONS_DIR . '/inc/widgets/social-media-links.php';

if ( ! function_exists( 'naix_register_widgets' ) ) {
	/**
	 * Register widgets
	 *
	 * @since  1.0
	 *
	 * @return void
	 */
	function naix_register_widgets() {
		register_widget( 'Naix_Language_Widget' );
		register_widget( 'Naix_Social_Links_Widget' );

	}

	add_action( 'widgets_init', 'naix_register_widgets' );
}