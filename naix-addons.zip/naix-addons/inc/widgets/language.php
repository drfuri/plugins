<?php
/**
 * Widget API: WP_Widget_Text class
 *
 * @package    WordPress
 * @subpackage Widgets
 * @since      4.4.0
 */


if ( ! class_exists( 'Naix_Language_Widget' ) ) {

	/**
	 * Core class used to implement a Text widget.
	 *
	 * @since 2.8.0
	 *
	 * @see   WP_Widget
	 */
	class Naix_Language_Widget extends WP_Widget {

		/**
		 * Sets up a new Text widget instance.
		 *
		 * @since  2.8.0
		 * @access public
		 */
		public function __construct() {
			$this->defaults = array(
				'title' => ''
			);
			$widget_ops     = array(
				'classname'   => 'widget_text naix-language',
				'description' => esc_html__( 'Shows language list by WPML plugin', 'naix' ),
			);
			$control_ops    = array( 'width' => 400, 'height' => 350 );
			parent::__construct( 'naix-language', esc_html__( 'Naix Language', 'naix' ), $widget_ops, $control_ops );
		}

		/**
		 * Outputs the content for the current Text widget instance.
		 *
		 * @since  2.8.0
		 * @access public
		 *
		 * @param array $args Display arguments including 'before_title', 'after_title',
		 *                        'before_widget', and 'after_widget'.
		 * @param array $instance Settings for the current Text widget instance.
		 */
		public function widget( $args, $instance ) {

			$instance = wp_parse_args( $instance, $this->defaults );
			extract( $args );

			echo $args['before_widget'];
			if ( $title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) ) {
				echo $before_title . esc_html( $title ) . $after_title;
			}

			?>
            <div class="widget-language">
				<?php
				if( function_exists('naix_language_switcher')) {
					echo apply_filters( 'naix_language_switcher_widget', naix_language_switcher( true ) );
				}
				?>
            </div>
			<?php
			echo $args['after_widget'];
		}


		/**
		 * Display widget settings
		 *
		 * @param array $instance Widget settings
		 *
		 * @return void
		 */
		function form( $instance ) {
			$instance = wp_parse_args( $instance, $this->defaults );
			?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'naix' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                       name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                       value="<?php echo esc_attr( $instance['title'] ); ?>">
            </p>

			<?php
		}
	}
}