<?php
/**
 * Hooks for share socials
 *
 * @package Naix
 */


/**
 * Add more options
 *
 */
function naix_addons_add_socials( $fields ) {

	// FOr Post
	$fields['post_share_box']    = array(
		'type'        => 'toggle',
		'label'       => esc_html__( 'Show Sharing Socials', 'naix-addons' ),
		'section'     => 'single_post',
		'default'     => 1,
		'description' => esc_html__( 'Display social sharing icons on single post', 'naix-addons' ),
		'priority'    => 20,
	);
	$fields['post_social_icons'] = array(
		'type'            => 'multicheck',
		'label'           => esc_html__( 'Social Icons', 'naix-addons' ),
		'section'         => 'single_post',
		'default'         => array( 'facebook', 'twitter', 'pinterest', 'google', 'linkedin', 'vkontakte' ),
		'priority'        => 60,
		'choices'         => array(
			'twitter'   => esc_html__( 'Twitter', 'naix-addons' ),
			'facebook'  => esc_html__( 'Facebook', 'naix-addons' ),
			'google'    => esc_html__( 'Google Plus', 'naix-addons' ),
			'pinterest' => esc_html__( 'Pinterest', 'naix-addons' ),
			'linkedin'  => esc_html__( 'Linkedin', 'naix-addons' ),
			'vkontakte' => esc_html__( 'Vkontakte', 'naix-addons' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'post_share_box',
				'operator' => '==',
				'value'    => 1,
			),
		),
	);

	// For Portfolio
	$fields['single_portfolio_share_box'] = array(
		'type'        => 'toggle',
		'label'       => esc_html__( 'Show Sharing Socials', 'naix-addons' ),
		'section'     => 'single_portfolio',
		'default'     => 1,
		'description' => esc_html__( 'Display social sharing icons on the single portfolio', 'naix-addons' ),
		'priority'    => 20,
	);

	$fields['single_portfolio_social_icons'] = array(
		'type'            => 'multicheck',
		'label'           => esc_html__( 'Social Icons', 'naix-addons' ),
		'section'         => 'single_portfolio',
		'default'         => array( 'facebook', 'twitter', 'pinterest', 'google', 'linkedin', 'vkontakte' ),
		'priority'        => 60,
		'choices'         => array(
			'twitter'   => esc_html__( 'Twitter', 'naix-addons' ),
			'facebook'  => esc_html__( 'Facebook', 'naix-addons' ),
			'google'    => esc_html__( 'Google Plus', 'naix-addons' ),
			'pinterest' => esc_html__( 'Pinterest', 'naix-addons' ),
			'linkedin'  => esc_html__( 'Linkedin', 'naix-addons' ),
			'vkontakte' => esc_html__( 'Vkontakte', 'naix-addons' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'single_portfolio_share_box',
				'operator' => '==',
				'value'    => 1,
			),
		),
	);

	// For Product
	$fields['show_product_socials'] = array(
		'type'     => 'toggle',
		'label'    => esc_html__( 'Show Sharing Socials', 'naix-addons' ),
		'section'  => 'single_product',
		'default'  => 1,
		'priority' => 30,
	);

	$fields['product_social_icons'] = array(
		'type'            => 'multicheck',
		'label'           => esc_html__( 'Social Icons', 'naix-addons' ),
		'section'         => 'single_product',
		'default'         => array( 'twitter', 'facebook', 'google', 'pinterest', 'linkedin', 'vkontakte' ),
		'priority'        => 30,
		'choices'         => array(
			'twitter'   => esc_html__( 'Twitter', 'naix-addons' ),
			'facebook'  => esc_html__( 'Facebook', 'naix-addons' ),
			'google'    => esc_html__( 'Google Plus', 'naix-addons' ),
			'pinterest' => esc_html__( 'Pinterest', 'naix-addons' ),
			'linkedin'  => esc_html__( 'Linkedin', 'naix-addons' ),
			'vkontakte' => esc_html__( 'Vkontakte', 'naix-addons' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'show_product_socials',
				'operator' => '==',
				'value'    => 1,
			),
		),
	);

	return $fields;
}

add_action( 'naix_customize_fields', 'naix_addons_add_socials' );

/**
 * Display sharing socials for products
 *
 * @since 1.0
 */
function naix_addons_single_product_socials() {

	if ( ! function_exists( 'naix_get_option' ) ) {
		return;
	}

	if ( ! is_singular( 'product' ) ) {
		return;
	}

	if ( ! intval( naix_get_option( 'show_product_socials' ) ) ) {
		return;
	}

	global $product;
	$image_id   = $product->get_image_id();
	$image_link = '';
	if ( $image_id ) {
		$image_link = wp_get_attachment_url( $image_id );
	}
	naix_addons_share_link_socials( $product->get_title(), $product->get_permalink(), $image_link );

}

add_action( 'woocommerce_single_product_summary', 'naix_addons_single_product_socials', 50 );


/**
 * Get sharing socials for single post
 *
 */

function naix_addons_single_post_socials() {

	if ( ! function_exists( 'naix_get_option' ) ) {
		return;
	}

	if ( ! is_singular( 'post' ) ) {
		return;
	}


	if ( ! intval( naix_get_option( 'post_share_box' ) ) ) {
		return;
	}

	printf( '<div class="footer-socials">' );
	printf( '<strong>%s: </strong>', esc_html__( 'Share', 'naix-addons' ) );

	$image = '';
	if ( function_exists( 'naix_get_image' ) ) {
		$image = naix_get_image(
			array(
				'size'     => 'full',
				'format'   => 'src',
				'meta_key' => 'image',
				'echo'     => false,
			)
		);
	}

	naix_addons_share_link_socials( get_the_title(), get_permalink(), $image );
	printf( '</div>' );

}

add_action( 'single_post_entry_footer', 'naix_addons_single_post_socials' );

/**
 * Add portfolio socials for single porfolio
 *
 * @since  1.0
 *
 *
 */

function naix_addons_single_portfolio_socials() {

	if ( ! function_exists( 'naix_get_option' ) ) {
		return;
	}

	if ( ! is_singular( 'portfolio_project' ) ) {
		return;
	}

	if ( ! intval( naix_get_option( 'single_portfolio_share_box' ) ) ) {
		return;
	}

	printf( '<div class="footer-socials">' );
	printf( '<strong>%s: </strong>', esc_html__( 'Share', 'naix-addons' ) );
	$image = '';
	if ( function_exists( 'naix_get_image' ) ) {
		$image = naix_get_image(
			array(
				'size'     => 'full',
				'format'   => 'src',
				'meta_key' => 'image',
				'echo'     => false,
			)
		);
	}
	naix_addons_share_link_socials( get_the_title(), get_permalink(), $image );
	printf( '</div>' );
}


add_action( 'naix_after_single_portfolio_content', 'naix_addons_single_portfolio_socials', 30 );

/**
 * Share link socials
 *
 * @since  1.0
 */

if ( ! function_exists( 'naix_addons_share_link_socials' ) ) :
	function naix_addons_share_link_socials( $title, $link, $media ) {
		if ( ! function_exists( 'naix_get_option' ) ) {
			return;
		}

		$socials = array();
		if ( is_singular( 'post' ) ) {
			$socials = naix_get_option( 'post_social_icons' );
		} elseif ( is_singular( 'portfolio_project' ) ) {
			$socials = naix_get_option( 'single_portfolio_social_icons' );
		} elseif ( is_singular( 'product' ) ) {
			$socials = naix_get_option( 'product_social_icons' );
		}

		$socials_html = '';
		if ( $socials ) {
			if ( in_array( 'facebook', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-facebook naix-facebook" title="%s" href="http://www.facebook.com/sharer.php?u=%s&t=%s" target="_blank"><i class="social_facebook"></i></a>',
					esc_attr( $title ),
					urlencode( $link ),
					urlencode( $title )
				);
			}

			if ( in_array( 'twitter', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-twitter naix-twitter" href="http://twitter.com/share?text=%s&url=%s" title="%s" target="_blank"><i class="social_twitter"></i></a>',
					esc_attr( $title ),
					urlencode( $link ),
					urlencode( $title )
				);
			}

			if ( in_array( 'pinterest', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-pinterest naix-pinterest" href="http://pinterest.com/pin/create/button?media=%s&url=%s&description=%s" title="%s" target="_blank"><i class="social_pinterest"></i></a>',
					urlencode( $media ),
					urlencode( $link ),
					esc_attr( $title ),
					urlencode( $title )
				);
			}

			if ( in_array( 'google', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-google-plus naix-google-plus" href="https://plus.google.com/share?url=%s&text=%s" title="%s" target="_blank"><i class="social_googleplus"></i></a>',
					urlencode( $link ),
					esc_attr( $title ),
					urlencode( $title )
				);
			}

			if ( in_array( 'linkedin', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-linkedin naix-linkedin" href="http://www.linkedin.com/shareArticle?url=%s&title=%s" title="%s" target="_blank"><i class="social_linkedin"></i></a>',
					urlencode( $link ),
					esc_attr( $title ),
					urlencode( $title )
				);
			}

			if ( in_array( 'vkontakte', $socials ) ) {
				$socials_html .= sprintf(
					'<a class="share-vkontakte naix-vkontakte" href="http://vk.com/share.php?url=%s&title=%s&image=%s" title="%s" target="_blank"><i class="fa fa-vk"></i></a>',
					urlencode( $link ),
					esc_attr( $title ),
					urlencode( $media ),
					urlencode( $title )
				);
			}

		}

		if ( $socials_html ) {
			printf( '<div class="social-links">%s</div>', $socials_html );
		}
		?>
		<?php
	}

endif;
