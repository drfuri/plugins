<?php
/**
 * Custom functions for Visual Composer
 *
 * @package    Naix
 * @subpackage Visual Composer
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/**
 * Class fos_VC
 *
 * @since 1.0.0
 */
class Naix_VC {

	/**
	 * Construction
	 */
	function __construct() {
		// Stop if VC is not installed
		if ( ! is_plugin_active( 'js_composer/js_composer.php' ) ) {
			return false;
		}

		add_action( 'init', array( $this, 'map_shortcodes' ), 20 );

		add_filter( 'vc_autocomplete_naix_portfolios_list_filter_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_list_filter_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_masonry_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_masonry_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_free_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_free_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_grid_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_grid_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_grid_gap_ids_callback', array( $this, 'portfolioIdsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_grid_gap_ids_render', array( $this, 'portfolioIdsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_list_filter_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_list_filter_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_masonry_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_masonry_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_free_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_free_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_grid_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_grid_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_portfolios_grid_gap_cats_callback', array( $this, 'portfolioCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_portfolios_grid_gap_cats_render', array( $this, 'portfolioCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_autocomplete_naix_posts_grid_cats_callback', array( $this, 'postCatsAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_naix_posts_grid_cats_render', array( $this, 'postCatsAutocompleteRender', ), 10, 1 );

		add_filter( 'vc_iconpicker-type-ionicons', array( $this, 'vc_iconpicker_type_ionicons' ) );

		add_action( 'vc_base_register_front_css', array( $this, 'vc_iconpicker_base_register_css' ) );
		add_action( 'vc_base_register_admin_css', array( $this, 'vc_iconpicker_base_register_css' ) );

		add_action( 'vc_enqueue_font_icon_element', array( $this, 'vc_icon_element_fonts_enqueue' ) );


	}


	/**
	 * Add new params or add new shortcode to VC
	 *
	 * @since 1.0
	 *
	 * @return void
	 */
	function map_shortcodes() {

		$attributes = array(
			array(
				'type'       => 'textfield',
				'heading'    => esc_html__( 'Letter Spacing', 'naix' ),
				'param_name' => 'letter_spacing',
				'group'      => esc_html__( 'Extra', 'naix' ),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Font Style', 'naix' ),
				'param_name' => 'font_style',
				'group'      => esc_html__( 'Extra', 'naix' ),
				'value'      => array(
					esc_html__( 'Default', 'naix' )  => '',
					esc_html__( 'Regular', 'naix' )  => '400',
					esc_html__( 'Light', 'naix' )    => '300',
					esc_html__( 'Medium', 'naix' )   => '500',
					esc_html__( 'SemiBold', 'naix' ) => '600',
					esc_html__( 'Bold', 'naix' )     => '700'
				),
				'dependency' => array(
					'element' => 'use_theme_fonts',
					'value'   => 'yes',
				),
			),
		);
		vc_add_params( 'vc_custom_heading', $attributes );

		// About

		vc_map(
			array(
				'name'     => esc_html__( 'About', 'naix' ),
				'base'     => 'naix_about',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'naix' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Name', 'naix' ),
						'param_name' => 'name',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Job', 'naix' ),
						'param_name' => 'job',
						'value'      => '',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Description', 'naix' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Socials Text', 'naix' ),
						'param_name' => 'socials_text',
						'value'      => '',
					),
					array(
						'heading'    => esc_html__( 'Texts', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'source_texts',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Section text
		vc_map(
			array(
				'name'     => esc_html__( 'Section Text Effect', 'naix' ),
				'base'     => 'naix_section_text_effect',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Content', 'naix' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'heading'    => esc_html__( 'Texts Source', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'source_texts',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'admin_label' => true,
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Color', 'naix' ),
								'param_name' => 'color',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Section title
		vc_map(
			array(
				'name'     => esc_html__( 'Section Title', 'naix' ),
				'base'     => 'naix_section_title',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
							esc_html__( 'Style 3', 'naix' ) => '3'
						),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1', '2' ),
						),
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Content', 'naix' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'naix' ),
						'param_name' => 'text_align',
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Left', 'naix' )   => 'left'
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'naix' ),
						'param_name' => 'link',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1', '2' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio List
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios List', 'naix' ),
				'base'     => 'naix_portfolios_list',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2'
						),
					),
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'naix' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'naix' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'naix' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link(URL)', 'naix' ),
								'param_name' => 'link',
							),
							array(
								'type'        => 'dropdown',
								'heading'     => esc_html__( 'Text Color', 'naix' ),
								'param_name'  => 'text_color',
								'value'       => array(
									esc_html__( 'Dark', 'naix' )  => 'dark',
									esc_html__( 'Light', 'naix' ) => 'light',
								),
								'description' => esc_html__( 'Choose text color when hover item. This option is only used for style 1', 'naix' ),
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio List Filter
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios List Tabs', 'naix' ),
				'base'     => 'naix_portfolios_list_filter',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'SubTitle', 'naix' ),
						'param_name' => 'subtitle',
						'value'      => '',
					),

					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'naix' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'naix' ) => 'default',
							esc_html__( 'Custom', 'naix' )  => 'custom',
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Categories Filter', 'naix' ),
						'param_name'  => 'cats_filters',
						'value'       => array( esc_html__( 'Disable', 'naix' ) => '0' ),
						'description' => esc_html__( 'Check this option to disable categories filter.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'default' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'default' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '5',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'default' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'default' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'default' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'naix' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( 'custom' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios Grid', 'naix' ),
				'base'     => 'naix_portfolios_grid',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
							esc_html__( 'Style 3', 'naix' ) => '3'
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Hover Style', 'naix' ),
						'param_name'  => 'hover_style',
						'value'       => array(
							esc_html__( 'Style 1', 'naix' )      => '1',
							esc_html__( 'Style 2', 'naix' )      => '2',
							esc_html__( 'Style 3', 'naix' )      => '3',
							esc_html__( 'Style 4', 'naix' )      => '4',
							esc_html__( 'Custom Style', 'naix' ) => 'custom'
						),
						'description' => esc_html__( 'Go to portfolio detail to choose background color for custom style.', 'naix' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '2', '3' ),
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'naix' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '2 Columns', 'naix' ) => '2',
							esc_html__( '3 Columns', 'naix' ) => '3',
							esc_html__( '4 Columns', 'naix' ) => '4'
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'naix' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'naix' ) => '1',
							esc_html__( 'Custom', 'naix' )  => '2',
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Categories Filter', 'naix' ),
						'param_name'  => 'cats_filter',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'value'       => array( esc_html__( 'Yes', 'naix' ) => 'true' ),
						'description' => esc_html__( 'Catgories Filter will be get from portfolios.', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Categories Filter Number', 'naix' ),
						'param_name'  => 'cats_filter_number',
						'value'       => '4',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'description' => esc_html__( 'Enter Catgories number you want to show.', 'naix' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'naix' ),
						'param_name' => 'cats_text_align',
						'group'      => esc_html__( 'Categories Filter', 'naix' ),
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Right', 'naix' )  => 'right',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '7',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'naix' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button', 'naix' ),
						'param_name' => 'button',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Featured Portfolio', 'naix' ),
				'base'     => 'naix_featured_portfolio',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Category', 'naix' ),
						'param_name' => 'cat',
					),
					array(
						'type'       => 'colorpicker',
						'heading'    => esc_html__( 'Category Color', 'naix' ),
						'param_name' => 'cat_color',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'naix' ),
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);


		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios Free Style', 'naix' ),
				'base'     => 'naix_portfolios_free',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Hover Style', 'naix' ),
						'param_name'  => 'hover_style',
						'value'       => array(
							esc_html__( 'Style 1', 'naix' )      => '1',
							esc_html__( 'Style 2', 'naix' )      => '2',
							esc_html__( 'Style 3', 'naix' )      => '3',
							esc_html__( 'Style 4', 'naix' )      => '4',
							esc_html__( 'Custom Style', 'naix' ) => 'custom'
						),
						'description' => esc_html__( 'Go to portfolio detail to choose background color for custom style.', 'naix' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1', '2' ),
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'naix' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'naix' ) => '1',
							esc_html__( 'Custom', 'naix' )  => '2',
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Categories Filter', 'naix' ),
						'param_name'  => 'cats_filter',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'value'       => array( esc_html__( 'Yes', 'naix' ) => 'true' ),
						'description' => esc_html__( 'Catgories Filter will be get from portfolios.', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Categories Filter Number', 'naix' ),
						'param_name'  => 'cats_filter_number',
						'value'       => '4',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'description' => esc_html__( 'Enter Catgories number you want to show.', 'naix' )
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '7',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'naix' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button', 'naix' ),
						'param_name' => 'button',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios Grid Gap', 'naix' ),
				'base'     => 'naix_portfolios_grid_gap',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'naix' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'naix' ) => '1',
							esc_html__( 'Custom', 'naix' )  => '2',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '9',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'naix' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button', 'naix' ),
						'param_name' => 'button',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Portfolio Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Portfolios Masonry', 'naix' ),
				'base'     => 'naix_portfolios_masonry',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
							esc_html__( 'Style 3', 'naix' ) => '3',
							esc_html__( 'Style 4', 'naix' ) => '4',
							esc_html__( 'Style 5', 'naix' ) => '5'
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Hover Style', 'naix' ),
						'param_name'  => 'hover_style',
						'value'       => array(
							esc_html__( 'Style 1', 'naix' )      => '1',
							esc_html__( 'Style 2', 'naix' )      => '2',
							esc_html__( 'Style 3', 'naix' )      => '3',
							esc_html__( 'Style 4', 'naix' )      => '4',
							esc_html__( 'Custom Style', 'naix' ) => 'custom'
						),
						'description' => esc_html__( 'Go to portfolio detail to choose background color for custom style.', 'naix' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1', '2', '3', '5' ),
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Portfolios Source', 'naix' ),
						'param_name' => 'source',
						'value'      => array(
							esc_html__( 'Default', 'naix' ) => '1',
							esc_html__( 'Custom', 'naix' )  => '2',
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Categories Filter', 'naix' ),
						'param_name'  => 'cats_filter',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'value'       => array( esc_html__( 'Yes', 'naix' ) => 'true' ),
						'description' => esc_html__( 'Catgories Filter will be get from portfolios.', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Categories Filter Number', 'naix' ),
						'param_name'  => 'cats_filter_number',
						'value'       => '4',
						'group'       => esc_html__( 'Categories Filter', 'naix' ),
						'description' => esc_html__( 'Enter Catgories number you want to show.', 'naix' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'naix' ),
						'param_name' => 'cats_text_align',
						'group'      => esc_html__( 'Categories Filter', 'naix' ),
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Right', 'naix' )  => 'right',
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolio Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter portfolio categories', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Portfolios per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '7',
						'description' => esc_html__( 'Set numbers of portfolios you want to display at the same time.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order portfolios. Leave empty to use the default order by of theme.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort portfolios. Leave empty to use the default sort of theme', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Portfolios', 'naix' ),
						'param_name'  => 'ids',
						'settings'    => array(
							'multiple'      => true,
							'sortable'      => true,
							'unique_values' => true,
						),
						'value'       => '',
						'description' => esc_html__( 'Enter List of Portfolios.', 'naix' ),
						'dependency'  => array(
							'element' => 'source',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button', 'naix' ),
						'param_name' => 'button',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Banner
		vc_map(
			array(
				'name'     => esc_html__( 'Banner', 'naix' ),
				'base'     => 'naix_banner',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
							esc_html__( 'Style 3', 'naix' ) => '3',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Background Type', 'naix' ),
						'param_name' => 'background',
						'value'      => array(
							esc_html__( 'Image', 'naix' ) => 'image',
							esc_html__( 'Video', 'naix' ) => 'video',
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Background Image', 'naix' ),
						'param_name'  => 'bg_image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
						'dependency'  => array(
							'element' => 'background',
							'value'   => array( 'image' ),
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Poster Image', 'naix' ),
						'param_name'  => 'poster',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
						'dependency'  => array(
							'element' => 'background',
							'value'   => array( 'video' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video file URL', 'naix' ),
						'description' => esc_html__( 'Only allow mp4, webm, ogv files', 'naix' ),
						'param_name'  => 'video',
						'value'       => '',
						'dependency'  => array(
							'element' => 'background',
							'value'   => array( 'video' ),
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Mute', 'naix' ),
						'param_name'  => 'mute',
						'value'       => array( esc_html__( 'Yes', 'naix' ) => 'true' ),
						'description' => esc_html__( 'Mute this video by default', 'naix' ),
						'dependency'  => array(
							'element' => 'background',
							'value'   => array( 'video' ),
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image Content', 'naix' ),
						'param_name'  => 'image_content',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' ),
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'SubTitle', 'naix' ),
						'param_name' => 'subtitle',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '3' ),
						),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2', '3' ),
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Text Left', 'naix' ),
						'param_name' => 'text_left',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '3' ),
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Text Right', 'naix' ),
						'param_name' => 'text_right',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '3' ),
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Items Text', 'naix' ),
						'param_name' => 'items_text',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '3' ),
						),
					),
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '3' ),
						),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Description', 'naix' ),
						'param_name' => 'content',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Button', 'naix' ),
						'param_name' => 'button',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height(px)', 'naix' ),
						'param_name'  => 'height',
						'value'       => '',
						'description' => esc_html__( 'Enter the height of the banner. Leave empty to have the height is 100% the height of the browser window.', 'naix' )
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Parallax', 'naix' ),
						'param_name' => 'parallax',
						'value'      => '',
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Opacity', 'naix' ),
						'param_name'  => 'opacity',
						'value'       => '',
						'description' => esc_html__( 'Check this option to enable opacity when scrolling.', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Clients Text
		vc_map(
			array(
				'name'     => esc_html__( 'Clients Text', 'naix' ),
				'base'     => 'naix_clients_text',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'naix' ),
						'param_name' => 'text_align',
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Left', 'naix' )   => 'left'
						),
					),
					array(
						'heading'    => esc_html__( 'Source Texts', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'source_texts',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Add Images grid shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Images Grid', 'naix' ),
				'base'     => 'naix_images_grid',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Images', 'naix' ),
						'param_name'  => 'images',
						'value'       => '',
						'description' => esc_html__( 'Select images from media library', 'naix' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'naix' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '4 Columns', 'naix' ) => '3',
							esc_html__( '3 Columns', 'naix' ) => '4',
							esc_html__( '5 Columns', 'naix' ) => '5',
							esc_html__( '6 Columns', 'naix' ) => '6',
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Opacity', 'naix' ),
						'param_name' => 'opacity',
						'value'      => '',
					),
					array(
						'type'        => 'exploded_textarea_safe',
						'heading'     => esc_html__( 'Custom links', 'naix' ),
						'param_name'  => 'custom_links',
						'description' => esc_html__( 'Enter links for each slide here. Divide links with linebreaks (Enter).', 'naix' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Custom link target', 'naix' ),
						'param_name'  => 'custom_links_target',
						'value'       => array(
							esc_html__( 'Same window', 'naix' ) => '_self',
							esc_html__( 'New window', 'naix' )  => '_blank',
						),
						'description' => esc_html__( 'Select where to open custom links.', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'naix' ),
					),
				),
			)
		);

		// Add Image Box shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Image Box', 'naix' ),
				'base'     => 'naix_image_box',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Image', 'naix' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'SubTitle', 'naix' ),
						'param_name' => 'subtitle',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'naix' ),
					),
				),
			)
		);

		// Services Text
		vc_map(
			array(
				'name'     => esc_html__( 'Services Text', 'naix' ),
				'base'     => 'naix_services_text',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Texts Source', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'source_texts',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Awards Text
		vc_map(
			array(
				'name'     => esc_html__( 'Awards Text', 'naix' ),
				'base'     => 'naix_awards_text',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Year', 'naix' ),
						'param_name' => 'year',
					),
					array(
						'heading'    => esc_html__( 'Texts Source', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'source_texts',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'SubTitle', 'naix' ),
								'param_name'  => 'subtitle',
								'admin_label' => true,
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Testimonial
		vc_map(
			array(
				'name'     => esc_html__( 'Testimonial', 'naix' ),
				'base'     => 'naix_testimonial',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'naix' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'naix' ) => '1',
							esc_html__( 'Style 2', 'naix' ) => '2',
							esc_html__( 'Style 3', 'naix' ) => '3'
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Name', 'naix' ),
						'param_name' => 'name',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Job', 'naix' ),
						'param_name' => 'job',
						'value'      => '',
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Content', 'naix' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'naix' ),
						'param_name' => 'text_align',
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Left', 'naix' )   => 'left'
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Member
		vc_map(
			array(
				'name'     => esc_html__( 'Member', 'naix' ),
				'base'     => 'naix_member',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'naix' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Name', 'naix' ),
						'param_name' => 'name',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Job', 'naix' ),
						'param_name' => 'job',
						'value'      => '',
					),
					array(
						'heading'    => esc_html__( 'Socials', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials',
						'params'     => array(
							array(
								'type'        => 'iconpicker',
								'value'       => '',
								'heading'     => esc_html__( 'Icon', 'naix' ),
								'param_name'  => 'icon_ionicons',
								'admin_label' => true,
								'settings'    => array(
									'emptyIcon'    => false,
									'type'         => 'ionicons',
									'iconsPerPage' => 200
								),
								'dependency'  => array(
									'element' => 'icon_type',
									'value'   => 'ionicons',
								),
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Vertical Scroll Slider
		vc_map(
			array(
				'name'     => esc_html__( 'Vertical Slider 1', 'naix' ),
				'base'     => 'naix_vsslider1',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'naix' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'naix' ),
							),
							array(
								'type'       => 'dropdown',
								'heading'    => esc_html__( 'Text Position', 'naix' ),
								'param_name' => 'text_position',
								'value'      => array(
									esc_html__( 'Left', 'naix' )  => 'left',
									esc_html__( 'Right', 'naix' ) => 'right',
								),
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'naix' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link(URL)', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Vertical Slider
		vc_map(
			array(
				'name'     => esc_html__( 'Vertical Slider 2', 'naix' ),
				'base'     => 'naix_vsslider2',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'naix' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'naix' ),
							),
							array(
								'type'        => 'textarea',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'naix' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link(URL)', 'naix' ),
								'param_name' => 'item_link',
							),
						)
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Keyboard Control', 'naix' ),
						'param_name' => 'no_keyboard',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Mouse Control', 'naix' ),
						'param_name' => 'no_mouse',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button Link', 'naix' ),
						'param_name' => 'button_link',
					),
					array(
						'type'       => 'colorpicker',
						'value'      => '',
						'heading'    => esc_html__( 'Baackground Color', 'naix' ),
						'param_name' => 'bg_color',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Color', 'naix' ),
						'param_name' => 'text_color',
						'value'      => array(
							esc_html__( 'Light', 'naix' ) => 'light',
							esc_html__( 'Dark', 'naix' )  => 'dark',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'naix' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Vertical Slider 3
		vc_map(
			array(
				'name'     => esc_html__( 'Vertical Slider 3', 'naix' ),
				'base'     => 'naix_vsslider3',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Image', 'naix' ),
								'param_name'  => 'image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'naix' ),
							),
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'naix' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Description', 'naix' ),
								'param_name' => 'desc',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link', 'naix' ),
								'param_name' => 'link',
							),
						)
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Keyboard Control', 'naix' ),
						'param_name' => 'no_keyboard',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Mouse Control', 'naix' ),
						'param_name' => 'no_mouse',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button Link', 'naix' ),
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'naix' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'naix' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Slider Repeat', 'naix' ),
						'param_name' => 'slider_repeat',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Horizontal Swipe Slider
		vc_map(
			array(
				'name'     => esc_html__( 'Horizontal Slider 1', 'naix' ),
				'base'     => 'naix_hsslider1',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'heading'    => esc_html__( 'Items', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'items',
						'params'     => array(
							array(
								'type'        => 'attach_image',
								'heading'     => esc_html__( 'Background Image', 'naix' ),
								'param_name'  => 'bg_image',
								'value'       => '',
								'description' => esc_html__( 'Select an image from media library', 'naix' ),
							),
							array(
								'type'        => 'textfield',
								'value'       => '',
								'heading'     => esc_html__( 'Title', 'naix' ),
								'param_name'  => 'title',
								'admin_label' => true,
							),
							array(
								'type'       => 'textfield',
								'value'      => '',
								'heading'    => esc_html__( 'SubTitle', 'naix' ),
								'param_name' => 'subtitle',
							),
							array(
								'type'       => 'textarea',
								'value'      => '',
								'heading'    => esc_html__( 'Description', 'naix' ),
								'param_name' => 'desc',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Item Link', 'naix' ),
								'param_name' => 'link',
							),
							array(
								'type'       => 'dropdown',
								'heading'    => esc_html__( 'Text Color', 'naix' ),
								'param_name' => 'text_color',
								'value'      => array(
									esc_html__( 'Dark', 'naix' )  => 'dark',
									esc_html__( 'Light', 'naix' ) => 'light',
								),
							),
						)
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Keyboard Control', 'naix' ),
						'param_name' => 'no_keyboard',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Mouse Control', 'naix' ),
						'param_name' => 'no_mouse',
						'value'      => array( esc_html__( 'Disable', 'naix' ) => 'true' ),
					),

					array(
						'type'       => 'vc_link',
						'value'      => '',
						'heading'    => esc_html__( 'Button Link', 'naix' ),
						'param_name' => 'link',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'naix' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Posts Grid
		vc_map(
			array(
				'name'     => esc_html__( 'Posts Grid', 'naix' ),
				'base'     => 'naix_posts_grid',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'autocomplete',
						'heading'     => esc_html__( 'Categories', 'naix' ),
						'param_name'  => 'cats',
						'settings'    => array(
							'multiple' => true,
							'sortable' => true,
						),
						'save_always' => true,
						'description' => esc_html__( 'Enter categories', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Posts per view', 'naix' ),
						'param_name'  => 'per_page',
						'value'       => '3',
						'description' => esc_html__( 'Set numbers of posts you want to display at the same time.', 'naix' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order By', 'naix' ),
						'param_name'  => 'orderby',
						'value'       => array(
							''                                 => '',
							esc_html__( 'Date', 'naix' )       => 'date',
							esc_html__( 'Title', 'naix' )      => 'title',
							esc_html__( 'Menu Order', 'naix' ) => 'menu_order',
							esc_html__( 'Random', 'naix' )     => 'rand',
						),
						'description' => esc_html__( 'Select to order posts. Leave empty to use the default order by of theme.', 'naix' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Order', 'naix' ),
						'param_name'  => 'order',
						'value'       => array(
							''                                  => '',
							esc_html__( 'Ascending ', 'naix' )  => 'asc',
							esc_html__( 'Descending ', 'naix' ) => 'desc',
						),
						'description' => esc_html__( 'Select to sort posts. Leave empty to use the default sort of theme', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Empty Space
		vc_map(
			array(
				'name'     => esc_html__( 'Naix Empty Space', 'naix' ),
				'base'     => 'naix_empty_space',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height(px)', 'naix' ),
						'param_name'  => 'height',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Desktop.', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height on Tablet(px)', 'naix' ),
						'param_name'  => 'height_tablet',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Mobile. Leave empty to use the height of the desktop', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height on Mobile(px)', 'naix' ),
						'param_name'  => 'height_mobile',
						'admin_label' => true,
						'description' => esc_html__( 'Enter empty space height on Mobile. Leave empty to use the height of the tablet', 'naix' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// get form id of mailchimp
		$contact_forms    = get_posts( 'post_type=wpcf7_contact_form&number=-1' );
		$contact_form_ids = array( esc_html__( 'Choose a from', 'naix' ) => 0 );
		foreach ( $contact_forms as $form ) {
			$contact_form_ids[$form->post_title] = $form->ID;
		}

		// Add Contact Form 7 shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Naix Contact Form 7', 'naix' ),
				'base'     => 'naix_contact_form',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Contact Form', 'naix' ),
						'param_name' => 'form',
						'value'      => $contact_form_ids,
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Add contact shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Naix Google Maps', 'naix' ),
				'base'     => 'naix_gmap',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Api Key', 'naix' ),
						'param_name'  => 'api_key',
						'value'       => '',
						'description' => sprintf( __( 'Please go to <a href="%s">Google Maps APIs</a> to get a key', 'naix' ), esc_url( 'https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key' ) ),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Marker', 'naix' ),
						'param_name'  => 'marker',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'naix' ),
					),
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Address', 'naix' ),
						'param_name' => 'address',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Width(px)', 'naix' ),
						'param_name'  => 'width',
						'value'       => '',
						'description' => esc_html__( 'Enter number of the width', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height(px)', 'naix' ),
						'param_name'  => 'height',
						'value'       => '450',
						'description' => esc_html__( 'Enter number of the height', 'naix' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Zoom', 'naix' ),
						'param_name' => 'zoom',
						'value'      => '13',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Content', 'naix' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Socials
		vc_map(
			array(
				'name'     => esc_html__( 'Socials', 'naix' ),
				'base'     => 'naix_socials',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Type', 'naix' ),
						'param_name' => 'type',
						'value'      => array(
							esc_html__( 'Icon ', 'naix' ) => 'icon',
							esc_html__( 'Text ', 'naix' ) => 'text',
						),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'naix' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Icon Size', 'naix' ),
						'param_name' => 'size',
						'value'      => array(
							esc_html__( 'Normal ', 'naix' ) => 'normal',
							esc_html__( 'Small ', 'naix' )  => 'small',
						),
						'dependency' => array(
							'element' => 'type',
							'value'   => 'icon',
						),
					),
					array(
						'heading'    => esc_html__( 'Socials Icon', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials',
						'params'     => array(
							array(
								'type'        => 'iconpicker',
								'value'       => '',
								'heading'     => esc_html__( 'Icon', 'naix' ),
								'param_name'  => 'icon_ionicons',
								'admin_label' => true,
								'settings'    => array(
									'emptyIcon'    => false,
									'type'         => 'ionicons',
									'iconsPerPage' => 200
								),
								'dependency'  => array(
									'element' => 'icon_type',
									'value'   => 'ionicons',
								),
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Color', 'naix' ),
								'param_name' => 'color',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						),
						'dependency' => array(
							'element' => 'type',
							'value'   => 'icon',
						),
					),
					array(
						'heading'    => esc_html__( 'Socials Text', 'naix' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'socials_text',
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => esc_html__( 'Text', 'naix' ),
								'param_name'  => 'text',
								'value'       => '',
								'admin_label' => true,
							),
							array(
								'type'       => 'colorpicker',
								'value'      => '',
								'heading'    => esc_html__( 'Color', 'naix' ),
								'param_name' => 'color',
							),
							array(
								'type'       => 'vc_link',
								'value'      => '',
								'heading'    => esc_html__( 'Link', 'naix' ),
								'param_name' => 'link',
							),
						),
						'dependency' => array(
							'element' => 'type',
							'value'   => 'text',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Add custom single image
		vc_map(
			array(
				'name'     => esc_html__( 'Naix Image Gallery', 'naix' ),
				'base'     => 'naix_image_gallery',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Images', 'naix' ),
						'param_name'  => 'images',
						'value'       => '',
						'description' => esc_html__( 'Select an images from media library', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'naix' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'naix' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Columns', 'naix' ),
						'param_name' => 'columns',
						'value'      => array(
							esc_html__( '1 Column', 'naix' )  => '1',
							esc_html__( '2 Columns', 'naix' ) => '2',
							esc_html__( '3 Columns', 'naix' ) => '3',
							esc_html__( '4 Columns', 'naix' ) => '4',
							esc_html__( '6 Columns', 'naix' ) => '6',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Image alignment', 'naix' ),
						'param_name' => 'image_align',
						'value'      => array(
							esc_html__( 'Center', 'naix' ) => 'center',
							esc_html__( 'Left', 'naix' )   => 'left',
							esc_html__( 'Right', 'naix' )  => 'right',
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'LightBox', 'naix' ),
						'param_name' => 'lightbox',
						'value'      => array( esc_html__( 'Yes', 'naix' ) => 'true' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'naix' ),
					),
				),
			)
		);

		// Add Call to Comming soon shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Countdown', 'naix' ),
				'base'     => 'naix_countdown',
				'class'    => '',
				'category' => esc_html__( 'Naix', 'naix' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Date', 'naix' ),
						'param_name'  => 'date',
						'value'       => '',
						'description' => esc_html__( 'Enter the date by format: YYYY/MM/DD', 'naix' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'naix' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'naix' ),
					),
				),
			)
		);

	}

	/**
	 * Suggester for autocomplete by slug
	 *
	 *
	 * @return array - id's from portfolio with title/slug.
	 */
	public function portfolioIdsAutocompleteSuggester( $query ) {
		$args = array(
			'post_type'              => 'portfolio_project',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			's'                      => $query
		);

		$query   = new WP_Query( $args );
		$results = array();
		while ( $query->have_posts() ) : $query->the_post();
			$data          = array();
			$data['value'] = get_the_ID();
			$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . get_the_ID() . ' - ' . esc_html__( 'Title', 'naix' ) . ': ' . get_the_title();
			$results[]     = $data;

		endwhile;
		wp_reset_postdata();

		return $results;
	}

	/**
	 * Suggester for autocomplete by slug
	 *
	 *
	 * @return array - id's from portfolio cat with title/slug.
	 */
	public function portfolioCatsAutocompleteSuggester( $query ) {
		global $wpdb;
		$cat_id          = (int) $query;
		$query           = trim( $query );
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'portfolio_category' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )", $cat_id > 0 ? $cat_id : - 1, stripslashes( $query ), stripslashes( $query )
			), ARRAY_A
		);

		$result = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . $value['id'] . ' - ' . esc_html__( 'Name', 'naix' ) . ': ' . $value['name'];
				$result[]      = $data;
			}
		}

		return $result;
	}

	/**
	 * Find portfolio cat by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function portfolioCatsAutocompleteRender( $query ) {
		$query = $query['value'];
		$query = trim( $query );
		$term  = get_term_by( 'slug', $query, 'portfolio_category' );

		if ( is_wp_error( $term ) || ! $term ) {
			return false;
		}

		$data          = array();
		$data['value'] = $term->slug;
		$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . $term->term_id . ' - ' . esc_html__( 'Name', 'naix' ) . ': ' . $term->name;


		return $data;
	}

	/**
	 * Suggester for autocomplete by slug
	 *
	 *
	 * @return array - id's from portfolio cat with title/slug.
	 */
	public function postCatsAutocompleteSuggester( $query ) {
		global $wpdb;
		$cat_id          = (int) $query;
		$query           = trim( $query );
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'category' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )", $cat_id > 0 ? $cat_id : - 1, stripslashes( $query ), stripslashes( $query )
			), ARRAY_A
		);

		$result = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . $value['id'] . ' - ' . esc_html__( 'Name', 'naix' ) . ': ' . $value['name'];
				$result[]      = $data;
			}
		}

		return $result;
	}

	/**
	 * Find post cat by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function postCatsAutocompleteRender( $query ) {
		$query = $query['value'];
		$query = trim( $query );
		$term  = get_term_by( 'slug', $query, 'category' );

		if ( is_wp_error( $term ) || ! $term ) {
			return false;
		}

		$data          = array();
		$data['value'] = $term->slug;
		$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . $term->term_id . ' - ' . esc_html__( 'Name', 'naix' ) . ': ' . $term->name;


		return $data;
	}

	/**
	 * Find portfolio by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function portfolioIdsAutocompleteRender(
		$query
	) {
		$query = trim( $query['value'] ); // get value from requested

		if ( empty( $query ) ) {
			return false;
		}

		$args = array(
			'post_type'              => 'portfolio_project',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			'p'                      => intval( $query )
		);

		$query = new WP_Query( $args );
		$data  = array();
		while ( $query->have_posts() ) : $query->the_post();
			$data['value'] = get_the_ID();
			$data['label'] = esc_html__( 'Id', 'naix' ) . ': ' . get_the_ID() . ' - ' . esc_html__( 'Title', 'naix' ) . ': ' . get_the_title();
		endwhile;
		wp_reset_postdata();

		return $data;

	}


	/**
	 * Get categories
	 *
	 * @return array|string
	 */
	function vc_iconpicker_type_ionicons( $icons ) {
		$ionicons = array(
			array( 'ion-alert' => 'alert' ),
			array( 'ion-alert-circled' => 'alert circled' ),
			array( 'ion-android-add' => 'android add' ),
			array( 'ion-android-add-circle' => 'android add circle' ),
			array( 'ion-android-alarm-clock' => 'android alarm clock' ),
			array( 'ion-android-alert' => 'android alert' ),
			array( 'ion-android-apps' => 'android apps' ),
			array( 'ion-android-archive' => 'android archive' ),
			array( 'ion-android-arrow-back' => 'android arrow back' ),
			array( 'ion-android-arrow-down' => 'android arrow down' ),
			array( 'ion-android-arrow-dropdown' => 'android arrow dropdown' ),
			array( 'ion-android-arrow-dropdown-circle' => 'android arrow dropdown circle' ),
			array( 'ion-android-arrow-dropleft' => 'android arrow dropleft' ),
			array( 'ion-android-arrow-dropleft-circle' => 'android arrow dropleft circle' ),
			array( 'ion-android-arrow-dropright' => 'android arrow dropright' ),
			array( 'ion-android-arrow-dropright-circle' => 'android arrow dropright circle' ),
			array( 'ion-android-arrow-dropup' => 'android arrow dropup' ),
			array( 'ion-android-arrow-dropup-circle' => 'android arrow dropup circle' ),
			array( 'ion-android-arrow-forward' => 'android arrow forward' ),
			array( 'ion-android-arrow-up' => 'android arrow up' ),
			array( 'ion-android-attach' => 'android attach' ),
			array( 'ion-android-bar' => 'android bar' ),
			array( 'ion-android-bicycle' => 'android bicycle' ),
			array( 'ion-android-boat' => 'android boat' ),
			array( 'ion-android-bookmark' => 'android bookmark' ),
			array( 'ion-android-bulb' => 'android bulb' ),
			array( 'ion-android-bus' => 'android bus' ),
			array( 'ion-android-calendar' => 'android calendar' ),
			array( 'ion-android-call' => 'android call' ),
			array( 'ion-android-camera' => 'android camera' ),
			array( 'ion-android-cancel' => 'android cancel' ),
			array( 'ion-android-car' => 'android car' ),
			array( 'ion-android-cart' => 'android cart' ),
			array( 'ion-android-chat' => 'android chat' ),
			array( 'ion-android-checkbox' => 'android checkbox' ),
			array( 'ion-android-checkbox-blank' => 'android checkbox blank' ),
			array( 'ion-android-checkbox-outline' => 'android checkbox outline' ),
			array( 'ion-android-checkbox-outline-blank' => 'android checkbox outline blank' ),
			array( 'ion-android-checkmark-circle' => 'android checkmark circle' ),
			array( 'ion-android-clipboard' => 'android clipboard' ),
			array( 'ion-android-close' => 'android close' ),
			array( 'ion-android-cloud' => 'android cloud' ),
			array( 'ion-android-cloud-circle' => 'android cloud circle' ),
			array( 'ion-android-cloud-done' => 'android cloud done' ),
			array( 'ion-android-cloud-outline' => 'android cloud outline' ),
			array( 'ion-android-color-palette' => 'android color palette' ),
			array( 'ion-android-compass' => 'android compass' ),
			array( 'ion-android-contact' => 'android contact' ),
			array( 'ion-android-contacts' => 'android contacts' ),
			array( 'ion-android-contract' => 'android contract' ),
			array( 'ion-android-create' => 'android create' ),
			array( 'ion-android-delete' => 'android delete' ),
			array( 'ion-android-desktop' => 'android desktop' ),
			array( 'ion-android-document' => 'android document' ),
			array( 'ion-android-done' => 'android done' ),
			array( 'ion-android-done-all' => 'android done all' ),
			array( 'ion-android-download' => 'android download' ),
			array( 'ion-android-drafts' => 'android drafts' ),
			array( 'ion-android-exit' => 'android exit' ),
			array( 'ion-android-expand' => 'android expand' ),
			array( 'ion-android-favorite' => 'android favorite' ),
			array( 'ion-android-favorite-outline' => 'android favorite outline' ),
			array( 'ion-android-film' => 'android film' ),
			array( 'ion-android-folder' => 'android folder' ),
			array( 'ion-android-folder-open' => 'android folder open' ),
			array( 'ion-android-funnel' => 'android funnel' ),
			array( 'ion-android-globe' => 'android globe' ),
			array( 'ion-android-hand' => 'android hand' ),
			array( 'ion-android-hangout' => 'android hangout' ),
			array( 'ion-android-happy' => 'android happy' ),
			array( 'ion-android-home' => 'android home' ),
			array( 'ion-android-image' => 'android image' ),
			array( 'ion-android-laptop' => 'android laptop' ),
			array( 'ion-android-list' => 'android list' ),
			array( 'ion-android-locate' => 'android locate' ),
			array( 'ion-android-lock' => 'android lock' ),
			array( 'ion-android-mail' => 'android mail' ),
			array( 'ion-android-map' => 'android map' ),
			array( 'ion-android-menu' => 'android menu' ),
			array( 'ion-android-microphone' => 'android microphone' ),
			array( 'ion-android-microphone-off' => 'android microphone off' ),
			array( 'ion-android-more-horizontal' => 'android more horizontal' ),
			array( 'ion-android-more-vertical' => 'android more vertical' ),
			array( 'ion-android-navigate' => 'android navigate' ),
			array( 'ion-android-notifications' => 'android notifications' ),
			array( 'ion-android-notifications-none' => 'android notifications none' ),
			array( 'ion-android-notifications-off' => 'android notifications off' ),
			array( 'ion-android-open' => 'android open' ),
			array( 'ion-android-options' => 'android options' ),
			array( 'ion-android-people' => 'android people' ),
			array( 'ion-android-person' => 'android person' ),
			array( 'ion-android-person-add' => 'android person add' ),
			array( 'ion-android-phone-landscape' => 'android phone landscape' ),
			array( 'ion-android-phone-portrait' => 'android phone portrait' ),
			array( 'ion-android-pin' => 'android pin' ),
			array( 'ion-android-plane' => 'android plane' ),
			array( 'ion-android-playstore' => 'android playstore' ),
			array( 'ion-android-print' => 'android print' ),
			array( 'ion-android-radio-button-off' => 'android radio button off' ),
			array( 'ion-android-radio-button-on' => 'android radio button on' ),
			array( 'ion-android-refresh' => 'android refresh' ),
			array( 'ion-android-remove' => 'android remove' ),
			array( 'ion-android-remove-circle' => 'android remove circle' ),
			array( 'ion-android-restaurant' => 'android restaurant' ),
			array( 'ion-android-sad' => 'android sad' ),
			array( 'ion-android-search' => 'android search' ),
			array( 'ion-android-send' => 'android send' ),
			array( 'ion-android-settings' => 'android settings' ),
			array( 'ion-android-share' => 'android share' ),
			array( 'ion-android-share-alt' => 'android share alt' ),
			array( 'ion-android-star' => 'android star' ),
			array( 'ion-android-star-half' => 'android star half' ),
			array( 'ion-android-star-outline' => 'android star outline' ),
			array( 'ion-android-stopwatch' => 'android stopwatch' ),
			array( 'ion-android-subway' => 'android subway' ),
			array( 'ion-android-sunny' => 'android sunny' ),
			array( 'ion-android-sync' => 'android sync' ),
			array( 'ion-android-textsms' => 'android textsms' ),
			array( 'ion-android-time' => 'android time' ),
			array( 'ion-android-train' => 'android train' ),
			array( 'ion-android-unlock' => 'android unlock' ),
			array( 'ion-android-upload' => 'android upload' ),
			array( 'ion-android-volume-down' => 'android volume down' ),
			array( 'ion-android-volume-mute' => 'android volume mute' ),
			array( 'ion-android-volume-off' => 'android volume off' ),
			array( 'ion-android-volume-up' => 'android volume up' ),
			array( 'ion-android-walk' => 'android walk' ),
			array( 'ion-android-warning' => 'android warning' ),
			array( 'ion-android-watch' => 'android watch' ),
			array( 'ion-android-wifi' => 'android wifi' ),
			array( 'ion-aperture' => 'aperture' ),
			array( 'ion-archive' => 'archive' ),
			array( 'ion-arrow-down-a' => 'arrow down a' ),
			array( 'ion-arrow-down-b' => 'arrow down b' ),
			array( 'ion-arrow-down-c' => 'arrow down c' ),
			array( 'ion-arrow-expand' => 'arrow expand' ),
			array( 'ion-arrow-graph-down-left' => 'arrow graph down left' ),
			array( 'ion-arrow-graph-down-right' => 'arrow graph down right' ),
			array( 'ion-arrow-graph-up-left' => 'arrow graph up left' ),
			array( 'ion-arrow-graph-up-right' => 'arrow graph up right' ),
			array( 'ion-arrow-left-a' => 'arrow left a' ),
			array( 'ion-arrow-left-b' => 'arrow left b' ),
			array( 'ion-arrow-left-c' => 'arrow left c' ),
			array( 'ion-arrow-move' => 'arrow move' ),
			array( 'ion-arrow-resize' => 'arrow resize' ),
			array( 'ion-arrow-return-left' => 'arrow return left' ),
			array( 'ion-arrow-return-right' => 'arrow return right' ),
			array( 'ion-arrow-right-a' => 'arrow right a' ),
			array( 'ion-arrow-right-b' => 'arrow right b' ),
			array( 'ion-arrow-right-c' => 'arrow right c' ),
			array( 'ion-arrow-shrink' => 'arrow shrink' ),
			array( 'ion-arrow-swap' => 'arrow swap' ),
			array( 'ion-arrow-up-a' => 'arrow up a' ),
			array( 'ion-arrow-up-b' => 'arrow up b' ),
			array( 'ion-arrow-up-c' => 'arrow up c' ),
			array( 'ion-asterisk' => 'asterisk' ),
			array( 'ion-at' => 'at' ),
			array( 'ion-backspace' => 'backspace' ),
			array( 'ion-backspace-outline' => 'backspace outline' ),
			array( 'ion-bag' => 'bag' ),
			array( 'ion-battery-charging' => 'battery charging' ),
			array( 'ion-battery-empty' => 'battery empty' ),
			array( 'ion-battery-full' => 'battery full' ),
			array( 'ion-battery-half' => 'battery half' ),
			array( 'ion-battery-low' => 'battery low' ),
			array( 'ion-beaker' => 'beaker' ),
			array( 'ion-beer' => 'beer' ),
			array( 'ion-bluetooth' => 'bluetooth' ),
			array( 'ion-bonfire' => 'bonfire' ),
			array( 'ion-bookmark' => 'bookmark' ),
			array( 'ion-bowtie' => 'bowtie' ),
			array( 'ion-briefcase' => 'briefcase' ),
			array( 'ion-bug' => 'bug' ),
			array( 'ion-calculator' => 'calculator' ),
			array( 'ion-calendar' => 'calendar' ),
			array( 'ion-camera' => 'camera' ),
			array( 'ion-card' => 'card' ),
			array( 'ion-cash' => 'cash' ),
			array( 'ion-chatbox' => 'chatbox' ),
			array( 'ion-chatbox-working' => 'chatbox working' ),
			array( 'ion-chatboxes' => 'chatboxes' ),
			array( 'ion-chatbubble' => 'chatbubble' ),
			array( 'ion-chatbubble-working' => 'chatbubble working' ),
			array( 'ion-chatbubbles' => 'chatbubbles' ),
			array( 'ion-checkmark' => 'checkmark' ),
			array( 'ion-checkmark-circled' => 'checkmark circled' ),
			array( 'ion-checkmark-round' => 'checkmark round' ),
			array( 'ion-chevron-down' => 'chevron down' ),
			array( 'ion-chevron-left' => 'chevron left' ),
			array( 'ion-chevron-right' => 'chevron right' ),
			array( 'ion-chevron-up' => 'chevron up' ),
			array( 'ion-clipboard' => 'clipboard' ),
			array( 'ion-clock' => 'clock' ),
			array( 'ion-close' => 'close' ),
			array( 'ion-close-circled' => 'close circled' ),
			array( 'ion-close-round' => 'close round' ),
			array( 'ion-closed-captioning' => 'closed captioning' ),
			array( 'ion-cloud' => 'cloud' ),
			array( 'ion-code' => 'code' ),
			array( 'ion-code-download' => 'code download' ),
			array( 'ion-code-working' => 'code working' ),
			array( 'ion-coffee' => 'coffee' ),
			array( 'ion-compass' => 'compass' ),
			array( 'ion-compose' => 'compose' ),
			array( 'ion-connection-bars' => 'connectbars' ),
			array( 'ion-contrast' => 'contrast' ),
			array( 'ion-crop' => 'crop' ),
			array( 'ion-cube' => 'cube' ),
			array( 'ion-disc' => 'disc' ),
			array( 'ion-document' => 'document' ),
			array( 'ion-document-text' => 'document text' ),
			array( 'ion-drag' => 'drag' ),
			array( 'ion-earth' => 'earth' ),
			array( 'ion-easel' => 'easel' ),
			array( 'ion-edit' => 'edit' ),
			array( 'ion-egg' => 'egg' ),
			array( 'ion-eject' => 'eject' ),
			array( 'ion-email' => 'email' ),
			array( 'ion-email-unread' => 'email unread' ),
			array( 'ion-erlenmeyer-flask' => 'erlenmeyer flask' ),
			array( 'ion-erlenmeyer-flask-bubbles' => 'erlenmeyer flask bubbles' ),
			array( 'ion-eye' => 'eye' ),
			array( 'ion-eye-disabled' => 'eye disabled' ),
			array( 'ion-female' => 'female' ),
			array( 'ion-filing' => 'filing' ),
			array( 'ion-film-marker' => 'film marker' ),
			array( 'ion-fireball' => 'fireball' ),
			array( 'ion-flag' => 'flag' ),
			array( 'ion-flame' => 'flame' ),
			array( 'ion-flash' => 'flash' ),
			array( 'ion-flash-off' => 'flash off' ),
			array( 'ion-folder' => 'folder' ),
			array( 'ion-fork' => 'fork' ),
			array( 'ion-fork-repo' => 'fork repo' ),
			array( 'ion-forward' => 'forward' ),
			array( 'ion-funnel' => 'funnel' ),
			array( 'ion-gear-a' => 'gear a' ),
			array( 'ion-gear-b' => 'gear b' ),
			array( 'ion-grid' => 'grid' ),
			array( 'ion-hammer' => 'hammer' ),
			array( 'ion-happy' => 'happy' ),
			array( 'ion-happy-outline' => 'happy outline' ),
			array( 'ion-headphone' => 'headphone' ),
			array( 'ion-heart' => 'heart' ),
			array( 'ion-heart-broken' => 'heart broken' ),
			array( 'ion-help' => 'help' ),
			array( 'ion-help-buoy' => 'help buoy' ),
			array( 'ion-help-circled' => 'help circled' ),
			array( 'ion-home' => 'home' ),
			array( 'ion-icecream' => 'icecream' ),
			array( 'ion-image' => 'image' ),
			array( 'ion-images' => 'images' ),
			array( 'ion-information' => 'information' ),
			array( 'ion-information-circled' => 'informatcircled' ),
			array( 'ion-ionic' => 'ionic' ),
			array( 'ion-ios-alarm' => 'ios alarm' ),
			array( 'ion-ios-alarm-outline' => 'ios alarm outline' ),
			array( 'ion-ios-albums' => 'ios albums' ),
			array( 'ion-ios-albums-outline' => 'ios albums outline' ),
			array( 'ion-ios-americanfootball' => 'ios americanfootball' ),
			array( 'ion-ios-americanfootball-outline' => 'ios americanfootball outline' ),
			array( 'ion-ios-analytics' => 'ios analytics' ),
			array( 'ion-ios-analytics-outline' => 'ios analytics outline' ),
			array( 'ion-ios-arrow-back' => 'ios arrow back' ),
			array( 'ion-ios-arrow-down' => 'ios arrow down' ),
			array( 'ion-ios-arrow-forward' => 'ios arrow forward' ),
			array( 'ion-ios-arrow-left' => 'ios arrow left' ),
			array( 'ion-ios-arrow-right' => 'ios arrow right' ),
			array( 'ion-ios-arrow-thin-down' => 'ios arrow thin down' ),
			array( 'ion-ios-arrow-thin-left' => 'ios arrow thin left' ),
			array( 'ion-ios-arrow-thin-right' => 'ios arrow thin right' ),
			array( 'ion-ios-arrow-thin-up' => 'ios arrow thin up' ),
			array( 'ion-ios-arrow-up' => 'ios arrow up' ),
			array( 'ion-ios-at' => 'ios at' ),
			array( 'ion-ios-at-outline' => 'ios at outline' ),
			array( 'ion-ios-barcode' => 'ios barcode' ),
			array( 'ion-ios-barcode-outline' => 'ios barcode outline' ),
			array( 'ion-ios-baseball' => 'ios baseball' ),
			array( 'ion-ios-baseball-outline' => 'ios baseball outline' ),
			array( 'ion-ios-basketball' => 'ios basketball' ),
			array( 'ion-ios-basketball-outline' => 'ios basketball outline' ),
			array( 'ion-ios-bell' => 'ios bell' ),
			array( 'ion-ios-bell-outline' => 'ios bell outline' ),
			array( 'ion-ios-body' => 'ios body' ),
			array( 'ion-ios-body-outline' => 'ios body outline' ),
			array( 'ion-ios-bolt' => 'ios bolt' ),
			array( 'ion-ios-bolt-outline' => 'ios bolt outline' ),
			array( 'ion-ios-book' => 'ios book' ),
			array( 'ion-ios-book-outline' => 'ios book outline' ),
			array( 'ion-ios-bookmarks' => 'ios bookmarks' ),
			array( 'ion-ios-bookmarks-outline' => 'ios bookmarks outline' ),
			array( 'ion-ios-box' => 'ios box' ),
			array( 'ion-ios-box-outline' => 'ios box outline' ),
			array( 'ion-ios-briefcase' => 'ios briefcase' ),
			array( 'ion-ios-briefcase-outline' => 'ios briefcase outline' ),
			array( 'ion-ios-browsers' => 'ios browsers' ),
			array( 'ion-ios-browsers-outline' => 'ios browsers outline' ),
			array( 'ion-ios-calculator' => 'ios calculator' ),
			array( 'ion-ios-calculator-outline' => 'ios calculator outline' ),
			array( 'ion-ios-calendar' => 'ios calendar' ),
			array( 'ion-ios-calendar-outline' => 'ios calendar outline' ),
			array( 'ion-ios-camera' => 'ios camera' ),
			array( 'ion-ios-camera-outline' => 'ios camera outline' ),
			array( 'ion-ios-cart' => 'ios cart' ),
			array( 'ion-ios-cart-outline' => 'ios cart outline' ),
			array( 'ion-ios-chatboxes' => 'ios chatboxes' ),
			array( 'ion-ios-chatboxes-outline' => 'ios chatboxes outline' ),
			array( 'ion-ios-chatbubble' => 'ios chatbubble' ),
			array( 'ion-ios-chatbubble-outline' => 'ios chatbubble outline' ),
			array( 'ion-ios-checkmark' => 'ios checkmark' ),
			array( 'ion-ios-checkmark-empty' => 'ios checkmark empty' ),
			array( 'ion-ios-checkmark-outline' => 'ios checkmark outline' ),
			array( 'ion-ios-circle-filled' => 'ios circle filled' ),
			array( 'ion-ios-circle-outline' => 'ios circle outline' ),
			array( 'ion-ios-clock' => 'ios clock' ),
			array( 'ion-ios-clock-outline' => 'ios clock outline' ),
			array( 'ion-ios-close' => 'ios close' ),
			array( 'ion-ios-close-empty' => 'ios close empty' ),
			array( 'ion-ios-close-outline' => 'ios close outline' ),
			array( 'ion-ios-cloud' => 'ios cloud' ),
			array( 'ion-ios-cloud-download' => 'ios cloud download' ),
			array( 'ion-ios-cloud-download-outline' => 'ios cloud download outline' ),
			array( 'ion-ios-cloud-outline' => 'ios cloud outline' ),
			array( 'ion-ios-cloud-upload' => 'ios cloud upload' ),
			array( 'ion-ios-cloud-upload-outline' => 'ios cloud upload outline' ),
			array( 'ion-ios-cloudy' => 'ios cloudy' ),
			array( 'ion-ios-cloudy-night' => 'ios cloudy night' ),
			array( 'ion-ios-cloudy-night-outline' => 'ios cloudy night outline' ),
			array( 'ion-ios-cloudy-outline' => 'ios cloudy outline' ),
			array( 'ion-ios-cog' => 'ios cog' ),
			array( 'ion-ios-cog-outline' => 'ios cog outline' ),
			array( 'ion-ios-color-filter' => 'ios color filter' ),
			array( 'ion-ios-color-filter-outline' => 'ios color filter outline' ),
			array( 'ion-ios-color-wand' => 'ios color wand' ),
			array( 'ion-ios-color-wand-outline' => 'ios color wand outline' ),
			array( 'ion-ios-compose' => 'ios compose' ),
			array( 'ion-ios-compose-outline' => 'ios compose outline' ),
			array( 'ion-ios-contact' => 'ios contact' ),
			array( 'ion-ios-contact-outline' => 'ios contact outline' ),
			array( 'ion-ios-copy' => 'ios copy' ),
			array( 'ion-ios-copy-outline' => 'ios copy outline' ),
			array( 'ion-ios-crop' => 'ios crop' ),
			array( 'ion-ios-crop-strong' => 'ios crop strong' ),
			array( 'ion-ios-download' => 'ios download' ),
			array( 'ion-ios-download-outline' => 'ios download outline' ),
			array( 'ion-ios-drag' => 'ios drag' ),
			array( 'ion-ios-email' => 'ios email' ),
			array( 'ion-ios-email-outline' => 'ios email outline' ),
			array( 'ion-ios-eye' => 'ios eye' ),
			array( 'ion-ios-eye-outline' => 'ios eye outline' ),
			array( 'ion-ios-fastforward' => 'ios fastforward' ),
			array( 'ion-ios-fastforward-outline' => 'ios fastforward outline' ),
			array( 'ion-ios-filing' => 'ios filing' ),
			array( 'ion-ios-filing-outline' => 'ios filing outline' ),
			array( 'ion-ios-film' => 'ios film' ),
			array( 'ion-ios-film-outline' => 'ios film outline' ),
			array( 'ion-ios-flag' => 'ios flag' ),
			array( 'ion-ios-flag-outline' => 'ios flag outline' ),
			array( 'ion-ios-flame' => 'ios flame' ),
			array( 'ion-ios-flame-outline' => 'ios flame outline' ),
			array( 'ion-ios-flask' => 'ios flask' ),
			array( 'ion-ios-flask-outline' => 'ios flask outline' ),
			array( 'ion-ios-flower' => 'ios flower' ),
			array( 'ion-ios-flower-outline' => 'ios flower outline' ),
			array( 'ion-ios-folder' => 'ios folder' ),
			array( 'ion-ios-folder-outline' => 'ios folder outline' ),
			array( 'ion-ios-football' => 'ios football' ),
			array( 'ion-ios-football-outline' => 'ios football outline' ),
			array( 'ion-ios-game-controller-a' => 'ios game controller a' ),
			array( 'ion-ios-game-controller-a-outline' => 'ios game controller a outline' ),
			array( 'ion-ios-game-controller-b' => 'ios game controller b' ),
			array( 'ion-ios-game-controller-b-outline' => 'ios game controller b outline' ),
			array( 'ion-ios-gear' => 'ios gear' ),
			array( 'ion-ios-gear-outline' => 'ios gear outline' ),
			array( 'ion-ios-glasses' => 'ios glasses' ),
			array( 'ion-ios-glasses-outline' => 'ios glasses outline' ),
			array( 'ion-ios-grid-view' => 'ios grid view' ),
			array( 'ion-ios-grid-view-outline' => 'ios grid view outline' ),
			array( 'ion-ios-heart' => 'ios heart' ),
			array( 'ion-ios-heart-outline' => 'ios heart outline' ),
			array( 'ion-ios-help' => 'ios help' ),
			array( 'ion-ios-help-empty' => 'ios help empty' ),
			array( 'ion-ios-help-outline' => 'ios help outline' ),
			array( 'ion-ios-home' => 'ios home' ),
			array( 'ion-ios-home-outline' => 'ios home outline' ),
			array( 'ion-ios-infinite' => 'ios infinite' ),
			array( 'ion-ios-infinite-outline' => 'ios infinite outline' ),
			array( 'ion-ios-information' => 'ios information' ),
			array( 'ion-ios-information-empty' => 'ios informatempty' ),
			array( 'ion-ios-information-outline' => 'ios informatoutline' ),
			array( 'ion-ios-ionic-outline' => 'ios ionic outline' ),
			array( 'ion-ios-keypad' => 'ios keypad' ),
			array( 'ion-ios-keypad-outline' => 'ios keypad outline' ),
			array( 'ion-ios-lightbulb' => 'ios lightbulb' ),
			array( 'ion-ios-lightbulb-outline' => 'ios lightbulb outline' ),
			array( 'ion-ios-list' => 'ios list' ),
			array( 'ion-ios-list-outline' => 'ios list outline' ),
			array( 'ion-ios-location' => 'ios location' ),
			array( 'ion-ios-location-outline' => 'ios locatoutline' ),
			array( 'ion-ios-locked' => 'ios locked' ),
			array( 'ion-ios-locked-outline' => 'ios locked outline' ),
			array( 'ion-ios-loop' => 'ios loop' ),
			array( 'ion-ios-loop-strong' => 'ios loop strong' ),
			array( 'ion-ios-medical' => 'ios medical' ),
			array( 'ion-ios-medical-outline' => 'ios medical outline' ),
			array( 'ion-ios-medkit' => 'ios medkit' ),
			array( 'ion-ios-medkit-outline' => 'ios medkit outline' ),
			array( 'ion-ios-mic' => 'ios mic' ),
			array( 'ion-ios-mic-off' => 'ios mic off' ),
			array( 'ion-ios-mic-outline' => 'ios mic outline' ),
			array( 'ion-ios-minus' => 'ios minus' ),
			array( 'ion-ios-minus-empty' => 'ios minus empty' ),
			array( 'ion-ios-minus-outline' => 'ios minus outline' ),
			array( 'ion-ios-monitor' => 'ios monitor' ),
			array( 'ion-ios-monitor-outline' => 'ios monitor outline' ),
			array( 'ion-ios-moon' => 'ios moon' ),
			array( 'ion-ios-moon-outline' => 'ios moon outline' ),
			array( 'ion-ios-more' => 'ios more' ),
			array( 'ion-ios-more-outline' => 'ios more outline' ),
			array( 'ion-ios-musical-note' => 'ios musical note' ),
			array( 'ion-ios-musical-notes' => 'ios musical notes' ),
			array( 'ion-ios-navigate' => 'ios navigate' ),
			array( 'ion-ios-navigate-outline' => 'ios navigate outline' ),
			array( 'ion-ios-nutrition' => 'ios nutrition' ),
			array( 'ion-ios-nutrition-outline' => 'ios nutritoutline' ),
			array( 'ion-ios-paper' => 'ios paper' ),
			array( 'ion-ios-paper-outline' => 'ios paper outline' ),
			array( 'ion-ios-paperplane' => 'ios paperplane' ),
			array( 'ion-ios-paperplane-outline' => 'ios paperplane outline' ),
			array( 'ion-ios-partlysunny' => 'ios partlysunny' ),
			array( 'ion-ios-partlysunny-outline' => 'ios partlysunny outline' ),
			array( 'ion-ios-pause' => 'ios pause' ),
			array( 'ion-ios-pause-outline' => 'ios pause outline' ),
			array( 'ion-ios-paw' => 'ios paw' ),
			array( 'ion-ios-paw-outline' => 'ios paw outline' ),
			array( 'ion-ios-people' => 'ios people' ),
			array( 'ion-ios-people-outline' => 'ios people outline' ),
			array( 'ion-ios-person' => 'ios person' ),
			array( 'ion-ios-person-outline' => 'ios person outline' ),
			array( 'ion-ios-personadd' => 'ios personadd' ),
			array( 'ion-ios-personadd-outline' => 'ios personadd outline' ),
			array( 'ion-ios-photos' => 'ios photos' ),
			array( 'ion-ios-photos-outline' => 'ios photos outline' ),
			array( 'ion-ios-pie' => 'ios pie' ),
			array( 'ion-ios-pie-outline' => 'ios pie outline' ),
			array( 'ion-ios-pint' => 'ios pint' ),
			array( 'ion-ios-pint-outline' => 'ios pint outline' ),
			array( 'ion-ios-play' => 'ios play' ),
			array( 'ion-ios-play-outline' => 'ios play outline' ),
			array( 'ion-ios-plus' => 'ios plus' ),
			array( 'ion-ios-plus-empty' => 'ios plus empty' ),
			array( 'ion-ios-plus-outline' => 'ios plus outline' ),
			array( 'ion-ios-pricetag' => 'ios pricetag' ),
			array( 'ion-ios-pricetag-outline' => 'ios pricetag outline' ),
			array( 'ion-ios-pricetags' => 'ios pricetags' ),
			array( 'ion-ios-pricetags-outline' => 'ios pricetags outline' ),
			array( 'ion-ios-printer' => 'ios printer' ),
			array( 'ion-ios-printer-outline' => 'ios printer outline' ),
			array( 'ion-ios-pulse' => 'ios pulse' ),
			array( 'ion-ios-pulse-strong' => 'ios pulse strong' ),
			array( 'ion-ios-rainy' => 'ios rainy' ),
			array( 'ion-ios-rainy-outline' => 'ios rainy outline' ),
			array( 'ion-ios-recording' => 'ios recording' ),
			array( 'ion-ios-recording-outline' => 'ios recording outline' ),
			array( 'ion-ios-redo' => 'ios redo' ),
			array( 'ion-ios-redo-outline' => 'ios redo outline' ),
			array( 'ion-ios-refresh' => 'ios refresh' ),
			array( 'ion-ios-refresh-empty' => 'ios refresh empty' ),
			array( 'ion-ios-refresh-outline' => 'ios refresh outline' ),
			array( 'ion-ios-reload' => 'ios reload' ),
			array( 'ion-ios-reverse-camera' => 'ios reverse camera' ),
			array( 'ion-ios-reverse-camera-outline' => 'ios reverse camera outline' ),
			array( 'ion-ios-rewind' => 'ios rewind' ),
			array( 'ion-ios-rewind-outline' => 'ios rewind outline' ),
			array( 'ion-ios-rose' => 'ios rose' ),
			array( 'ion-ios-rose-outline' => 'ios rose outline' ),
			array( 'ion-ios-search' => 'ios search' ),
			array( 'ion-ios-search-strong' => 'ios search strong' ),
			array( 'ion-ios-settings' => 'ios settings' ),
			array( 'ion-ios-settings-strong' => 'ios settings strong' ),
			array( 'ion-ios-shuffle' => 'ios shuffle' ),
			array( 'ion-ios-shuffle-strong' => 'ios shuffle strong' ),
			array( 'ion-ios-skipbackward' => 'ios skipbackward' ),
			array( 'ion-ios-skipbackward-outline' => 'ios skipbackward outline' ),
			array( 'ion-ios-skipforward' => 'ios skipforward' ),
			array( 'ion-ios-skipforward-outline' => 'ios skipforward outline' ),
			array( 'ion-ios-snowy' => 'ios snowy' ),
			array( 'ion-ios-speedometer' => 'ios speedometer' ),
			array( 'ion-ios-speedometer-outline' => 'ios speedometer outline' ),
			array( 'ion-ios-star' => 'ios star' ),
			array( 'ion-ios-star-half' => 'ios star half' ),
			array( 'ion-ios-star-outline' => 'ios star outline' ),
			array( 'ion-ios-stopwatch' => 'ios stopwatch' ),
			array( 'ion-ios-stopwatch-outline' => 'ios stopwatch outline' ),
			array( 'ion-ios-sunny' => 'ios sunny' ),
			array( 'ion-ios-sunny-outline' => 'ios sunny outline' ),
			array( 'ion-ios-telephone' => 'ios telephone' ),
			array( 'ion-ios-telephone-outline' => 'ios telephone outline' ),
			array( 'ion-ios-tennisball' => 'ios tennisball' ),
			array( 'ion-ios-tennisball-outline' => 'ios tennisball outline' ),
			array( 'ion-ios-thunderstorm' => 'ios thunderstorm' ),
			array( 'ion-ios-thunderstorm-outline' => 'ios thunderstorm outline' ),
			array( 'ion-ios-time' => 'ios time' ),
			array( 'ion-ios-time-outline' => 'ios time outline' ),
			array( 'ion-ios-timer' => 'ios timer' ),
			array( 'ion-ios-timer-outline' => 'ios timer outline' ),
			array( 'ion-ios-toggle' => 'ios toggle' ),
			array( 'ion-ios-toggle-outline' => 'ios toggle outline' ),
			array( 'ion-ios-trash' => 'ios trash' ),
			array( 'ion-ios-trash-outline' => 'ios trash outline' ),
			array( 'ion-ios-undo' => 'ios undo' ),
			array( 'ion-ios-undo-outline' => 'ios undo outline' ),
			array( 'ion-ios-unlocked' => 'ios unlocked' ),
			array( 'ion-ios-unlocked-outline' => 'ios unlocked outline' ),
			array( 'ion-ios-upload' => 'ios upload' ),
			array( 'ion-ios-upload-outline' => 'ios upload outline' ),
			array( 'ion-ios-videocam' => 'ios videocam' ),
			array( 'ion-ios-videocam-outline' => 'ios videocam outline' ),
			array( 'ion-ios-volume-high' => 'ios volume high' ),
			array( 'ion-ios-volume-low' => 'ios volume low' ),
			array( 'ion-ios-wineglass' => 'ios wineglass' ),
			array( 'ion-ios-wineglass-outline' => 'ios wineglass outline' ),
			array( 'ion-ios-world' => 'ios world' ),
			array( 'ion-ios-world-outline' => 'ios world outline' ),
			array( 'ion-ipad' => 'ipad' ),
			array( 'ion-iphone' => 'iphone' ),
			array( 'ion-ipod' => 'ipod' ),
			array( 'ion-jet' => 'jet' ),
			array( 'ion-key' => 'key' ),
			array( 'ion-knife' => 'knife' ),
			array( 'ion-laptop' => 'laptop' ),
			array( 'ion-leaf' => 'leaf' ),
			array( 'ion-levels' => 'levels' ),
			array( 'ion-lightbulb' => 'lightbulb' ),
			array( 'ion-link' => 'link' ),
			array( 'ion-load-a' => 'load a' ),
			array( 'ion-load-b' => 'load b' ),
			array( 'ion-load-c' => 'load c' ),
			array( 'ion-load-d' => 'load d' ),
			array( 'ion-location' => 'location' ),
			array( 'ion-lock-combination' => 'lock combination' ),
			array( 'ion-locked' => 'locked' ),
			array( 'ion-log-in' => 'log in' ),
			array( 'ion-log-out' => 'log out' ),
			array( 'ion-loop' => 'loop' ),
			array( 'ion-magnet' => 'magnet' ),
			array( 'ion-male' => 'male' ),
			array( 'ion-man' => 'man' ),
			array( 'ion-map' => 'map' ),
			array( 'ion-medkit' => 'medkit' ),
			array( 'ion-merge' => 'merge' ),
			array( 'ion-mic-a' => 'mic a' ),
			array( 'ion-mic-b' => 'mic b' ),
			array( 'ion-mic-c' => 'mic c' ),
			array( 'ion-minus' => 'minus' ),
			array( 'ion-minus-circled' => 'minus circled' ),
			array( 'ion-minus-round' => 'minus round' ),
			array( 'ion-model-s' => 'model s' ),
			array( 'ion-monitor' => 'monitor' ),
			array( 'ion-more' => 'more' ),
			array( 'ion-mouse' => 'mouse' ),
			array( 'ion-music-note' => 'music note' ),
			array( 'ion-navicon' => 'navicon' ),
			array( 'ion-navicon-round' => 'navicon round' ),
			array( 'ion-navigate' => 'navigate' ),
			array( 'ion-network' => 'network' ),
			array( 'ion-no-smoking' => 'no smoking' ),
			array( 'ion-nuclear' => 'nuclear' ),
			array( 'ion-outlet' => 'outlet' ),
			array( 'ion-paintbrush' => 'paintbrush' ),
			array( 'ion-paintbucket' => 'paintbucket' ),
			array( 'ion-paper-airplane' => 'paper airplane' ),
			array( 'ion-paperclip' => 'paperclip' ),
			array( 'ion-pause' => 'pause' ),
			array( 'ion-person' => 'person' ),
			array( 'ion-person-add' => 'person add' ),
			array( 'ion-person-stalker' => 'person stalker' ),
			array( 'ion-pie-graph' => 'pie graph' ),
			array( 'ion-pin' => 'pin' ),
			array( 'ion-pinpoint' => 'pinpoint' ),
			array( 'ion-pizza' => 'pizza' ),
			array( 'ion-plane' => 'plane' ),
			array( 'ion-planet' => 'planet' ),
			array( 'ion-play' => 'play' ),
			array( 'ion-playstation' => 'playstation' ),
			array( 'ion-plus' => 'plus' ),
			array( 'ion-plus-circled' => 'plus circled' ),
			array( 'ion-plus-round' => 'plus round' ),
			array( 'ion-podium' => 'podium' ),
			array( 'ion-pound' => 'pound' ),
			array( 'ion-power' => 'power' ),
			array( 'ion-pricetag' => 'pricetag' ),
			array( 'ion-pricetags' => 'pricetags' ),
			array( 'ion-printer' => 'printer' ),
			array( 'ion-pull-request' => 'pull request' ),
			array( 'ion-qr-scanner' => 'qr scanner' ),
			array( 'ion-quote' => 'quote' ),
			array( 'ion-radio-waves' => 'radio waves' ),
			array( 'ion-record' => 'record' ),
			array( 'ion-refresh' => 'refresh' ),
			array( 'ion-reply' => 'reply' ),
			array( 'ion-reply-all' => 'reply all' ),
			array( 'ion-ribbon-a' => 'ribbon a' ),
			array( 'ion-ribbon-b' => 'ribbon b' ),
			array( 'ion-sad' => 'sad' ),
			array( 'ion-sad-outline' => 'sad outline' ),
			array( 'ion-scissors' => 'scissors' ),
			array( 'ion-search' => 'search' ),
			array( 'ion-settings' => 'settings' ),
			array( 'ion-share' => 'share' ),
			array( 'ion-shuffle' => 'shuffle' ),
			array( 'ion-skip-backward' => 'skip backward' ),
			array( 'ion-skip-forward' => 'skip forward' ),
			array( 'ion-social-android' => 'social android' ),
			array( 'ion-social-android-outline' => 'social android outline' ),
			array( 'ion-social-angular' => 'social angular' ),
			array( 'ion-social-angular-outline' => 'social angular outline' ),
			array( 'ion-social-apple' => 'social apple' ),
			array( 'ion-social-apple-outline' => 'social apple outline' ),
			array( 'ion-social-bitcoin' => 'social bitcoin' ),
			array( 'ion-social-bitcoin-outline' => 'social bitcoin outline' ),
			array( 'ion-social-buffer' => 'social buffer' ),
			array( 'ion-social-buffer-outline' => 'social buffer outline' ),
			array( 'ion-social-chrome' => 'social chrome' ),
			array( 'ion-social-chrome-outline' => 'social chrome outline' ),
			array( 'ion-social-codepen' => 'social codepen' ),
			array( 'ion-social-codepen-outline' => 'social codepen outline' ),
			array( 'ion-social-css3' => 'social css3' ),
			array( 'ion-social-css3-outline' => 'social css3 outline' ),
			array( 'ion-social-designernews' => 'social designernews' ),
			array( 'ion-social-designernews-outline' => 'social designernews outline' ),
			array( 'ion-social-dribbble' => 'social dribbble' ),
			array( 'ion-social-dribbble-outline' => 'social dribbble outline' ),
			array( 'ion-social-dropbox' => 'social dropbox' ),
			array( 'ion-social-dropbox-outline' => 'social dropbox outline' ),
			array( 'ion-social-euro' => 'social euro' ),
			array( 'ion-social-euro-outline' => 'social euro outline' ),
			array( 'ion-social-facebook' => 'social facebook' ),
			array( 'ion-social-facebook-outline' => 'social facebook outline' ),
			array( 'ion-social-foursquare' => 'social foursquare' ),
			array( 'ion-social-foursquare-outline' => 'social foursquare outline' ),
			array( 'ion-social-freebsd-devil' => 'social freebsd devil' ),
			array( 'ion-social-github' => 'social github' ),
			array( 'ion-social-github-outline' => 'social github outline' ),
			array( 'ion-social-google' => 'social google' ),
			array( 'ion-social-google-outline' => 'social google outline' ),
			array( 'ion-social-googleplus' => 'social googleplus' ),
			array( 'ion-social-googleplus-outline' => 'social googleplus outline' ),
			array( 'ion-social-hackernews' => 'social hackernews' ),
			array( 'ion-social-hackernews-outline' => 'social hackernews outline' ),
			array( 'ion-social-html5' => 'social html5' ),
			array( 'ion-social-html5-outline' => 'social html5 outline' ),
			array( 'ion-social-instagram' => 'social instagram' ),
			array( 'ion-social-instagram-outline' => 'social instagram outline' ),
			array( 'ion-social-javascript' => 'social javascript' ),
			array( 'ion-social-javascript-outline' => 'social javascript outline' ),
			array( 'ion-social-linkedin' => 'social linkedin' ),
			array( 'ion-social-linkedin-outline' => 'social linkedin outline' ),
			array( 'ion-social-markdown' => 'social markdown' ),
			array( 'ion-social-nodejs' => 'social nodejs' ),
			array( 'ion-social-octocat' => 'social octocat' ),
			array( 'ion-social-pinterest' => 'social pinterest' ),
			array( 'ion-social-pinterest-outline' => 'social pinterest outline' ),
			array( 'ion-social-python' => 'social python' ),
			array( 'ion-social-reddit' => 'social reddit' ),
			array( 'ion-social-reddit-outline' => 'social reddit outline' ),
			array( 'ion-social-rss' => 'social rss' ),
			array( 'ion-social-rss-outline' => 'social rss outline' ),
			array( 'ion-social-sass' => 'social sass' ),
			array( 'ion-social-skype' => 'social skype' ),
			array( 'ion-social-skype-outline' => 'social skype outline' ),
			array( 'ion-social-snapchat' => 'social snapchat' ),
			array( 'ion-social-snapchat-outline' => 'social snapchat outline' ),
			array( 'ion-social-tumblr' => 'social tumblr' ),
			array( 'ion-social-tumblr-outline' => 'social tumblr outline' ),
			array( 'ion-social-tux' => 'social tux' ),
			array( 'ion-social-twitch' => 'social twitch' ),
			array( 'ion-social-twitch-outline' => 'social twitch outline' ),
			array( 'ion-social-twitter' => 'social twitter' ),
			array( 'ion-social-twitter-outline' => 'social twitter outline' ),
			array( 'ion-social-usd' => 'social usd' ),
			array( 'ion-social-usd-outline' => 'social usd outline' ),
			array( 'ion-social-vimeo' => 'social vimeo' ),
			array( 'ion-social-vimeo-outline' => 'social vimeo outline' ),
			array( 'ion-social-whatsapp' => 'social whatsapp' ),
			array( 'ion-social-whatsapp-outline' => 'social whatsapp outline' ),
			array( 'ion-social-windows' => 'social windows' ),
			array( 'ion-social-windows-outline' => 'social windows outline' ),
			array( 'ion-social-wordpress' => 'social wordpress' ),
			array( 'ion-social-wordpress-outline' => 'social wordpress outline' ),
			array( 'ion-social-yahoo' => 'social yahoo' ),
			array( 'ion-social-yahoo-outline' => 'social yahoo outline' ),
			array( 'ion-social-yen' => 'social yen' ),
			array( 'ion-social-yen-outline' => 'social yen outline' ),
			array( 'ion-social-youtube' => 'social youtube' ),
			array( 'ion-social-youtube-outline' => 'social youtube outline' ),
			array( 'ion-soup-can' => 'soup can' ),
			array( 'ion-soup-can-outline' => 'soup can outline' ),
			array( 'ion-speakerphone' => 'speakerphone' ),
			array( 'ion-speedometer' => 'speedometer' ),
			array( 'ion-spoon' => 'spoon' ),
			array( 'ion-star' => 'star' ),
			array( 'ion-stats-bars' => 'stats bars' ),
			array( 'ion-steam' => 'steam' ),
			array( 'ion-stop' => 'stop' ),
			array( 'ion-thermometer' => 'thermometer' ),
			array( 'ion-thumbsdown' => 'thumbsdown' ),
			array( 'ion-thumbsup' => 'thumbsup' ),
			array( 'ion-toggle' => 'toggle' ),
			array( 'ion-toggle-filled' => 'toggle filled' ),
			array( 'ion-transgender' => 'transgender' ),
			array( 'ion-trash-a' => 'trash a' ),
			array( 'ion-trash-b' => 'trash b' ),
			array( 'ion-trophy' => 'trophy' ),
			array( 'ion-tshirt' => 'tshirt' ),
			array( 'ion-tshirt-outline' => 'tshirt outline' ),
			array( 'ion-umbrella' => 'umbrella' ),
			array( 'ion-university' => 'university' ),
			array( 'ion-unlocked' => 'unlocked' ),
			array( 'ion-upload' => 'upload' ),
			array( 'ion-usb' => 'usb' ),
			array( 'ion-videocamera' => 'videocamera' ),
			array( 'ion-volume-high' => 'volume high' ),
			array( 'ion-volume-low' => 'volume low' ),
			array( 'ion-volume-medium' => 'volume medium' ),
			array( 'ion-volume-mute' => 'volume mute' ),
			array( 'ion-wand' => 'wand' ),
			array( 'ion-waterdrop' => 'waterdrop' ),
			array( 'ion-wifi' => 'wifi' ),
			array( 'ion-wineglass' => 'wineglass' ),
			array( 'ion-woman' => 'woman' ),
			array( 'ion-wrench' => 'wrench' ),
			array( 'ion-xbox' => 'xbox' ),
		);

		return array_merge( $icons, $ionicons );
	}

	/**
	 * Enqueue icon element font
	 *
	 * @param $font
	 */
	function vc_icon_element_fonts_enqueue( $font ) {
		switch ( $font ) {
			case 'ionicons':
				wp_enqueue_style( 'ionicons' );
		}
	}

	function vc_iconpicker_base_register_css() {
		wp_enqueue_style( 'ionicons', NAIX_ADDONS_URL . '/assets/css/ionicons.min.css', array(), '2.0.0' );
	}
}