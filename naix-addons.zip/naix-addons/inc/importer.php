<?php
/**
 * Hooks for importer
 *
 * @package Naix
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function naix_vc_addons_importer() {
	return array(
		array(
			'name'       => 'Home Agency Digital',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-digital/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-digital/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Agency Digital',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Agency Creative',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-creative/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-creative/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Agency Creative',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Agency Modern',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-modern/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-modern/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Agency Modern',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Full Screen Horizontal',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-horizontal/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-horizontal/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Full Screen Horizontal',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Full Screen Vertical',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-vertical/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-vertical/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Full Screen Vertical',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Agency Simple',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-simple/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/agency-simple/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Agency Simple',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Full Screen Parallax',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-parallax/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-parallax/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Full Screen Parallax',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Full Screen Text',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-text/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/full-screen-text/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Full Screen Text',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Freelance Designer',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/freelance-desinger/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/freelance-desinger/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Freelance Desinger',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Masonry Simple',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/masonry-simple/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/masonry-simple/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Masonry Simple',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Freelance Developer',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/freelance-developer/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/freelance-developer/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Freelance Developer',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Masonry Style',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/masonry-style/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/masonry-style/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Masonry Style',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Personal',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/personal/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/personal/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Personal',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Metro Style',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/metro-style/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/metro-style/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Metro Style',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

		array(
			'name'       => 'Home Photographer',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/photographer/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/photographer/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Photographer',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Grid Style',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/grid-style/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/grid-style/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Grid Style',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Text Interative',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/text-interative/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/text-interative/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Text Interative',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Home Video Featured',
			'preview'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/video-featured/preview.jpg',
			'content'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/demo-content.xml',
			'wpcf7'      => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/wpcf7.xml',
			'customizer' => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/video-featured/customizer.dat',
			'widgets'    => 'https://raw.githubusercontent.com/drfuri/demo-content/main/naix/widgets.wie',
			'pages'      => array(
				'front_page' => 'Home Video Featured',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
				'portfolio'  => 'Portfolio'
			),
			'menus'      => array(
				'primary' => 'primary-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

	);
}

add_filter( 'soo_demo_packages', 'naix_vc_addons_importer', 20 );

/**
 * Update more page options
 *
 * @param $pages
 */
function naix_addons_import_portfolio( $pages ) {

	if ( isset( $pages['portfolio'] ) ) {
		$portfolio = get_page_by_title( $pages['portfolio'] );

		if ( $portfolio ) {
			update_option( 'drf_portfolio_page_id', $portfolio->ID );
		}
	}
}

add_action( 'soodi_after_setup_pages', 'naix_addons_import_portfolio' );
